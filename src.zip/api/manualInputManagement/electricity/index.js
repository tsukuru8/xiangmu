import request from '@/utils/request'

/**
 * 列表
 * @param param
 * @returns {Promise<void>}
 */
export const electricInputList = async (param) => {
  return request({
    url: '/electricInput/getPageList',
    method: 'get',
    params: param
  })
}

/**
 * 新增
 * @param param
 * @returns {Promise<void>}
 */
export const electricInputAdd = async (param) => {
  return request({
    url: '/electricInput/addOne',
    method: 'post',
    data: param
  })
}

/**
 * 删除
 * @param param
 * @returns {Promise<void>}
 */
export const electricInputDel = async (param) => {
  return request({
    url: '/electricInput/deleteOne',
    method: 'get',
    params: param
  })
}

/**
 * 修改
 * @param param
 * @returns {Promise<void>}
 */
export const electricInputMod = async (param) => {
  return request({
    url: '/electricInput/editOne',
    method: 'post',
    data: param
  })
}
