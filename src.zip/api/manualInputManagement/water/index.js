import request from '@/utils/request'

/**
 * 列表
 * @param param
 * @returns {Promise<void>}
 */
export const waterInputList = async (param) => {
  return request({
    url: '/waterInput/getPageList',
    method: 'get',
    params: param
  })
}

/**
 * 新增
 * @param param
 * @returns {Promise<void>}
 */
export const waterInputAdd = async (param) => {
  return request({
    url: '/waterInput/addOne',
    method: 'post',
    params: param
  })
}

/**
 * 删除
 * @param param
 * @returns {Promise<void>}
 */
export const waterInputDel = async (param) => {
  return request({
    url: '/waterInput/deleteOne',
    method: 'get',
    params: param
  })
}

/**
 * 修改
 * @param param
 * @returns {Promise<void>}
 */
export const waterInputMod = async (param) => {
  return request({
    url: '/waterInput/editOne',
    method: 'post',
    params: param
  })
}
