import request from '@/utils/request'

/**
 * 列表
 * @param param
 * @returns {Promise<void>}
 */
export const gasInputList = async (param) => {
  return request({
    url: '/gasInput/getPageList',
    method: 'get',
    params: param
  })
}

/**
 * 新增
 * @param param
 * @returns {Promise<void>}
 */
export const gasInputAdd = async (param) => {
  return request({
    url: '/gasInput/addOne',
    method: 'post',
    data: param
  })
}

/**
 * 删除
 * @param param
 * @returns {Promise<void>}
 */
export const gasInputDel = async (param) => {
  return request({
    url: '/gasInput/deleteOne',
    method: 'get',
    params: param
  })
}

/**
 * 修改
 * @param param
 * @returns {Promise<void>}
 */
export const gasInputMod = async (param) => {
  return request({
    url: '/gasInput/editOne',
    method: 'post',
    data: param
  })
}
