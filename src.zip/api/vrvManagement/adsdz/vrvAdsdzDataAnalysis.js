import request from '@/utils/request'
//艾笛森中央空调系统二氧化碳浓度分析
export function co2List(query) {
  return request({
    url: '/vrvManagement/VrvAidisenCarbonDioxide/co2List',
    method: 'get',
    params: query
  })
}
// 查询艾笛森中央空调系统二氧化碳浓度列表
export function listVrvAidisenCarbonDioxide(query) {
  return request({
    url: '/vrvManagement/VrvAidisenCarbonDioxide/listCo2',
    method: 'get',
    params: query
  })
}
// 导出艾笛森中央空调系统二氧化碳浓度
export function exportVrvAidisenCarbonDioxide(query) {
  return request({
    url: '/vrvManagement/VrvAidisenCarbonDioxide/exportCo2',
    method: 'get',
    params: query
  })
}
// 根据key值查询温度/湿度
export function listTempHumidity(query) {
  return request({
    url: '/vrvManagement/aidisenTH/listTh',
    method: 'get',
    params: query
  })
}
export function thList(query) {
  return request({
    url: '/vrvManagement/aidisenTH/thList',
    method: 'get',
    params: query
  })
}
//导出温度/湿度
export function exportTempHumidity(query) {
  return request({
    url: '/vrvManagement/aidisenTH/exportTH',
    method:'get',
    params:query
  })
}
// 根据key值查询流量/冷热量
export function listFlowHotCold(query) {
  return request({
    url: '/vrvManagement/aidisenFlowHotCold/listFlowHotCold',
    method: 'get',
    params: query
  })
}
export function flowHotColdList(query) {
  return request({
    url: '/vrvManagement/aidisenFlowHotCold/flowHotColdList',
    method: 'get',
    params: query
  })
}
//导出流量/冷热量
export function exportFlowHotCold(query) {
  return request({
    url: '/vrvManagement/aidisenFlowHotCold/exportFlowHotCold',
    method:'get',
    params:query
  })
}

// 根据key值查询压力
export function listPressure(query) {
  return request({
    url: '/vrvManagement/aidisenPressure/listPressure',
    method: 'get',
    params: query
  })
}
export function pressureList(query) {
  return request({
    url: '/vrvManagement/aidisenPressure/pressureList',
    method: 'get',
    params: query
  })
}
//导出压力
export function exportPressure(query) {
  return request({
    url: '/vrvManagement/aidisenPressure/exportPressure',
    method:'get',
    params:query
  })
}
// 根据key值查询效率
export function listEff(query) {
  return request({
    url: '/vrvManagement/aidisenEff/listEff',
    method: 'get',
    params: query
  })
}
export function effList(query) {
  return request({
    url: '/vrvManagement/aidisenEff/effList',
    method: 'get',
    params: query
  })
}
//导出效率
export function exportEff(query) {
  return request({
    url: '/vrvManagement/aidisenEff/exportEff',
    method:'get',
    params:query
  })
}
//获取实时数据
export function realtimeData() {
  return request({
    url: '/vrvManagement/aidisen/realtimeData',
    method:'post',
  })
}
