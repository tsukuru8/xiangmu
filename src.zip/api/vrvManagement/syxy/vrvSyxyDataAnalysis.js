import request from '@/utils/request'

// 根据key值查询温度
export function listTempData(query) {
  return request({
    url: '/vrvManagement/syxy/analysis',
    method: 'get',
    params: query
  })
}
