import request from '@/utils/request'
/**
 * 查询扬杰中央空调系统节能前基期电量
 */
export function listYjPower(query) {
  return request({
    url: '/vrvManagement/VrvYjPower/list',
    method: 'get',
    params: query
  })
}
/**
 * 导出扬杰中央空调系统节能前基期电量
 */
export function exportYjPower(query) {
  return request({
    url: '/vrvManagement/VrvYjPower/export',
    method: 'get',
    params: query
  })
}
/**
 * 查询扬杰电子中央空调流量1_1列表
 */
export function listLl11(query) {
  return request({
    url: '/vrvManagement/yj/listLl11',
    method: 'get',
    params: query
  })
}
/**
 * 导出扬杰电子中央空调流量1_1列表
 */
export function exportLl11(query) {
  return request({
    url: '/vrvManagement/yj/exportLl11',
    method: 'get',
    params: query
  })
}

/**
 * 查询扬杰电子中央空调流量1_2列表
 */
export function listLl12(query) {
  return request({
    url: '/vrvManagement/yj/listLl12',
    method: 'get',
    params: query
  })
}
/**
 * 导出扬杰电子中央空调流量1_2列表
 * */
export function exportLl12(query) {
  return request({
    url: '/vrvManagement/yj/exportLl12',
    method: 'get',
    params: query
  })
}
/**
 * 查询扬杰电子中央空调流量1_3列表
 */
export function listLl13(query) {
  return request({
    url: '/vrvManagement/yj/listLl13',
    method: 'get',
    params: query
  })
}
/**
 * 导出扬杰电子中央空调流量1_3列表
 */
export function exportLl13(query) {
  return request({
    url: '/vrvManagement/yj/exportLl13',
    method: 'get',
    params: query
  })
}
/**
 * 查询扬杰电子中央空调电能1列表
 */
export function listDn1(query) {
  return request({
    url: '/vrvManagement/yj/listDn1',
    method: 'get',
    params: query
  })
}

/**
 * 导出扬杰电子中央空调电能1列表
 */
export function exportDn1(query) {
  return request({
    url: '/vrvManagement/yj/exportDn1',
    method: 'get',
    params: query
  })
}
/**
 * 查询扬杰电子中央空调电能2_1列表
 */
export function listDn21(query) {
  return request({
    url: '/vrvManagement/yj/listDn21',
    method: 'get',
    params: query

  })
}

/**
 * 导出扬杰电子中央空调电能2_1列表
 */
export function exportDn21(query) {
  return request({
    url: '/vrvManagement/yj/exportDn21',
    method: 'get',
    params: query
  })
}

/**
 * 查询扬杰电子中央空调电能2_2列表
 */
export function listDn22(query) {
  return request({
    url: '/vrvManagement/yj/listDn22',
    method: 'get',
    params: query
  })
}

/**
 * 导出扬杰电子中央空调电能2_2列表
 */
export function exportDn22(query) {
  return request({
    url: '/vrvManagement/yj/exportDn22',
    method: 'get',
    params: query
  })
}
// 查询扬杰电子中央空调流量2列表
export function listLl2(query) {
  return request({
    url: '/vrvManagement/yj/listLl2',
    method: 'get',
    params: query
  })
}
// 导出扬杰电子中央空调流量2
export function exportLl2(query) {
  return request({
    url: '/vrvManagement/yj/exportLl2',
    method: 'get',
    params: query
  })
}
