import request from '@/utils/request'

/** 各事业部费用饼图*/
export function divisionMonthCost() {
  return request({
    url:'/dataBigScreen/operation/costPie',
    method:'get'
  })
}
/** 厂区分布水电氮气总用量*/
export function totalEnergyUse() {
  return request({
    url:'/dataBigScreen/operation/operationNumber',
    method:'get',
  })
}
/** 水饼图
export function getWaterPie () {
  return request({
    url: '/operationData/waterPie',
    method: 'get',
  })
}*/

//仪表饼图
export function getMeterCountPie () {
  return request({
    url: '/dataBigScreen/deviceData/devicePie',
    method: 'get',
  })
}
/** 三类能耗日费用饼图*/
export function getThreeEnergyCostPie() {
  return request({
    url:'/dataBigScreen/energyDay/costPie',
    method:'get'
  })
}
/** 三类能耗日费用柱状图*/
export function getThreeEnergyCostBar() {
    return request({
      url:'/dataBigScreen/energyDay/costDay',
      method:'get'
    })
}
/** 月用量统计 水*/
export function waterMonthUseData() {
  return request({
    url:'/dataBigScreen/operation/waterPie',
    method:'get'
  })
}

/** 月用量统计 电*/
export function electricMonthUseData() {
  return request({
    url:'/dataBigScreen/operation/elctricPie',
    method:'get'
  })
}

/** 月用量统计 气*/
export function gasMonthUseData() {
  return request({
    url:'/dataBigScreen/operation/ngasPie',
    method:'get'
  })
}

/** 日报统计*/
export function getDailyNews() {
  return request({
    url:'/dataBigScreen/energyDay/dayNews',
    method:'get'
  })
}

/** 太阳能饼图*/
export function solarPieData() {
  return request({
    url:'/dataBigScreen/Solar/solarPie',
    method:'get'
  })
}
/** 太阳能柱状图*/
export function solarBarData() {
  return request({
    url:'/dataBigScreen/Solar/solarDay',
    method:'get'
  })
}
/** 异常分析*/
export function abnormalAnalysis() {
  return request({
    url:'/dataBigScreen/deviceData/offline',
    method: 'get',
  })
}

/** 日用量 水*/
export function waterDayUseLine() {
  return request({
    url:'/dataBigScreen/energyDay/waterDay',
    method: 'get',
  })
}
/** 日用量 电*/
export function electricDayUseLine() {
  return request({
    url:'/dataBigScreen/energyDay/elctricDay',
    method: 'get',
  })
}

/** 日用量 氮气*/
export function gasDayUseLine() {
  return request({
    url:'/dataBigScreen/energyDay/ngasDay',
    method: 'get',
  })
}
