import request from '@/utils/request'

/** 部门设备信息  */
export const getTreeForWater = async (query={deptId}) => {
  return request({
    url: '/system/deptDeviceTopics/getTreeForWater',
    method: 'get',
    params: query
  })
}

/** 用能分析
 * @param beginTime 搜索开始时间
 * @param deptId 部门id
 * @param deviceId 设备id
 * @param endTime 搜索结束时间
 * @param radioValue 分析类型 实时：0 日：1 月：2 年：3
 */
export const useAnalysis = async (query={beginTime, deptId, deviceId, endTime, radioValue}) => {
  return request({
    url: '/waterAnalysis/useAnalysis',
    method: 'get',
    params: query
  })
}

export const loadAnalysis = async (query={beginTime, deptId, deviceId, endTime, radioValue}) => {
  return request({
    url: '/waterAnalysis/loadAnalysis',
    method: 'get',
    params: query
  })
}

/**
 * 抄见用量日报表
 * @param {*} query 
 */
export const useDayReport = async (query={beginTime, deptId, deviceId, endTime, radioValue}) => {
  return request({
    url: '/waterDataReport/useDayReport',
    method: 'get',
    params: query
  })
}

export const useDayReportExport = async (query={beginTime, deptId, deviceId, endTime, radioValue}) => {
  return request({
    url: '/waterReportExport/useDayReportExport',
    method: 'get',
    params: query
  })
}

/**
 * 抄见示值日报表
 * @param {*} query 
 */
export const indicationDayReport = async (query={beginTime, deptId, deviceId, endTime, radioValue}) => {
  return request({
    url: '/waterDataReport/indicationDayReport',
    method: 'get',
    params: query
  })
}

export const indicationDayReportExport = async (query={beginTime, deptId, deviceId, endTime, radioValue}) => {
  return request({
    url: '/waterReportExport/indicationDayReportExport',
    method: 'get',
    params: query
  })
}

/**
 * 监测点数据监测
 * @param {*} query 
 */
export const monitorRealTimeReport = async (query={deviceId, date}) => {
  return request({
    url: '/waterDataReport/monitorRealTimeReport',
    method: 'get',
    params: query
  })
}

export const monitorRealTimeReportExport = async (query={deviceId, date}) => {
  return request({
    url: '/waterReportExport/monitorRealTimeReportExport',
    method: 'get',
    params: query
  })
}
