import request from '@/utils/request'
/** 部门设备信息  */
export const getTreeForWater = async (query={deptId}) => {
  return request({
    url: '/system/deptDeviceTopics/getTreeForWater',
    method: 'get',
    params: query
  })
}
/** 混合纯水  */
export const mixedPiont = async (query={date}) => {
  return request({
    url: '/waterPiont/mixedPiont',
    method: 'get',
    params: query
  })
}
/** 混合纯水  */
export const jennyPiont = async (query={date}) => {
  return request({
    url: '/waterPiont/jennyPiont',
    method: 'get',
    params: query
  })
}
// /** 混合纯水  */
// export const jennyTable = async (query={date}) => {
//   return request({
//     url: '/waterPiont/jennyTable',
//     method: 'get',
//     params: query
//   })
// }
//
// /** 混合纯水  */
// export const mixedTable = async (query={date}) => {
//   return request({
//     url: '/waterPiont/mixedTable',
//     method: 'get',
//     params: query
//   })
// }

/** 混合纯水  */
export const mixedMapDay = async (query={beginTime, endTime}) => {
  return request({
    url: '/waterPiont/mixedDay',
    method: 'get',
    params: query
  })
}


/** 混合纯水  */
export const jennyMapDay = async (query={beginTime, endTime}) => {
  return request({
    url: '/waterPiont/jennyDay',
    method: 'get',
    params: query
  })
}
