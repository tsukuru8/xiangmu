import request from '@/utils/request'

/** 电-部门设备信息  */
export const getTree = async (query = { deptId }) => {
  return request({
    url: '/system/deptDeviceTopics/getTree',
    method: 'get',
    params: query
  })
}

/** 用能分析
 * @param beginTime 搜索开始时间
 * @param deptId 部门id
 * @param deviceId 设备id
 * @param endTime 搜索结束时间
 * @param radioValue 分析类型 实时：0 日：1 月：2 年：3
 */
export const useAnalysis = async (query = { beginTime, deptId, deviceId, endTime, radioValue }) => {
  return request({
    url: '/electricAnalysis/useAnalysis',
    method: 'get',
    params: query
  })
}

/**
 * 负荷分析
 * @param beginTime 搜索开始时间
 * @param deptId 部门id
 * @param deviceId 设备id
 * @param endTime 搜索结束时间
 * @param radioValue 分析类型 实时：0 日：1 月：2 年：3
 */
export const loadAnalysis = async (query = { beginTime, deptId, deviceId, endTime, radioValue }) => {
  return request({
    url: '/electricAnalysis/loadAnalysis',
    method: 'get',
    params: query
  })
}

/** 分时统计分析
 * @param beginTime 搜索开始时间
 * @param deptId 部门id
 * @param deviceId 设备id
 * @param endTime 搜索结束时间
 * @param radioValue 分析类型 实时：0 日：1 月：2 年：3
 */
export const timeSharingAnalysis = async (query = { beginTime, deptId, deviceId, endTime, radioValue }) => {
  return request({
    url: '/electricAnalysis/timeSharingAnalysis',
    method: 'get',
    params: query
  })
}

/**
 * 力调分析
 * @param beginTime 搜索开始时间
 * @param deptId 部门id
 * @param deviceId 设备id
 * @param endTime 搜索结束时间
 * @param radioValue 分析类型 实时：0 日：1 月：2 年：3
 */
export const forceAnalysis = async (query = { beginTime, deptId, deviceId, endTime, radioValue }) => {
  return request({
    url: '/electricAnalysis/forceAnalysis',
    method: 'get',
    params: query
  })
}

/**
 * 抄见用量日报
 * @param {*} query
 */
export const useDayReport = async (query = { beginTime, deptId, deviceId, endTime, radioValue }) => {
  return request({
    url: '/electricDataReport/useDayReport',
    method: 'get',
    params: query
  })
}

export const useDayReportExport = async (query = { beginTime, deptId, deviceId, endTime, radioValue }) => {
  return request({
    url: '/electricReportExport/useDayReportExport',
    method: 'get',
    params: query
  })
}

/**
 * 抄见示值日报
 * @param {*} query
 */
export const indicationDayReport = async (query = { beginTime, deptId, deviceId, endTime, radioValue }) => {
  return request({
    url: '/electricDataReport/indicationDayReport',
    method: 'get',
    params: query
  })
}

export const indicationDayReportExport = async (query = { beginTime, deptId, deviceId, endTime, radioValue }) => {
  return request({
    url: '/electricReportExport/indicationDayReportExport',
    method: 'get',
    params: query
  })
}

/**
 * 监测点数据监测
 * @param {*} query
 */
export const monitorRealTimeReport = async (query = { beginTime, deptId, deviceId, endTime, radioValue }) => {
  return request({
    url: '/electricDataReport/monitorRealTimeReport',
    method: 'get',
    params: query
  })
}

export const monitorRealTimeReportExport = async (query = { beginTime, deptId, deviceId, endTime, radioValue }) => {
  return request({
    url: '/electricReportExport/monitorRealTimeReportExport',
    method: 'get',
    params: query
  })
}


/** 设备OEE
 * @param beginTime 搜索开始时间
 * @param machineCodeList 设备id数组
 * @param endTime 搜索结束时间
 */
export const deviceAnalysis = async (query = { beginTime, machineCodeList, endTime }) => {
  return request({
    url: '/split',
    method: 'get',
    params: query
  })
}

// 设备状态数据
export const ListDeviceStatus = async (query = { deptId }) => {
  return request({
    url: '/split/deviceInfo',
    method: 'get',
    params: query
  })
}

// 定时刷新时间下拉选择
export const getRefreshTimeOptions = async () => {
  return request({
    url: '/split/refreshTime',
    method: 'get',
  })
}
// 获取定时刷新时间
export const getRrefreshTime = async () => {
  return request({
    url: '/split/onTime',
    method: 'get',
  })
}

// 修改定时刷新时间
export function EditRrefreshTime(time) {
  return request({
    url: '/split/refreshTime/edit/' + time,
    method: 'put',
  })
}

// 查询告警列表
export function listAlarm(query) {
  return request({
    url: '/alarmManagement/log/list',
    method: 'get',
    params: query
  })
}

// 删除告警
export function delAlarm(id) {
  return request({
    url: '/alarmManagement/log/' + id,
    method: 'delete'
  })
}

// 导出告警
export function exportAlarm(query) {
  return request({
    url: '/alarmManagement/log/export',
    method: 'get',
    params: query
  })
}


/** 电-流程列表  */
export const getFlow = async (query = {}) => {
  return request({
    url: '/system/deptDeviceTopics/getFlow',
    method: 'get',
    params: query
  })
}


/**
 * 流程查询报表
 * @param {*} query
 */
export const workflowReport = async (query = { beginTime, flowid, endTime }) => {

  return request({
    url: '/electricDataReport/workflowReport',
    method: 'get',
    params: query
  })
}

export const workflowReportExport = async (query = { beginTime, flowid, endTime }) => {
  return request({
    url: '/electricReportExport/workflowReportExport',
    method: 'get',
    params: query
  })
}


export const getFlowDetail = async (query = { beginTime, flowid, endTime }) => {
  return request({
    url: '/electricDataReport/getFlowDetail',
    method: 'get',
    params: query
  })
}
export const workflowDetailReportExport = async (query = { beginTime, flowid, endTime }) => {
  return request({
    url: '/electricReportExport/workflowDetailReportExport',
    method: 'get',
    params: query
  })
}
