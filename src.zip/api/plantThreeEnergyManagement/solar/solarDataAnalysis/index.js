import request from '@/utils/request'

/** 太阳能-部门设备信息  */
export const getTreeForSolar = async (query={deptId}) => {
  return request({
    url: '/system/deptDeviceTopics/getTreeForSolar',
    method: 'get',
    params: query
  })
}
/** 用能分析
 * @param beginTime 搜索开始时间
 * @param deptId 部门id
 * @param deviceId 设备id
 * @param endTime 搜索结束时间
 * @param radioValue 分析类型 实时：0 日：1 月：2 年：3
 */
export const useAnalysis = async (query={beginTime, deptId, deviceId, endTime, radioValue}) => {
  return request({
    url: '/solarAnalysis/useAnalysis',
    method: 'get',
    params: query
  })
}

/**
 * 负荷分析
 * @param beginTime 搜索开始时间
 * @param deptId 部门id
 * @param deviceId 设备id
 * @param endTime 搜索结束时间
 * @param radioValue 分析类型 实时：0 日：1 月：2 年：3
 */
export const loadAnalysis = async (query={beginTime, deptId, deviceId, endTime, radioValue}) => {
  return request({
    url: '/solarAnalysis/loadAnalysis',
    method: 'get',
    params: query
  })
}

/** 分时统计分析
 * @param beginTime 搜索开始时间
 * @param deptId 部门id
 * @param deviceId 设备id
 * @param endTime 搜索结束时间
 * @param radioValue 分析类型 实时：0 日：1 月：2 年：3
 */
export const timeSharingAnalysis = async (query={beginTime, deptId, deviceId, endTime, radioValue}) => {
  return request({
    url: '/solarAnalysis/timeSharingAnalysis',
    method: 'get',
    params: query
  })
}

/**
 * 力调分析
 * @param beginTime 搜索开始时间
 * @param deptId 部门id
 * @param deviceId 设备id
 * @param endTime 搜索结束时间
 * @param radioValue 分析类型 实时：0 日：1 月：2 年：3
 */
export const forceAnalysis = async (query={beginTime, deptId, deviceId, endTime, radioValue}) => {
  return request({
    url: '/solarAnalysis/forceAnalysis',
    method: 'get',
    params: query
  })
}

/**
 * 抄见用量日报
 * @param {*} query
 */
export const useDayReport = async (query={beginTime, deptId, deviceId, endTime, radioValue}) => {
  return request({
    url: '/solarDataReport/useDayReport',
    method: 'get',
    params: query
  })
}

export const useDayReportExport = async (query={beginTime, deptId, deviceId, endTime, radioValue}) => {
  return request({
    url: '/solarReportExport/useDayReportExport',
    method: 'get',
    params: query
  })
}

/**
 * 抄见示值日报
 * @param {*} query
 */
export const indicationDayReport = async (query={beginTime, deptId, deviceId, endTime, radioValue}) => {
  return request({
    url: '/solarDataReport/indicationDayReport',
    method: 'get',
    params: query
  })
}

export const indicationDayReportExport = async (query={beginTime, deptId, deviceId, endTime, radioValue}) => {
  return request({
    url: '/solarReportExport/indicationDayReportExport',
    method: 'get',
    params: query
  })
}

/**
 * 监测点数据监测
 * @param {*} query
 */
export const monitorRealTimeReport = async (query={beginTime, deptId, deviceId, endTime, radioValue}) => {
  return request({
    url: '/solarDataReport/monitorRealTimeReport',
    method: 'get',
    params: query
  })
}

export const monitorRealTimeReportExport = async (query={beginTime, deptId, deviceId, endTime, radioValue}) => {
  return request({
    url: '/solarReportExport/monitorRealTimeReportExport',
    method: 'get',
    params: query
  })
}

export const systemStatus = async () =>{
  return request({
    url:'/realTime/systemStatus',
    method:'get'
  })
}
