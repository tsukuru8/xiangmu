import request from '@/utils/request'

// 汇总电能
export const sumElectricData = (query = {date}) => {
  return request({
    url: '/summary/summaryElectric',
    method: 'get',
    params: query
  })
}

// 计算电能
export const calculateElectricData = (query = {date}) => {
  return request({
    url: '/summary/calculateElectric',
    method: 'get',
    params: query
  })
}

//汇总水能
export const sumWaterData = (query = {date}) => {
  return request({
    url: '/summary/summaryWater',
    method: 'get',
    params: query
  })
}
//计算水能
export const calculateWaterData = (query = {date}) => {
  return request({
    url: '/summary/calculateWater',
    method: 'get',
    params: query
  })
}
//汇总气能
export const sumGasData = (query = {date}) => {
  return request({
    url: '/summary/summaryGas',
    method: 'get',
    params: query
  })
}
//计算气能
export const calculateGasData = (query = {date}) => {
  return request({
    url: '/summary/calculateGas',
    method: 'get',
    params: query
  })
}

// 汇总太阳能
export const sumSolarData = (query = {date}) => {
  return request({
    url: '/summary/summarySolar',
    method: 'get',
    params: query
  })
}

// 计算太阳能
export const calculateSolarData = (query = {date}) => {
  return request({
    url: '/summary/calculateSolar',
    method: 'get',
    params: query
  })
}

// 大屏数据计算
export const refreshBigScreenData = (query) => {
  return request({
    url: '/dataBigScreen/screenData/refreshBigScreenData',
    method: 'get',
    params: query
  })
}

// 汇总热能
export const sumThremalData = (query) => {
  return request({
    url: '/summary/summaryThermal',
    method: 'get',
    params: query
  })
}

// 计算热能
export const calculateThremalData = (query) => {
  return request({
    url: '/summary/calculateThermal',
    method: 'get',
    params: query
  })
}
