import request from '@/utils/request'

// 查询MQTT订阅配置列表
export function listConfigure(query) {
  return request({
    url: '/mqtt/configure/list',
    method: 'get',
    params: query
  })
}

// 查询MQTT订阅配置详细
export function getConfigure(id) {
  return request({
    url: '/mqtt/configure/' + id,
    method: 'get'
  })
}

// 新增MQTT订阅配置
export function addConfigure(data) {
  return request({
    url: '/mqtt/configure',
    method: 'post',
    data: data
  })
}

// 修改MQTT订阅配置
export function updateConfigure(data) {
  return request({
    url: '/mqtt/configure',
    method: 'put',
    data: data
  })
}

// 删除MQTT订阅配置
export function delConfigure(id) {
  return request({
    url: '/mqtt/configure/' + id,
    method: 'delete'
  })
}

// 导出MQTT订阅配置
export function exportConfigure(query) {
  return request({
    url: '/mqtt/configure/export',
    method: 'get',
    params: query
  })
}

//配置相应的数据库
export function generateDateTable(id) {
  return request({
    url: '/mqtt/configure/generateDataTable/' + id,
    method: 'post'
  })
}
