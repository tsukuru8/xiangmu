import request from '@/utils/request'

/**
 * 3厂日报表
 * @param query
 * @returns {Promise<void>}
 */
export const exportThirdFtyRpForDay = async (query = {monthParm}) => {
  return request({
    url: '/thirdFtyRp/getDayRp',
    method: 'get',
    params: query
  })
}


/**
 * 3厂月报表
 * @param query
 * @returns {Promise<void>}
 */
export const exportThirdFtyRpForMonth = async (query = {monthParm}) => {
  return request({
    url: '/thirdFtyRp/getMonthRp',
    method: 'get',
    params: query
  })
}


/**
 * 2厂月报表
 * @param query
 * @returns {Promise<void>}
 */
export const exportSecondFtyRpForMonth = async (query = {monthParm}) => {
  return request({
    url: '/thirdFtyRp/getSecftyMonthRp',
    method: 'get',
    params: query
  })
}


export function handleThreeExport () {
  return request({
    url: '/thirdFtyRpModel/downloadThreeExcel',
    method: 'get',
  })
}

export function handleTwoExport () {
  return request({
    url: '/thirdFtyRpModel/downloadTwoExcel',
    method: 'get',
  })
}

export function handleDayExport () {
  return request({
    url: '/thirdFtyRpModel/downloadDayExcel',
    method: 'get',
  })
}

export const handleDayImport = async (query = {uploadfile}) => {
    return request({
      url: '/thirdFtyRpModel/importmoban',
      method: 'get',
      params: query
    })
}

/**
 * 日报表模板数据
 */
export const getRpModelDailyList = async (query) => {
  return request({
    url: '/reportModel/getDailyList',
    method: 'get',
    params: query
  })
}



/**
 * 日报表模板下载
 */
export const downloadRpModelDaily = async (query) => {
  return request({
    url: '/reportModel/downloadDailyModel',
    method: 'get',
    params: query
  })
}
