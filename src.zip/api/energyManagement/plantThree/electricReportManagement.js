import request from '@/utils/request'

// 查询Mqtt信息
export function listMqtt(query) {
  return request({
    url: '/energyManagement/listMqtt',
    method: 'get',
    params: query
  })
}
