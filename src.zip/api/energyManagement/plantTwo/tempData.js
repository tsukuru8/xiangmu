import request from '@/utils/request'

// 查询电能21临时数据
export function tempData21(query) {
  return request({
    url: '/tempData/tempData21',
    method: 'get',
    params: query
  })
}

// 导出电能21临时数据
export function exportDn21(query) {
  return request({
    url: '/tempData/exportDn21',
    method: 'get',
    params: query
  })
}


//查询电能22临时数据
export function tempData22(query) {
  return request({
    url: '/tempData/tempData22',
    method: 'get',
    params: query
  })
}

// 导出电能22临时数据
export function exportDn22(query) {
  return request({
    url: '/tempData/exportDn22',
    method: 'get',
    params: query
  })
}
