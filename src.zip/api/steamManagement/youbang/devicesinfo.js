import request from '@/utils/request'

// 查询优邦蒸汽信息列表
export function listDevicesinfo(query) {
  return request({
    url: '/steamManagement/youbangdevicesinfo/list',
    method: 'get',
    params: query
  })
}

// 查询优邦蒸汽信息详细
export function getDevicesinfo(id) {
  return request({
    url: '/steamManagement/youbangdevicesinfo/' + id,
    method: 'get'
  })
}

// 新增优邦蒸汽信息
export function addDevicesinfo(data) {
  return request({
    url: '/steamManagement/youbangdevicesinfo',
    method: 'post',
    data: data
  })
}

// 修改优邦蒸汽信息
export function updateDevicesinfo(data) {
  return request({
    url: '/steamManagement/youbangdevicesinfo',
    method: 'put',
    data: data
  })
}

// 删除优邦蒸汽信息
export function delDevicesinfo(id) {
  return request({
    url: '/steamManagement/youbangdevicesinfo/' + id,
    method: 'delete'
  })
}

// 导出优邦蒸汽信息
export function exportDevicesinfo(query) {
  return request({
    url: '/steamManagement/youbangdevicesinfo/export',
    method: 'get',
    params: query
  })
}
