import request from '@/utils/request'

//查询用量
export function countYoubangCountConsumption(query) {
  return request({
    url: '/steamManagement/youbang/count',
    method: 'get',
    params: query
  })
}

// 查询优邦蒸汽数据收集列表
export function listYoubang(query) {
  return request({
    url: '/steamManagement/youbang/list',
    method: 'get',
    params: query
  })
}

// 查询优邦蒸汽数据收集详细
export function getYoubang(id) {
  return request({
    url: '/steamManagement/youbang/' + id,
    method: 'get'
  })
}

// 新增优邦蒸汽数据收集
export function addYoubang(data) {
  return request({
    url: '/steamManagement/youbang',
    method: 'post',
    data: data
  })
}

// 修改优邦蒸汽数据收集
export function updateYoubang(data) {
  return request({
    url: '/steamManagement/youbang',
    method: 'put',
    data: data
  })
}

// 删除优邦蒸汽数据收集
export function delYoubang(id) {
  return request({
    url: '/steamManagement/youbang/' + id,
    method: 'delete'
  })
}

// 导出优邦蒸汽数据收集
export function exportYoubang(query) {
  return request({
    url: '/steamManagement/youbang/export',
    method: 'get',
    params: query
  })
}

// 导出优邦蒸汽瞬时数据
export function exportYoubangShunShi(query) {
  return request({
    url: '/steamManagement/youbang/exportshunshi',
    method: 'get',
    params: query
  })
}


// 导出优邦蒸汽瞬时数据
export function exportYoubangUseageStatistics(query) {
  return request({
    url: '/steamManagement/youbang/exportUseageStatistics',
    method: 'get',
    params: query
  })
}

//查询年月日用量
export function selectMDMYYoubangCountConsumption(query) {
  return request({
    url: '/steamManagement/youbang/analysis',
    method: 'get',
    params: query
  })
}

//查询瞬时流量
export function selectInstantData(query) {
  return request({
    url: '/steamManagement/youbang/instantData',
    method: 'get',
    params: query
  })
}
