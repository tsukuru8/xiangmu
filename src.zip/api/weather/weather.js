import request from '@/utils/request'

/** 部门设备信息  */
export function getWeather() {
  return request({
    url: '/weather/yangzhou',
    method: 'get'
  })
}
