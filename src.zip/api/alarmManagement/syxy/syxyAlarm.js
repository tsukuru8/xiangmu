import request from '@/utils/request'

// 查询预报警管理列表
export function listAlarm(query) {
  return request({
    url: '/alarmManagement/alarm/list',
    method: 'get',
    params: query
  })
}

// 查询预报警管理详细
export function getAlarm(id) {
  return request({
    url: '/alarmManagement/alarm/' + id,
    method: 'get'
  })
}

// 新增预报警管理
export function addAlarm(data) {
  return request({
    url: '/alarmManagement/alarm',
    method: 'post',
    data: data
  })
}

// 修改预报警管理
export function updateAlarm(data) {
  return request({
    url: '/alarmManagement/alarm',
    method: 'put',
    data: data
  })
}

// 删除预报警管理
export function delAlarm(id) {
  return request({
    url: '/alarmManagement/alarm/' + id,
    method: 'delete'
  })
}

// 导出预报警管理
export function exportAlarm(query) {
  return request({
    url: '/alarmManagement/alarm/export',
    method: 'get',
    params: query
  })
}
