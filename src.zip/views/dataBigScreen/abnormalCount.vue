<template>
  <div id="abnormalCount">
    <div class="bg-color-black">
      <div class="d-flex jc-start title" style="margin: 0 0.1rem">
        <div class="dec">—</div>
        <div style="font-family: SimHei">异常分析</div>
        <div class="dec">—</div>
      </div>
      <div class="d-flex jc-center body-box">
        <dv-scroll-board :config="config" style="width:5.3333rem;height:1.633333rem; margin: 0.2rem 0.2rem 0.2rem 0.1rem"/>
      </div>
    </div>
  </div>
</template>

<script>
  import {abnormalAnalysis} from '../../api/plantThreeEnergyManagement/dataBigScreen/dataBigScreen'

  export default {
    data() {
      return {
        timer:'',
        config: {
          header: ["<span style='font-size:12px; color: #00f4be;'>厂区</span>", "<span style='color: #00f4be;font-size:12px;'>仪表名称</span>", "<span style='color: #00f4be;font-size:12px;'>离线时间</span>"],
          data: [
            ["一厂", "引线桥总表", "2020-09-10 15:20:30"],
            ["二厂", "晶圆二厂总表", "2020-09-10 15:20:30"],
            ["三厂", "总表", "2020-09-10 15:20:30"],
            ["电镀", "电镀总表", "2020-09-10 15:20:30"],
            ["泗洪", "泗洪总表", "2020-09-10 15:20:30"],
          ],
          indexHeader:'<span style="color: #00f4be;font-size:12px;">序号</span>',
          waitTime:'5000',
          headerBGC:'#1a6492',
          oddRowBGC:'',
          evenRowBGC:'#112f5c',
          rowNum: 3, //表格行数
          headerHeight: 20,
          //headerBGC: "#0f1325", //表头
          //oddRowBGC: "#0f1325", //奇数行
          //evenRowBGC: "#171c33", //偶数行
          index: true,
          columnWidth: [60,70,120],
          align: ["center"]
        }
      };
    },
    components: {},
    mounted() {
      this.abnormalAnalysis()
      this.timer = setInterval(()=>{
        this.abnormalAnalysis()
      },60*60*1000)
    },
    beforeDestroy() {
      clearInterval(this.timer);
    },
    methods: {
      abnormalAnalysis(){
        const { config } = this
        abnormalAnalysis().then(response=>{
          this.config.data = response.data
          this.config = {...this.config}
        })
      }
    }
  };
</script>

<style lang="scss">
  #abnormalCount {
    padding: 0.1rem 0.1rem 0.1rem 0.1rem;
    // height: 2rem;
    min-width: 2.75rem;
    border-radius: 0.0625rem;
    font-family: SimHei;
    .bg-color-black {
      padding: 0 0.2rem;
      height: 2rem;
      border-radius: 0.125rem;
      .title {
        height: 0.466667rem;
        color: #fff;
        font-size: 0.24rem;

        .dec {
          margin: 0 0.133333rem;
          color: #11E8E3;
          text-shadow: 0 0 5px #11E8E3;
          font-weight: 800;
        }
      }
      .total-cost {
        font-family: SimHei;
        color: #fff;
        .cost {
          margin: 0 0.2rem;
          font-size: 0.293333rem;
          text-align: center;
          // line-height: .256667rem;
          text-shadow: 0 0 5px #03BAB5;
          color: #03BAB5;
          font-weight: 800;
        }
      }
    }
    .text {
      color: #c3cbde;
    }
    // .body-box {
    //   //border-radius: 0.125rem;
    //   //overflow: hidden;
    // }
  }
</style>
