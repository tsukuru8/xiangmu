<template>
  <div id="totalCost">
    <div class="bg-color-black">
      <!-- 标题部分 -->
      <div class="d-flex jc-start title" style="margin: 0 0.1rem">
        <div class="dec">—</div>
        <div style=" font-family: SimHei;">各事业部费用月统计</div>
        <div class="dec">—</div>
      </div>
      <!-- 总费用部分 -->
      <div class="d-flex jc-end total-cost">
        <span class="size">总费用：</span>
        <span class="cost">{{sumCost}}</span>
        <span  class="size">元</span>
      </div>
      <!-- <div class="d-flex pt-2 pl-2">
        <span style="color:#5cd9e8">
          <icon name="chart-bar"></icon>
        </span>
        <div class="d-flex">
          <span class="fs-xl text mx-2">各事业部费用统计</span>
        </div>
      </div> -->
      <div>
        <totalCostPieChart :chart-data="totalCostPie"/>
      </div>
    </div>
  </div>
</template>

<script>
import totalCostPieChart from "../dashboard/dataBigScreenEcharts/totalCostPieChart";
import {divisionMonthCost} from '../../api/plantThreeEnergyManagement/dataBigScreen/dataBigScreen'
const totalCostPie = {
  totalCostPieChartList:{
    fourInch:1,
    sixInch:2,
    smallSignal:3,
    paster:4,
    lead:5,
    junction:6,
    PV:7,
    SC:8,
  }
}
export default {
  data() {
    return {
      timer:'',
      sumCost:0,
      totalCostPie:totalCostPie.totalCostPieChartList
    };
  },
  components: {
    totalCostPieChart,
  },
  mounted() {
    this.divisionMonthCostData()
    this.timer = setInterval(()=>{
      this.divisionMonthCostData()
    },60*60*1000)
  },
  beforeDestroy() {
    clearInterval(this.timer);
  },
  methods: {
    divisionMonthCostData(){
      divisionMonthCost().then(response=>{
        let  data = response.data
        this.totalCostPie = data
        this.sumCost = data.total
      })
    }
  },
};
</script>

<style lang="scss">
#totalCost {
  padding: 0.1rem 0.1rem;
  // box-sizing: 7.6648rem;
  // height: 3.2rem;
  // width: 484.014px;

  // height: 3.5rem;
  // height: 3.52rem;
  min-width: 1.75rem;
  border-radius: 0.0625rem;
  .bg-color-black {
  // width: 6.45352rem;
   padding: 0 .2rem;
    border-radius: 0.125rem;

  .title {
    height: .466667rem;
    color: #fff;
    font-size: .24rem;


    .dec{
      margin:0 .133333rem;
      color: #11E8E3;
       text-shadow: 0 0 5px #11E8E3;
      font-weight: 800;
    }
  }
  .total-cost{
    font-family: SimHei;
    color: #fff;
    .cost{
      margin: .093333rem 0.2rem 0 0.2rem;
      font-size: .24rem;
      text-align: center;
      // line-height: .256667rem;
      line-height: .133333rem;
      color: #E6C93D;
      font-weight: 800;
    }
    .size{
      font-size: .16rem;
    }
  }
  // .text {
  //   color: #fff;
  // }
  .chart-box {
    // width: 7.266667rem;
    width:6.24rem;
    height: 2.125rem;
    .active-ring-name {
      padding-top: 0.125rem;
    }
  }
}}
</style>
