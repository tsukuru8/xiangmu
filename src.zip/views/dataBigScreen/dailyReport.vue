<template>
  <div id="dailyReport">
    <div class="bg-color-black">
      <!-- 标题部分 -->
      <div class="d-flex float-l jc-start title" style="margin: 0 0.1rem">
        <div class="dec">—</div>
        <div style="font-family: SimHei">日报统计</div>
        <div class="dec">—</div>
      </div>
      <!-- 各工厂 -->
      <div class="d-flex jc-end total-cost">
        <span class="cost size" v-if="activeName">{{factoryName}}</span>
        <span class="cost">{{yesterday}}</span>
      </div>
      <div class="d-flex jc-around container">
         <!-- 水 -->
        <div class="d-flex water">
          <div class="water-img">
             <img src="../../assets/image/water.png" alt="" />
             <span><br/>水</span>
          </div>
          <div class="water-yield">
            <div class="cost">{{tableData.dayWater}}</div>
            <div class="size">水量<br />(m³)</div>
          </div>
          <div class="water-cost">
            <div class="cost">{{tableData.dayWaterCost}}</div>
            <div class="size">水费<br />(元)</div>
          </div>
                  </div>
                  <span class="qua">|</span>
        <!-- 电 -->
         <div class="d-flex elec">
           <div class="elec-img">
             <img src="../../assets/image/elec.png" alt="" />
             <span><br/>电</span>
          </div>
          <div class="elec-yield">
            <div class="cost">{{tableData.dayElectric}}</div>
            <div class="size">电量<br />(m³)</div>
          </div>
          <div class="elec-cost">
            <div class="cost">{{tableData.dayElectricCost}}</div>
            <div class="size">电费<br />(元)</div>
          </div>
         </div>
                  <span class="qua">|</span>
         <!-- 氮气 -->
         <div class="d-flex gas">
           <div class="gas-img">
             <img src="../../assets/image/gas.png" alt="" />
             <span><br/>氮气</span>
          </div>
          <div class="gas-yield">
            <div class="cost">{{tableData.dayGas}}</div>
            <div class="size">氮气量<br />(Nm³)</div>
          </div>
          <div class="gas-cost">
            <div class="cost">{{tableData.dayGasCost}}</div>
            <div class="size">氮气费<br />(元)</div>
          </div>
         </div>
                  <span class="qua">|</span>
         <!-- 合计 -->
          <div class="total">

            <div class="cost">{{tableData.dayTotalCost}}</div>
            <div class="size">合计<br />(元)</div>

          </div>

      </div>
    </div>
  </div>
</template>

<script>
import {getDailyNews} from '../../api/plantThreeEnergyManagement/dataBigScreen/dataBigScreen'
import dayjs from 'dayjs'

export default {
  data() {
    return {
      yesterday:'2月2日',
      activeName:1,
      factoryName:'运营体系',
      timer:'',
      timer2:'',
      tableData:
        {
          dayElectric: "25963",
          dayElectricCost: "5756",
          dayWater: "2564",
          dayWaterCost: "1231",
          dayGas: "5647",
          dayGasCost: "2541",
          dayTotalCost: "12365",
        },
    };
  },
  components: {
  },
  mounted() {
    this.getNowDate()
    this.getDailyNewsData()
    this.timer2 = setInterval(()=>{
      this.getNowDate()
    },5*3600*1000),
    this.timer = setInterval(()=>{
      this.activeName++
      console.log('序号',this.activeName)
      if (this.activeName === 10){
        this.activeName = 1
        console.log('重置序号',this.activeName)
      }
      this.getDailyNewsData()
    },60*1000)
  },
  beforeDestroy() {
    clearInterval(this.timer);
    clearInterval(this.timer2);
  },
  methods: {
    // 获取当前时间
    getNowDate(){
      let nowTime = dayjs(dayjs().add(-1, 'day').toString()).format('YYYY-MM-DD');
      this.yesterday = nowTime.substring(5,7)+'月'+nowTime.substring(8,10)+'日'
      console.log('昨天是几号-------', this.yesterday)
    },
    getDailyNewsData(){
      getDailyNews().then(response=>{
        let data = response.data
        console.log('日报----',data)
        switch (this.activeName) {
          case 1:{
            this.factoryName = '运营体系';
            this.tableData.dayWater = data.total.dayWater
            this.tableData.dayWaterCost = data.total.dayWaterCost
            this.tableData.dayElectric = data.total.dayElectric
            this.tableData.dayElectricCost = data.total.dayElectricCost
            this.tableData.dayGas = data.total.dayNgas
            this.tableData.dayGasCost = data.total.dayNgasCost
            this.tableData.dayTotalCost = data.total.dayCost
            break;
          }
          case 2:{
            this.factoryName = '四寸晶圆';
            this.tableData.dayWater = data.fourInch.dayWater
            this.tableData.dayWaterCost = data.fourInch.dayWaterCost
            this.tableData.dayElectric = data.fourInch.dayElectric
            this.tableData.dayElectricCost = data.fourInch.dayElectricCost
            this.tableData.dayGas = data.fourInch.dayNgas
            this.tableData.dayGasCost = data.fourInch.dayNgasCost
            this.tableData.dayTotalCost = data.fourInch.dayCost
            break;
          }
          case 3:{
            this.factoryName = '六寸晶圆';
            this.tableData.dayWater = data.sixInch.dayWater
            this.tableData.dayWaterCost = data.sixInch.dayWaterCost
            this.tableData.dayElectric = data.sixInch.dayElectric
            this.tableData.dayElectricCost = data.sixInch.dayElectricCost
            this.tableData.dayGas = data.sixInch.dayNgas
            this.tableData.dayGasCost = data.sixInch.dayNgasCost
            this.tableData.dayTotalCost = data.sixInch.dayCost
            break;
          }
          case 4:{
            this.factoryName = '引线器件工厂'
            this.tableData.dayWater = data.lead.dayWater
            this.tableData.dayWaterCost = data.lead.dayWaterCost
            this.tableData.dayElectric = data.lead.dayElectric
            this.tableData.dayElectricCost = data.lead.dayElectricCost
            this.tableData.dayGas = data.lead.dayNgas
            this.tableData.dayGasCost = data.lead.dayNgasCost
            this.tableData.dayTotalCost = data.lead.dayCost
            break;
          }
          case 5:{
            this.factoryName = '贴片器件工厂'
            this.tableData.dayWater = data.paster.dayWater
            this.tableData.dayWaterCost = data.paster.dayWaterCost
            this.tableData.dayElectric = data.paster.dayElectric
            this.tableData.dayElectricCost = data.paster.dayElectricCost
            this.tableData.dayGas = data.paster.dayNgas
            this.tableData.dayGasCost = data.paster.dayNgasCost
            this.tableData.dayTotalCost = data.paster.dayCost
            break;
          }
          case 6:{
            this.factoryName = '小信号工厂'
            this.tableData.dayWater = data.smallSignal.dayWater
            this.tableData.dayWaterCost = data.smallSignal.dayWaterCost
            this.tableData.dayElectric = data.smallSignal.dayElectric
            this.tableData.dayElectricCost = data.smallSignal.dayElectricCost
            this.tableData.dayGas = data.smallSignal.dayNgas
            this.tableData.dayGasCost = data.smallSignal.dayNgasCost
            this.tableData.dayTotalCost = data.smallSignal.dayCost
            break;
          }
          case 7:{
            this.factoryName = '框架桥工厂'
            this.tableData.dayWater = data.junction.dayWater
            this.tableData.dayWaterCost = data.junction.dayWaterCost
            this.tableData.dayElectric = data.junctiondayElectric
            this.tableData.dayElectricCost = data.junction.dayElectricCost
            this.tableData.dayGas = data.junction.dayNgas
            this.tableData.dayGasCost = data.junction.dayNgasCost
            this.tableData.dayTotalCost = data.junction.dayCost
            break;
          }
          case 8:{
            this.factoryName = '光伏工厂'
            this.tableData.dayWater = data.PV.dayWater
            this.tableData.dayWaterCost = data.PV.dayWaterCost
            this.tableData.dayElectric = data.PV.dayElectric
            this.tableData.dayElectricCost = data.PV.dayElectricCost
            this.tableData.dayGas = data.PV.dayNgas
            this.tableData.dayGasCost = data.PV.dayNgasCost
            this.tableData.dayTotalCost = data.PV.dayCost
            break;
          }
          case 9:{
            this.factoryName = '供应链工厂'
            this.tableData.dayWater = data.SC.dayWater
            this.tableData.dayWaterCost = data.SC.dayWaterCost
            this.tableData.dayElectric = data.SC.dayElectric
            this.tableData.dayElectricCost = data.SC.dayElectricCost
            this.tableData.dayGas = data.SC.dayNgas
            this.tableData.dayGasCost = data.SC.dayNgasCost
            this.tableData.dayTotalCost = data.SC.dayCost
            break;
          }
        }
      })
    }
  },
};
</script>

<style lang="scss">
#dailyReport {
  padding: 0.1rem 0.1rem;
  // height: 2.1rem;
  margin-right: 0.133333rem;
  min-width: 1.75rem;
  border-radius: 0.0625rem;
  font-family: SimHei;
  .bg-color-black {
    padding: 0 0.2rem 0 0;
    // height: 6.1rem;
    border-radius: 0.125rem;
    color: #fff;
    .title {
      height: 0.466667rem;
      color: #fff;
      font-size: 0.24rem;

      .dec {
        margin: 0 0.133333rem;
        color: #11e8e3;
        text-shadow: 0 0 5px #11e8e3;
        font-weight: 800;
      }
    }
    .total-cost {
      color: #fff;
      .cost {
        margin: 0.2rem 0.1rem;
        font-size: 0.186667rem;
        color: #03bab5;
      }
      .size {
        color: #fff;
      }
    }
  }
  .container {
    margin-top: -0.133333rem;
    text-align: center;
    .qua{
      padding: .3rem .06rem 0 .06rem;
      font-size: .253333rem;
      // font-weight: 800;

    }
    img {
      margin-top: .266667rem;
        max-width:15px;
        // min-height: .226667rem;
        height: 16px;
        // height: 25%;
      }
    .cost{
      padding: .02rem .02rem .02rem .02rem;
          font-size: .2rem;
          font-weight: 800;
        }
        .size{
           font-size: 0.16rem;
        }
    .water {
      .water-img{
        margin-left:.066667rem;
      }
      .cost{
          color:#00f4be;
        }
      .water-yield,.water-cost{
        padding:0 .133333rem;
      }
    }
    .elec{
      .elec-img{
        margin-left:.066667rem;
      }
      .cost{
          color:#ffbb3e;
        }
      .elec-yield,.elec-cost{
        padding:0 .133333rem;
      }
    }
    .gas{
      .gas-img{
        margin-left:.066667rem;
      }
      .cost{
          color:#ff7f46;
        }
      .gas-yield,.gas-cost{
        padding:0 .133333rem;
      }
    }
     .total{
      .cost{
          color:#db464c;
        }
      .gas-yield,.gas-cost{
        padding:0 .133333rem;
      }
    }
  }

  .chart-box {
    width: 6.24rem;
    height: 2.125rem;
    .active-ring-name {
      padding-top: 0.125rem;
    }
  }
}
</style>
