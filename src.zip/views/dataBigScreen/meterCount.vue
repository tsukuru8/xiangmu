<template>
  <div id="meter">
    <div class="bg-color-black">
      <!-- 标题部分 -->
      <div class="d-flex jc-start title" style="margin: 0 0.1rem">
        <div class="dec">—</div>
        <div style=" font-family: SimHei;">仪表统计</div>
        <div class="dec">—</div>
      </div>
      <!-- 仪表总数 -->
      <div class="d-flex jc-end total-cost">
        <span class="size">仪表总数:</span>
        <span class="cost">{{totalMeter}}</span>
        <span  class="size">台</span>
        <span class="cost line">|</span>
        <span class="size">在线仪表:</span>
        <span class="cost">{{onlineMeter}}</span>
        <span  class="size">台</span>
      </div>
      <!-- 柱状图图例部分 -->
      <div class="d-flex jc-end total-cost">
        <div class="location-item">
          <div class="d-flex">
            <div class="d-flex pdg">
              <div class="dot" style="background-color: #189CEF"></div>
              <div class="text">一厂: </div>
              <div class="d-flex jc-around pdg">
                <div class="number plantOne">{{meterPieChart.first}}</div>
                <div class="textEnd">台</div>
              </div>
            </div>
          </div>
          <div class="d-flex">
            <div class="d-flex pdg">
              <div class="dot" style="background-color: #FFAF35"></div>
              <div class="text">二厂: </div>
              <div class="d-flex jc-around pdg">
                <div class="number plantTwo">{{meterPieChart.second}}</div>
                <div class="textEnd">台</div>
              </div>
            </div>
          </div>

          <div class="d-flex">
            <div class="d-flex pdg">
              <div class="dot" style="background-color: #02F4BA"></div>
              <div class="text">电镀: </div>
              <div class="d-flex jc-around pdg">
                <div class="number plantFour">{{meterPieChart.forth}}</div>
                <div class="textEnd">台</div>
              </div>
            </div>
          </div>

          <div>
            <div class="d-flex pdg">
              <div class="dot" style="background-color: #8F53F3"></div>
              <div class="text">三厂: </div>
              <div class="d-flex jc-around pdg">
                <div class="number plantThree">{{meterPieChart.third}}</div>
                <div class="textEnd">台</div>
              </div>
            </div>
          </div>
          <div>
            <div class="d-flex">
              <div class="d-flex pdg">
                <div class="dot" style="background-color: #114FF2"></div>
                <div class="text">泗洪: </div>
              </div>
              <div class="d-flex jc-around pdg">
                <div class="number plantFive">{{meterPieChart.fifth}}</div>
                <div class="textEnd">台</div>
              </div>
            </div>
          </div>
          </div>

        </div>
      </div>
      <div>
        <meterCountPieChart :chart-data="meterPieChart"/>
      </div>
    </div>
</template>

<script>
  import meterCountPieChart from '../dashboard/dataBigScreenEcharts/meterCountPieChart'
  import {getMeterCountPie} from '../../api/plantThreeEnergyManagement/dataBigScreen/dataBigScreen'

  const meterPieChart = {
    meterPieChartList:{
      first:0,
      second:0,
      third:0,
      forth:0,
      fifth:0,
    }
  }

  export default {
    data() {
      return {
        timer:'',
        totalMeter:0,
        onlineMeter:0,
        meterPieChart: meterPieChart.meterPieChartList
      };
    },
    components: {
      meterCountPieChart
    },
    mounted() {
      this.getMeterPie()
      this.timer = setInterval(()=>{
        this.getMeterPie()
      },60*60*1000)
    },
    beforeDestroy() {
      clearInterval(this.timer);
    },
    methods: {
      getMeterPie(){
        getMeterCountPie().then(response=>{
          let data = response.data
          //仪表总数
          this.totalMeter = data.total
          //在线仪表
          this.onlineMeter = data.online
          //饼图
          this.meterPieChart = data;

        })
      }
    }
  };
</script>

<style lang="scss">
  #meter {
    padding: 0.1rem 0.1rem;
    box-sizing: 7.6648rem;
    height: 3.2rem;
    min-width: 1.75rem;
    border-radius: 0.0625rem;
    .bg-color-black {
      // width: 484.014px;
      border-radius: 0.125rem;
      padding: 0 .2rem;

      .title {
        height: .466667rem;
        color: #fff;
        font-size: .24rem;


        .dec{
          margin:0 .133333rem;
          color: #11E8E3;
          text-shadow: 0 0 5px #11E8E3;
          font-weight: 800;
        }
      }
      .total-cost{
        font-family: SimHei;
        color: #fff;
        .cost{
          // margin: 0 .2rem;
          margin: .093333rem 0.2rem 0 0.2rem;
                font-size: .24rem;
          text-align: center;
          // line-height: .256667rem;
          line-height: .133333rem;
          color: #E6C93D;
          font-weight: 800;
        }
        .line{
          color: #fff;
          font-weight: 400;
        }
        .size{
          font-size: .16rem;
        }
        .location-item {
          position: absolute;
          right: 25%;
          transform: translateX(50%);
          top:80px;
          display: grid;
          grid-template-rows: repeat(20%);
          .pdg {
            // padding: 12px;
            margin:0 .133333rem .133333rem 0;
          }
          .dot {
            margin-right: 0.066667rem;
            width: 0.146667rem;
            height: 0.146667rem;
            border-radius: 0.026667rem;
          }
          .text {
            line-height: 0.172267rem;
          }
          .textEnd {
            line-height: 0.172267rem;
            font-size: .16rem;
          }
          .number {
            padding: 0 0.106667rem;
            line-height: 0.133333rem;
            font-size: 0.24rem;
            text-align: center;
            font-weight: 800;
          }
          .plantOne {
            color: #189CEF;
          }
          .plantTwo {
            color: #FFAF35;
          }
          .plantThree {
            color: #8F53F3;
          }
          .plantFour {
            color: #02F4BA ;
          }
          .plantFive {
            color: #114FF2;
          }
        }
      }
      // .text {
      //   color: #fff;
      // }
      .chart-box {
        // width: 7.266667rem;
        width:6.24rem;
        height: 2.125rem;
        .active-ring-name {
          padding-top: 0.125rem;
        }
      }
    }
    .text {
      color: #c3cbde;
    }
    .chart-box {
      width: 2.125rem;
      height: 2.125rem;
      .active-ring-name {
        padding-top: 0.125rem;
      }
    }
  }
</style>
