<template>
  <div id="mapCenter">
    <div class="bg-color-black">
      <!-- 标题部分 -->
      <div class="d-flex jc-start title" style="margin: 0 0.1rem">
        <div class="dec">—</div>
        <div style="font-family: SimHei">厂区分布</div>
        <div class="dec">—</div>
      </div>
      <!-- 总用量展示区域 -->
      <div class="d-flex jc-around" style="height: 150px">
        <div class="left">
          <div class="d-flex jc-around total-amount cover border">
            <div class="size">水总用量<br />(m³)</div>
            <div class="number">{{ totalWaterUse }}</div>
            <div class="circle"></div>
          </div>
          <div class="d-flex jc-around total-amount cover border">
            <div class="size">电总用量<br />(kw)</div>
            <div class="number e-color">{{ totalElectricUse }}</div>
            <div class="circle"></div>
          </div>
          <div
            class="d-flex jc-around total-amount cover border"
            style="margin-bottom: 0"
          >
            <div class="size">氮气总用量<br />(Nm³)</div>
            <div class="number n-color">{{ totalGasUse }}</div>
            <div class="circle"></div>
          </div>
        </div>
        <!-- 地图区域 -->
        <div class="center">
          <img
            src="../../assets/image/map/map.png"
            style="width: 80%; height: 80%"
          />
        </div>
        <!-- 厂区注释区域 -->
        <div class="right">
          <!-- 天气模块 -->
          <div class="d-flex jc-around wea-all">
            <div class="weatherImg">
              <img v-if="weatherInfo===0"
                src="../../assets/image/weather/100.png"
                style="width: 0.567rem"
              />
              <img v-if="weatherInfo===1"
                   src="../../assets/image/weather/102.png"
                   style="width: 0.567rem"
              />
              <img v-if="weatherInfo===2"
                   src="../../assets/image/weather/104.png"
                   style="width: 0.567rem"
              />
              <img v-if="weatherInfo===3"
                   src="../../assets/image/weather/307.png"
                   style="width: 0.567rem"
              />
              <img v-if="weatherInfo===4"
                   src="../../assets/image/weather/408.png"
                   style="width: 0.567rem"
              />
            </div>
            <div class="weather">
              <div>{{weatherType}}</div>
              <div>{{weatherTemp}}℃</div>
            </div>
          </div>
          <!-- 注释模块 -->
          <div class="location-dor">
            <div class="d-flex location-item">
              <div class="d-flex pdg">
                <div class="dot" style="background-color: #fcd224"></div>
                <div class="text">一厂</div>
              </div>
              <div class="d-flex pdg">
                <div class="dot" style="background-color: #ff8549"></div>
                <div class="text">二厂</div>
              </div>
              <div class="d-flex pdg">
                <div class="dot" style="background-color: #9159ee"></div>
                <div class="text">三厂</div>
              </div>
              <div class="d-flex pdg">
                <div class="dot" style="background-color: #00f4b6"></div>
                <div class="text">电镀</div>
              </div>
              <div class="d-flex pdg">
                <div class="dot" style="background-color: #ff70d4"></div>
                <div class="text">泗洪</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- <div class="d-flex pt-2 pl-2">
        <span style="color:#5cd9e8">
          <icon name="chart-bar"></icon>
        </span>
        <div class="d-flex">
          <span class="fs-xl text mx-2">厂区分布图</span>
        </div>
      </div> -->
      <!-- <div style="float: left">
        <dv-flyline-chart-enhanced :config="config" />
        <img
          src="../../assets/image/map/jsMap.png"
          style="width: 100%; height: 100%"
        />
      </div> -->
      <!-- <div style="float: right">
        <div id="he-plugin-simple"></div>
      </div> -->
    </div>
  </div>
</template>

<script>
import { totalEnergyUse } from "../../api/plantThreeEnergyManagement/dataBigScreen/dataBigScreen";

export default {
  data() {
    return {
      weatherInfo:1,
      timer:'',
      //天气类型
      weatherType:'',
      //天气温度
      weatherTemp:'',
      totalWaterUse: 0,
      totalElectricUse: 0,
      totalGasUse: 0,
    };
  },
  mounted() {
    this.getWeather();
    this.getTotalEnergyUse()
    this.timer = setInterval(()=>{
      this.getWeather()
      this.getTotalEnergyUse()
    },60*60*1000)
  },
  beforeDestroy() {
    clearInterval(this.timer)
  },
  methods: {
    getTotalEnergyUse(){
      totalEnergyUse().then(response =>{
        let data = response.data;
        //电
        this.totalElectricUse = data[0];
        //水
        this.totalWaterUse = data[1];
        //气
        this.totalGasUse = data[2];
        console.log('能源用量---',data)
      })
    },
    //获取天气
    getWeather:async function(){
      let httpUrl1 = `https://devapi.qweather.com/v7/weather/now?location=101190601&key=0ae4d6f821db45088d74ed85270f458c`
      let res1 = await fetch(httpUrl1)
      let result1 = await res1.json()
      let nowWeather = result1.now
      console.log('实时天气',nowWeather)
      this.weatherType = nowWeather.text;
      this.weatherTemp = nowWeather.temp;
      switch (this.weatherType) {
        case '晴':{
          this.weatherInfo = 0
          break;
        }
        case '多云':{
          this.weatherInfo = 2
          break;
        }
        case '下雨':{
          this.weatherInfo = 3
          break;
        }
        case '下雪':{
          this.weatherInfo = 4
          break;
        }
        default:{
          this.weatherInfo = 1
          break;
        }
      }
      //this.tmpNew =now.temp
      //this.briefNew = now.text
    },
  },
};
</script>

<style lang="scss">
#mapCenter {
  padding: 0.1rem 0.1rem;
  box-sizing: 10.5592rem;
  // width: 10.08512rem;
  // height: 3.2rem;
  min-width: 1.75rem;
  border-radius: 0.0625rem;
  font-family: SimHei;
  .bg-color-black {
    position: relative;
    // box-sizing: 3.2rem;
    // height: 3.2rem;
    border-radius: 0.125rem;
    .title {
      height: 0.466667rem;
      color: #fff;
      font-size: 0.24rem;

      .dec {
        margin: 0 0.2rem;
        color: #11e8e3;
        text-shadow: 0 0 5px #11e8e3;
        font-weight: 800;
      }
    }
    .left {
      // margin: 0.373333rem 0.213333rem 0 0.533333rem;
      margin: 0.2rem 0.333333rem 0 0.533333rem;
      width: 2.453333rem;
      height: 2.666667rem;
      .total-amount {
        width: 2.633333rem;
        // height: 0.693333rem;
        height: .626667rem;
        line-height: 0.333333rem;
        border-right: 2px solid #247497;
        border-top: 2px solid #247497;
        color: #fff;
        // border-image: -webkit-linear-gradient(#247497, #20D5FF) 20 20;
        // border-image: -moz-linear-gradient(#247497, #20D5FF) 20 20;

        // border-image: -o-linear-gradient(#247497, #20D5FF) 20 20;

        // border-image: linear-gradient(#247497, #20D5FF) 20 20;
        // background-color: #102d62;
        background: -webkit-linear-gradient(left bottom, #183c70, #0f2757);
        // box-shadow: 0 0 5px #fff;

        font-size: 0.186667rem;

        padding: 0 0.133333rem;
        text-align: center;

        .number {
          // line-height: 0.693333rem;
          line-height: 0.626667rem;
          // font-size: 0.293333rem;
          font-size: 0.24rem;
          color: #00f4be;
          font-weight: 800;
        }
        .size {
          font-size: 0.16rem;
        }
        .circle {
          position: absolute;
          top: 0.053333rem;
          right: 0.08rem;
          width: 0.066667rem;
          height: 0.066667rem;
          background-color: #2ad6ff;
          border-radius: 100%;
        }
        .e-color {
          color: #ffbb3e;
        }
        .n-color {
          color: #ff7f46;
        }
      }
      .cover {
        margin-bottom: .16rem;
      }
      .border {
        position: relative;
      }
      .border::before {
        content: "";
        width: 10px;
        height: 8px;
        position: absolute;
        left: 0;
        bottom: 0;
        border: 8px solid #0f204c;
        border-top-color: transparent;
        border-right-color: transparent;
      }
    }
    .center {
      position: absolute;
      top: 5%;
      left: 58%;
      transform: translate(-50%);
    }
    .right {
      margin: 0.2rem 0.133333rem 0.133333rem 3.066667rem;
      width: 2.666667rem;
      height: 1.466667rem;
      .wea-all {
        position: absolute;
        top: 0.32rem;
        right: 0.533333rem;

        .weather {
          //  margin: 0 .066667rem .266667rem .4rem .066667rem ;
          font-size: 0.213333rem;
          color: #fff;
        }
      }

      .location-dor {
        display: flex;
        flex-direction: column;
        margin-top: 0.4rem;
        font-size: 0.16rem;
        .location-item {
          display: grid;
          grid-template-columns: 50% 50%;
          .pdg {
            padding: 0.125rem;
          }
          .dot {
            margin-right: 0.066667rem;
            width: 0.146667rem;
            height: 0.146667rem;
            border-radius: .026667rem;
          }
          .text {
            line-height: 0.172267rem;
          }
        }
      }
    }
    .text {
      color: #fff;
    }
    .chart-box {
      margin-top: 0.2rem;
      width: 2.125rem;
      height: 2.125rem;
      .active-ring-name {
        padding-top: 0.125rem;
      }
    }
  }
}
</style>
