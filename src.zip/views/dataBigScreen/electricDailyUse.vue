<template>
  <div id="electricDailyUse">
    <div class="bg-color-black">
      <!-- 标题部分 -->
      <div class="d-flex jc-start title" style="margin: 0 0.1rem">
        <div class="dec">—</div>
        <div style="font-family: SimHei">日用量统计：电</div>
        <div class="dec">—</div>
      </div>
      <!--折线图图例-->
      <div class="d-flex jc-end total-cost">
        <span class="cost">—</span>
        <span class="size" v-if="activeName">{{factoryName}}</span>
        <span class="unit">单位：kW·h</span>
      </div>
      <!-- <div class="d-flex pt-2 pl-2">
        <span style="color:#5cd9e8">
          <icon name="chart-bar"></icon>
        </span>
        <div class="d-flex">
          <span class="fs-xl text mx-2">日用量统计：水</span>
        </div>
      </div> -->
      <div>
        <electricDayUseCountLine v-if="activeName" :chart-data="electricDayUseLineChart"/>
      </div>
    </div>
  </div>
</template>

<script>
  import electricDayUseCountLine from '../dashboard/dataBigScreenEcharts/electricDayUseCountLine'
  import {electricDayUseLine} from '../../api/plantThreeEnergyManagement/dataBigScreen/dataBigScreen'
  const electricDayUseLineChart = {
    electricDayUseLineChartList:{
      abscissa:[],
      curList:[],
    }
  }
  export default {
    data() {
      return {
        timer:'',
        activeName:1,
        factoryName:'运营体系',
        electricDayUseLineChart:electricDayUseLineChart.electricDayUseLineChartList
      };
    },
    components: {
      electricDayUseCountLine
    },
    mounted() {
      this.electricDayUseLineData()
      this.timer = setInterval(()=>{
        this.activeName++
        console.log('序号',this.activeName)
        if (this.activeName === 10){
          this.activeName = 1
          console.log('重置序号',this.activeName)
        }
        this.electricDayUseLineData()
      },60*1000)
    },
    beforeDestroy() {
      clearInterval(this.timer);
    },
    methods: {
      electricDayUseLineData(){
        electricDayUseLine().then(response=>{
          let data = response.data
          console.log('日用量电----',data)
          switch (this.activeName) {
            case 1:{
              this.factoryName = '运营体系';
              this.electricDayUseLineChart.abscissa = data.total.abscissa;
              this.electricDayUseLineChart.curList = data.total.curList;
              break;
            }
            case 2:{
              this.factoryName = '四寸晶圆';
              this.electricDayUseLineChart.abscissa = data.fourInch.abscissa;
              this.electricDayUseLineChart.curList = data.fourInch.curList;
              break;
            }
            case 3:{
              this.factoryName = '六寸晶圆';
              this.electricDayUseLineChart.abscissa = data.sixInch.abscissa;
              this.electricDayUseLineChart.curList = data.sixInch.curList;
              break;
            }
            case 4:{
              this.factoryName = '引线器件工厂'
              this.electricDayUseLineChart.abscissa = data.lead.abscissa;
              this.electricDayUseLineChart.curList = data.lead.curList;
              break;
            }
            case 5:{
              this.factoryName = '贴片器件工厂'
              this.electricDayUseLineChart.abscissa = data.paster.abscissa;
              this.electricDayUseLineChart.curList = data.paster.curList;
              break;
            }
            case 6:{
              this.factoryName = '小信号工厂'
              this.electricDayUseLineChart.abscissa = data.smallSignal.abscissa;
              this.electricDayUseLineChart.curList = data.smallSignal.curList;
              break;
            }
            case 7:{
              this.factoryName = '框架桥工厂'
              this.electricDayUseLineChart.abscissa = data.junction.abscissa;
              this.electricDayUseLineChart.curList = data.junction.curList;
              break;
            }
            case 8:{
              this.factoryName = '光伏工厂'
              this.electricDayUseLineChart.abscissa = data.PV.abscissa;
              this.electricDayUseLineChart.curList = data.PV.curList;
              break;
            }
            case 9:{
              this.factoryName = '供应链工厂'
              this.electricDayUseLineChart.abscissa = data.SC.abscissa;
              this.electricDayUseLineChart.curList = data.SC.curList;
              break;
            }
          }
        })
      }
    }
  };
</script>

<style lang="scss">
  #electricDailyUse {
    padding: 0.2rem 0.1rem;
    box-sizing: 5.2rem;
    min-width: 2.75rem;
    border-radius: 0.0625rem;
    .bg-color-black {
      position:relative;
      padding: 0 0.2rem;
      min-width: 2.75rem;
      // height: 5.666667rem;
      border-radius: 0.125rem;
      .title {
        height: 0.466667rem;
        color: #fff;
        font-size: 0.24rem;

        .dec {
          margin: 0 0.1rem;
          color:#11E8E3;
          text-shadow: 0 0 5px #11E8E3;
          font-weight: 800;
        }
      }
      .total-cost {
        font-family: SimHei;
        color: #fff;
        .cost {
          margin: 0 0.2rem;
          font-size: 0.293333rem;
          text-align: center;
          // line-height: .256667rem;
          text-shadow: 0 0 5px #ffb53d;
          color: #ffb53d;
          font-weight: 800;
        }
        .size {
          line-height: .4rem;
          font-size: 0.16rem;
        }
        .unit{
          position:absolute;
          top: 30%;
          left: .386667rem;
          transform: translateY(-50%);
          font-size: 0.16rem;
        }
      }
    }
    .chart-box {
      width: 2.125rem;
      height: 2.125rem;
      .active-ring-name {
        padding-top: 0.125rem;
      }
    }
  }
</style>
