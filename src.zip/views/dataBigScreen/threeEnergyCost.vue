<template>
  <div id="threeEnergyCost">
    <div class="bg-color-black">
      <!-- 标题部分 -->
      <div class="d-flex jc-start title" style="margin: 0 0.1rem">
        <div class="dec">—</div>
        <div style="font-family: SimHei">三类能耗费用月统计</div>
        <div class="dec">—</div>
      </div>
      <!-- 柱状图图例部分 -->
      <div class="d-flex jc-end total-cost">
        <span class="cost">—</span>
        <span class="size" v-if="activeName">{{ factoryName }}</span>
        <span class="unit">单位：元</span>
        <div class="location-item">
          <div class="d-flex">
            <div class="d-flex pdg">
            <div class="dot" style="background-color: #0BF4B3"></div>
            <div class="text">水: </div>
            </div>
           <div class="d-flex jc-around pdg">
            <div class="number water">{{threeEnergyCostPie.water}}</div>
            <div class="text">元</div>
          </div>
          </div>
          <div class="d-flex">
          <div class="d-flex pdg">
            <div class="dot" style="background-color: #ffb53d"></div>
            <div class="text">电: </div>
          </div>
           <div class="d-flex jc-around pdg">
              <div class="number elec">{{threeEnergyCostPie.electric}}</div>
            <div class="text">元</div>
           </div>
          </div>
          <div class="d-flex">
          <div class="d-flex  pdg">
            <div class="dot" style="background-color: #8a59f1"></div>
            <div class="text">氮气:</div>
          </div>
             <div class="d-flex jc-around pdg">
            <div class="number gas">{{threeEnergyCostPie.ngas}}</div>
            <div class="text">元</div>
             </div>
          </div>
          </div>
        </div>
      </div>
      <div>
        <threeEnergyCostPieChart
          v-if="activeName"
          :chart-data="threeEnergyCostPie"
        />
        <day-cost-count-line-chart
          v-if="activeName"
          :chart-data="threeEnergyCostBar"
        />
      </div>
    </div>
</template>

<script>
import threeEnergyCostPieChart from "../dashboard/dataBigScreenEcharts/threeEnergyCostPieChart";
import dayCostCountLineChart from "../dashboard/dataBigScreenEcharts/dayCostCountLineChart";
import {
  getThreeEnergyCostPie,
  getThreeEnergyCostBar,
} from "../../api/plantThreeEnergyManagement/dataBigScreen/dataBigScreen";
const threeEnergyCostBar = {
  threeEnergyCostTotalList: {
    abscissa: [],
    curList: [],
  },
};

const threeEnergyCostPie = {
  threeEnergyCostPieList: {
    water: 0,
    electric: 0,
    ngas: 0,
  },
};
export default {
  data() {
    return {
      timer: "",
      threeEnergyCostBar: threeEnergyCostBar.threeEnergyCostTotalList,
      threeEnergyCostPie: threeEnergyCostPie.threeEnergyCostPieList,
      activeName: 1,
      factoryName: "运营体系",
      /*everyFactory:[
        {
          name:'运营体系',
          value:0
        },
        {
          name:'四寸晶圆',
          value:1
        },
        {
          name:'六寸晶圆',
          value:2
        },
        {
          name:'引线器件工厂',
          value:3
        },
        {
          name:'贴片器件工厂',
          value:4
        },
        {
          name:'小信号工厂',
          value:5
        },
        {
          name:'框架桥工厂',
          value:6
        },
        {
          name:'光伏工厂',
          value:7
        },
        {
          name:'供应链工厂',
          value:8
        },
      ]*/
    };
  },
  components: {
    threeEnergyCostPieChart,
    dayCostCountLineChart,
  },
  computed: {},
  mounted() {
    this.getThreeEnergyCostPieData();
    this.getThreeEnergyCostBarData();
    this.timer = setInterval(() => {
      this.activeName++;
      console.log("序号", this.activeName);
      if (this.activeName === 10) {
        this.activeName = 1;
        console.log("重置序号", this.activeName);
      }
      this.getThreeEnergyCostBarData();
      this.getThreeEnergyCostPieData();
    }, 60 * 1000);
  },
  beforeDestroy() {
    clearInterval(this.timer);
  },
  methods: {
    getThreeEnergyCostPieData() {
      getThreeEnergyCostPie().then((response) => {
        let data = response.data;
        console.log("三类饼图", response.data);
        switch (this.activeName) {
          case 1: {
            this.factoryName = "运营体系";
            this.threeEnergyCostPie.water = data.total.water;
            this.threeEnergyCostPie.electric = data.total.electric;
            this.threeEnergyCostPie.ngas = data.total.ngas;
            break;
          }
          case 2: {
            this.factoryName = "四寸晶圆";
            this.threeEnergyCostPie.water = data.fourInch.water;
            this.threeEnergyCostPie.electric = data.fourInch.electric;
            this.threeEnergyCostPie.ngas = data.fourInch.ngas;
            break;
          }
          case 3: {
            this.factoryName = "六寸晶圆";
            this.threeEnergyCostPie.water = data.sixInch.water;
            this.threeEnergyCostPie.electric = data.sixInch.electric;
            this.threeEnergyCostPie.ngas = data.sixInch.ngas;
            break;
          }
          case 4: {
            this.factoryName = "引线器件工厂";
            this.threeEnergyCostPie.water = data.lead.water;
            this.threeEnergyCostPie.electric = data.lead.electric;
            this.threeEnergyCostPie.ngas = data.lead.ngas;
            break;
          }
          case 5: {
            this.factoryName = "贴片器件工厂";
            this.threeEnergyCostPie.water = data.paster.water;
            this.threeEnergyCostPie.electric = data.paster.electric;
            this.threeEnergyCostPie.ngas = data.paster.ngas;
            break;
          }
          case 6: {
            this.factoryName = "小信号工厂";
            this.threeEnergyCostPie.water = data.smallSignal.water;
            this.threeEnergyCostPie.electric = data.smallSignal.electric;
            this.threeEnergyCostPie.ngas = data.smallSignal.ngas;
            break;
          }
          case 7: {
            this.factoryName = "框架桥工厂";
            this.threeEnergyCostPie.water = data.junction.water;
            this.threeEnergyCostPie.electric = data.junction.electric;
            this.threeEnergyCostPie.ngas = data.junction.ngas;
            break;
          }
          case 8: {
            this.factoryName = "光伏工厂";
            this.threeEnergyCostPie.water = data.PV.water;
            this.threeEnergyCostPie.electric = data.PV.electric;
            this.threeEnergyCostPie.ngas = data.PV.ngas;
            break;
          }
          case 9: {
            this.factoryName = "供应链工厂";
            this.threeEnergyCostPie.water = data.SC.water;
            this.threeEnergyCostPie.electric = data.SC.electric;
            this.threeEnergyCostPie.ngas = data.SC.ngas;
            break;
          }
        }
      });
    },
    getThreeEnergyCostBarData() {
      getThreeEnergyCostBar().then((response) => {
        let data = response.data;
        console.log("三类柱状图", response.data);
        switch (this.activeName) {
          case 1: {
            this.factoryName = "运营体系";
            this.threeEnergyCostBar.abscissa = data.total.abscissa;
            this.threeEnergyCostBar.curList = data.total.curList;
            break;
          }
          case 2: {
            this.factoryName = "四寸晶圆";
            this.threeEnergyCostBar.abscissa = data.fourInch.abscissa;
            this.threeEnergyCostBar.curList = data.fourInch.curList;
            break;
          }
          case 3: {
            this.factoryName = "六寸晶圆";
            this.threeEnergyCostBar.abscissa = data.sixInch.abscissa;
            this.threeEnergyCostBar.curList = data.sixInch.curList;
            break;
          }
          case 4: {
            this.factoryName = "引线器件工厂";
            this.threeEnergyCostBar.abscissa = data.lead.abscissa;
            this.threeEnergyCostBar.curList = data.lead.curList;
            break;
          }
          case 5: {
            this.factoryName = "贴片器件工厂";
            this.threeEnergyCostBar.abscissa = data.paster.abscissa;
            this.threeEnergyCostBar.curList = data.paster.curList;
            break;
          }
          case 6: {
            this.factoryName = "小信号工厂";
            this.threeEnergyCostBar.abscissa = data.smallSignal.abscissa;
            this.threeEnergyCostBar.curList = data.smallSignal.curList;
            break;
          }
          case 7: {
            this.factoryName = "框架桥工厂";
            this.threeEnergyCostBar.abscissa = data.junction.abscissa;
            this.threeEnergyCostBar.curList = data.junction.curList;
            break;
          }
          case 8: {
            this.factoryName = "光伏工厂";
            this.threeEnergyCostBar.abscissa = data.PV.abscissa;
            this.threeEnergyCostBar.curList = data.PV.curList;
            break;
          }
          case 9: {
            this.factoryName = "供应链工厂";
            this.threeEnergyCostBar.abscissa = data.SC.abscissa;
            this.threeEnergyCostBar.curList = data.SC.curList;
            break;
          }
        }
      });
    },
  },
};
</script>

<style lang="scss">
#threeEnergyCost {
    position: relative;
  padding: 0.1rem 0.1rem;
  box-sizing: 5.2rem;
  // width: 10.08512rem;
  // height: 5.84rem;
  min-width: 1.75rem;
  border-radius: 0.0625rem;
  font-family: SimHei;
  .bg-color-black {
    padding: 0 0.2rem;
    // height: 5.666667rem;
    border-radius: 0.125rem;
    .title {
      height: 0.466667rem;
      color: #fff;
      font-size: 0.24rem;

      .dec {
        margin: 0 0.133333rem 0 0;
        color: #11e8e3;
        text-shadow: 0 0 5px #11e8e3;
        font-weight: 800;
      }
    }
    .total-cost {
      font-family: SimHei;
      color: #fff;
      .cost {
        margin: 0 0.2rem;
        font-size: 0.293333rem;
        text-align: center;
        // line-height: .256667rem;
        text-shadow: 0 0 5px #03bab5;
        color: #03bab5;
        font-weight: 800;
      }
      .size {
        line-height: 0.4rem;
        font-size: 0.16rem;
      }
      .unit {
        position: absolute;
        top: 50%;
        left: 0.386667rem;
        transform: translateY(-50%);
        font-size: 0.16rem;
      }
      .location-item {
        position: absolute;
        right: 30%;
        transform: translateX(50%);
        top:80px;
        display: grid;
        grid-template-rows: repeat(33.33%);
        .pdg {
          // padding: 12px;
          margin:.133333rem .133333rem .133333rem 0;
        }
        .dot {
          margin-right: 0.066667rem;
          width: 0.146667rem;
          height: 0.146667rem;
          border-radius: 0.026667rem;
        }
        .text {
          line-height: 0.172267rem;
        }
        .number {
          padding: 0 0.106667rem;
          line-height: 0.133333rem;
          font-size: 0.24rem;
          text-align: center;
          font-weight: 800;
        }
        .water {
          color: #0bf2be;
        }
        .elec {
          color: #ffb53d;
        }
        .gas {
          color: #8a59f1 ;
        }
      }
    }
  }

  .chart-box {
    width: 2.125rem;
    height: 2.125rem;
    // height: 1.946667rem;
    .active-ring-name {
      padding-top: 0.125rem;
    }
  }
  .seamless {
    width: 52px;
    height: 25px;
    overflow: hidden;
  }
}
</style>
