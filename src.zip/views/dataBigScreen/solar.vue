<template>
  <div id="solar">
    <div class="bg-color-black" style="margin: 0">
      <!-- 标题部分 -->
      <div class="d-flex jc-start title" style="margin: 0 0.1rem">
        <div class="dec">—</div>
        <div style="font-family: SimHei">太阳能发电统计</div>
        <div class="dec">—</div>
      </div>
      <!-- 柱状图图例部分 -->
      <div class="d-flex jc-end total-cost">
        <span class="cost">—</span>
        <span class="size">太阳能每日总发电量</span>
        <span class="unit">单位：kW·h</span>
         <div class="location-item">
          <div class="d-flex">
            <div class="d-flex pdg">
            <div class="dot" style="background-color: #0BF2BE"></div>
            <div class="text">二厂: </div>
            </div>
           <div class="d-flex jc-around pdg">
            <div class="number water">{{solarPie.CIC}}</div>
            <div class="textEnd">kW·h</div>
          </div>
          </div>
          <div class="d-flex">
          <div class="d-flex pdg">
            <div class="dot" style="background-color: #FF8444"></div>
            <div class="text">三厂: </div>
          </div>
           <div class="d-flex jc-around pdg">
              <div class="number elec">{{solarPie.CIT}}</div>
            <div class="textEnd">kW·h</div>
           </div>
          </div>
          <div class="d-flex">
          <div class="d-flex  pdg">
            <div class="dot" style="background-color: #1F95F5"></div>
            <div class="text">园区:</div>
          </div>
             <div class="d-flex jc-around pdg">
            <div class="number gas">{{solarPie.park}}</div>
            <div class="textEnd">kW·h</div>
             </div>
          </div>
          </div>
      </div>
      <div>
        <solar-pie-chart :chart-data="solarPie" />
        <solarBarChart :chart-data="solarBar" />
      </div>
    </div>
  </div>
</template>

<script>
import solarBarChart from "../dashboard/dataBigScreenEcharts/solarBarChart";
import solarPieChart from "../dashboard/dataBigScreenEcharts/solarPieChart";
import {
  solarPieData,
  solarBarData,
} from "../../api/plantThreeEnergyManagement/dataBigScreen/dataBigScreen";

const solarPie = {
  solarPieList: {
    CIC: 0,
    CIT: 0,
    park: 0,
  },
};
const solarBar = {
  solarBarList: {
    abscissa: [],
    curList: [],
  },
};
export default {
  data() {
    return {
      solarPie: solarPie.solarPieList,
      solarBar: solarBar.solarBarList,
    };
  },
  components: {
    solarBarChart,
    solarPieChart,
  },
  mounted() {
    this.getSolarPieData();
    this.getSolarBarData();
    this.timer = setInterval(()=>{
      this.getSolarPieData();
      this.getSolarBarData();
    },60*60*1000)
  },
  methods: {
    //柱状图数据
    getSolarBarData() {
      solarBarData().then((response) => {
        let data = response.data;
        this.solarBar.abscissa = data.Result.abscissa;
        this.solarBar.curList = data.Result.curList;
      });
    },
    //饼图数据
    getSolarPieData() {
      solarPieData().then((response) => {
        let data = response.data;
        this.solarPie = data;
        console.log(response.data);
      });
    },
  },
};
</script>

<style lang="scss">
#solar {
  padding: 0.1rem 0.1rem;
  min-width: 1.75rem;
  border-radius: 0.0625rem;
  .bg-color-black {
    position: relative;
    padding: 0 0.2rem;
    // width: 484.014px;
    border-radius: 0.125rem;

    .title {
      height: 0.466667rem;
      color: #fff;
      font-size: 0.24rem;
      .dec {
        margin: 0 0.133333rem;
        color: #11e8e3;
        text-shadow: 0 0 5px #11e8e3;
        font-weight: 800;
      }
    }
    .total-cost {
      font-family: SimHei;
      color: #fff;
      .cost {
        margin: 0 0.2rem;
        font-size: 0.293333rem;
        text-align: center;
        // line-height: .256667rem;
        text-shadow: 0 0 5px #03bab5;
        color: #03bab5;
        font-weight: 800;
      }
      .size {
        line-height: 0.4rem;
        font-size: 0.16rem;
      }
      .unit{
        position:absolute;
        top: 50%;
        left: .386667rem;
        transform: translateY(-50%);
        font-size: 0.16rem;
      }
       .location-item {
        position: absolute;
        right: 30%;
        transform: translateX(50%);
        top:80px;
        display: grid;
        grid-template-rows: repeat(33.33%);
        .pdg {
          // padding: 12px;
          margin:.133333rem .133333rem .133333rem 0;
        }
        .dot {
          margin-right: 0.066667rem;
          width: 0.146667rem;
          height: 0.146667rem;
          border-radius: 0.026667rem;
        }
        .text {
          line-height: 0.172267rem;
        }
        .textEnd {
          line-height: 0.172267rem;
          font-size: 0.16rem;
        }
        .number {
          padding: 0 0.106667rem;
          line-height: 0.133333rem;
          font-size: 0.24rem;
          text-align: center;
          font-weight: 800;
        }
        .water {
          color: #0bf2be;
        }
        .elec {
          color: #FF8444;
        }
        .gas {
          color: #1DA2E7 ;
        }
      }
    }
  }
  // .text {
  //   color: #c3cbde;
  // }
  .chart-box {
    width: 2.125rem;
    height: 2.125rem;
    .active-ring-name {
      padding-top: 0.125rem;
    }
  }
}
</style>

