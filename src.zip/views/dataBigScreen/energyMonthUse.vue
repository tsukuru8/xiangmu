<template>
  <div id="energyMonthUse">
    <div class="bg-color-black">
      <!-- 标题部分 -->
      <div class="d-flex jc-start title" style="margin: 0 0.1rem">
        <div class="dec">—</div>
        <div style="font-family: SimHei">月用量统计</div>
        <div class="dec">—</div>
      </div>
      <!-- <div class="d-flex pt-2 pl-2">
        <span style="color:#5cd9e8">
          <icon name="chart-bar"></icon>
        </span>
        <div class="d-flex">
          <span class="fs-xl text mx-2">月用量统计</span>
        </div>
      </div> -->
      <div class="d-flex container">
        <div>
          <month-use-water-donut-chart :chart-data="monthUseWater" />
        </div>
        <div>
          <month-use-electric-donut-chart :chart-data="monthUseElectric" />
        </div>
        <div>
          <month-use-gas-donut-chart :chart-data="monthUseGas" />
        </div>
      </div>
      <!--图例-->
      <div class="legend">
        <div class="d-flex location-item">
          <div class="d-flex pdg">
            <div class="dot" style="background-color: #00fcb7"></div>
            <div class="text">四寸晶圆</div>
          </div>
          <div class="d-flex pdg">
            <div class="dot" style="background-color: #ffb331"></div>
            <div class="text">六寸晶圆</div>
          </div>
          <div class="d-flex pdg">
            <div class="dot" style="background-color: #1896ed"></div>
            <div class="text">小信号工厂</div>
          </div>
          <div class="d-flex pdg">
            <div class="dot" style="background-color: #f38e62"></div>
            <div class="text">框架桥工厂</div>
          </div>
          <div class="d-flex pdg">
            <div class="dot" style="background-color: #8b66f2"></div>
            <div class="text">光伏工厂</div>
          </div>
          <div class="d-flex pdg">
            <div class="dot" style="background-color: #1055d6"></div>
            <div class="text">供应链工厂</div>
          </div>
        </div>
        <div class="d-flex jc-center double-glend">
          <div class="d-flex pdg">
            <div class="dot" style="background-color: #db464c"></div>
            <div class="text">引线器件工厂</div>
          </div>
          <div class="d-flex pdg">
            <div class="dot" style="background-color: #01cbdf"></div>
            <div class="text">贴片器件工厂</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import monthUseElectricDonutChart from "../dashboard/dataBigScreenEcharts/monthUseElectricDonutChart";
import monthUseWaterDonutChart from "../dashboard/dataBigScreenEcharts/monthUseWaterDonutChart";
import monthUseGasDonutChart from "../dashboard/dataBigScreenEcharts/monthUseGasDonutChart";
import {
  waterMonthUseData,
  electricMonthUseData,
  gasMonthUseData,
} from "../../api/plantThreeEnergyManagement/dataBigScreen/dataBigScreen";

const monthUseElectric = {
  monthUseElectricList: {
    first: 1,
    second: 2,
    third: 3,
    forth: 4,
    fifth: 5,
    sixth: 6,
    senth: 7,
    eighth: 8,
  },
};
const monthUseWater = {
  monthUseWaterList: {
    first: 1,
    second: 2,
    third: 3,
    forth: 4,
    fifth: 5,
    sixth: 6,
    senth: 7,
    eighth: 8,
  },
};
const monthUseGas = {
  monthUserGasList: {
    first: 1,
    second: 2,
    third: 3,
    forth: 4,
    fifth: 5,
    sixth: 6,
    senth: 7,
    eighth: 8,
  },
};
export default {
  data() {
    return {
      timer:'',
      monthUseElectric: monthUseElectric.monthUseElectricList,
      monthUseWater: monthUseWater.monthUseWaterList,
      monthUseGas: monthUseGas.monthUserGasList,
    };
  },
  components: {
    monthUseElectricDonutChart,
    monthUseWaterDonutChart,
    monthUseGasDonutChart,
  },
  mounted() {
    this.getMonthUseWater();
    this.getMonthUseElectric();
    this.getMonthUseGas();
    this.timer = setInterval(()=>{
      this.getMonthUseWater();
      this.getMonthUseElectric();
      this.getMonthUseGas();
    },60*60*1000)
  },
  beforeDestroy() {
    clearInterval(this.timer);
  },
  methods: {
    //水
    getMonthUseWater() {
      waterMonthUseData().then((response) => {
        console.log("水月用量饼图", response.data);
        this.monthUseWater = response.data;
      });
    },
    //电
    getMonthUseElectric() {
      electricMonthUseData().then((response) => {
        console.log("电月用量饼图", response.data);
        this.monthUseElectric = response.data;
      });
    },
    //气
    getMonthUseGas() {
      gasMonthUseData().then((response) => {
        console.log("气月用量饼图", response.data);
        this.monthUseGas = response.data;
      });
    },
  },
};
</script>

<style lang="scss">
#energyMonthUse {
  padding: 0.1rem 0.1rem;
  // box-sizing: 3.46rem;
  // height: 3.46rem;
  min-width: 1.75rem;
  border-radius: 0.0625rem;
  font-family: SimHei;
  .bg-color-black {
  // box-sizing: 3.46rem;
    border-radius: 0.125rem;
    .title {
      height: 0.466667rem;
      color: #fff;
      font-size: 0.24rem;

      .dec {
        margin: 0 0.133333rem;
        color: #11e8e3;
        text-shadow: 0 0 5px #11e8e3;
        font-weight: 800;
      }
    }
    .container {
      margin: .066667rem 0.2rem 0 .2rem;
      display: grid;
      grid-template-columns: repeat(3, 33.3%);
    }
    .legend {
      display: flex;
      flex-direction: column;
      margin: 0 .2rem;
      font-size: .133333rem;

      .location-item {
        display: grid;
        grid-template-columns: repeat(6, 16.6%);
        .pdg {
          padding: 0.066667rem;
        }
        .dot {
          margin-right: 0.066667rem;
          width: 0.146667rem;
          height: 0.146667rem;
          border-radius: .026667rem;
        }
        .text {
          line-height: .172267rem;
        }
      }
      .double-glend{
        margin: .106667rem 0;
        .pdg {
          padding: 0.066667rem;
        }
        .dot {
          margin-right: 0.066667rem;
          width: 0.146667rem;
          height: 0.146667rem;
          border-radius: .026667rem;
        }
        .text {
          line-height: 0.172267rem;
        }
      }
    }
    .chart-box {
      width: 2.125rem;
      height: 2.125rem;
      .active-ring-name {
        padding-top: 0.125rem;
      }
    }
  }
}
</style>
