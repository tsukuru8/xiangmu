<template>

</template>

<script>
    export default {
        name: "usageStatistics"
    }
</script>

<style scoped>

</style>
