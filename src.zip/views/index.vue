<template>
  <div id="index">
    <div class="bg">

      <div class="host-body">
        <div class="top">
          <!-- 标题内容区域 -->
          <div class="d-flex jc-center">
            <dv-decoration-6
              style="width: 4.653333rem; height: 0.2rem; margin: 0.3rem 0"
            />
            <div class="d-flex jc-center title">
              <img src="../assets/image/logo.png" alt="" />
              <span class="title-text">扬州泰富能源数据大屏</span>
            </div>
            <div class="d-flex jc-around">
              <dv-decoration-6
                style="width: 4.653333rem; height: 0.2rem; margin: 0.3rem 0"
              />
              <!-- 时间区域 -->
              <div class="d-flex jc-center time">
                <div class="top-time">{{time.dateTime}}</div>
                <div class="top-date">
                  <div>{{time.week}}</div>
                  <div>{{time.day}}</div>
                </div>
              </div>
            </div>
          </div>
          <!-- 标题下边框线 -->
          <div class="d-flex jc-center" style="margin-top: -0.4rem">
            <dv-decoration-10 style="width: 33.3%; height: 0.0625rem" />
            <div class="d-flex jc-center">
              <dv-decoration-8
                :color="['#34c8ff', 'rgba(255,0,0,0)']"
                style="mragin: 0; width: 4rem; height: 0.625rem"
              />

              <dv-decoration-8
                :reverse="true"
                :color="['#34c8ff', 'rgba(255,0,0,0)']"
                style="mragin: 0; width: 4rem; height: 0.625rem"
              />
            </div>
            <dv-decoration-10
              style="
                width: 33.3%;
                height: 0.0625rem;
                transform: rotateY(180deg);
              "
            />
          </div>
        </div>
        <!-- 第二行 -->
        <!-- <div class="d-flex jc-between px-3">
          <div class="d-flex" style="width: 40%">
            <div class="react-left ml-4"></div> -->
        <!--<div class="react-left ml-3">
              <span class="text colorBlue">2020年10月1日</span>
            </div>-->
        <!-- </div>
          <div style="width: 40%" class="d-flex"> -->
        <!--<div class="react-left mr-3">
              <span class="text colorBlue">星期四 16:28:20</span>
            </div>-->
        <!--            <div-->
        <!--              class="react-left mr-4"-->
        <!--              style="width: 6.25rem; background-color: #0f1325; text-align: right;"-->
        <!--            >-->
        <!--              <span class="react-after"></span>-->
        <!--              <span class="text"></span>-->
        <!--            </div>-->
        <!-- </div>
        </div> -->
        <!-- 大屏第一行模块 -->
        <div class="body-box">
          <div class="content-box">
            <!--各事业部费用月统计-->
            <div class="first-box" style="margin-left: 0.373333rem">
              <dv-border-box-12 :key="keyData"
                :color="['#128799', '#22E6E5']"
                backgroundColor="#0F204C"
              >
                <div>
                  <totalCost />
                </div>
              </dv-border-box-12>
            </div>

            <!-- 厂区分布 -->
            <div class="first-box">
              <dv-border-box-12
                :color="['#128799', '#22E6E5']"
                backgroundColor="#0F204C"
              >
                <div>
                  <mapCenter />
                </div>
              </dv-border-box-12>
            </div>
            <!-- 仪表统计 -->
            <div style="margin-right: 0.373333rem">
              <dv-border-box-12
                :color="['#128799', '#22E6E5']"
                backgroundColor="#0F204C"
              >
                <div>
                  <meter-count />
                </div>
              </dv-border-box-12>
            </div>
          </div>
          <!--大屏第二行模块-->
          <div class="center-box">
            <!--三类能耗费用日统计-->
            <div class="first-box" style="margin-left: 0.373333rem">
              <dv-border-box-12
                :color="['#128799', '#22E6E5']"
                backgroundColor="#0F204C"
              >
                <div>
                  <threeEnergyCost />
                </div>
              </dv-border-box-12>
            </div>
            <div>
              <div class="center-center-box">
                <!-- 月用量统计 -->
                <div class="first-box">
                  <dv-border-box-12
                    :color="['#128799', '#22E6E5']"
                    backgroundColor="#0F204C"
                  >
                    <div>
                      <energyMonthUse />
                    </div>
                  </dv-border-box-12>
                </div>
                <!-- 日报统计 -->
                <div class="second-box" style="margin-top: 0.173333rem">
                  <dv-border-box-12
                    :color="['#128799', '#22E6E5']"
                    backgroundColor="#0F204C"
                  >
                    <div>
                      <dailyReport />
                    </div>
                  </dv-border-box-12>
                </div>
              </div>
            </div>
            <!-- 太阳能发电统计 -->
            <div class="first-box" style="margin-right: 0.373333rem">
              <dv-border-box-12
                :color="['#128799', '#22E6E5']"
                backgroundColor="#0F204C"
              >
                <div>
                  <solar />
                </div>
              </dv-border-box-12>
            </div>
          </div>

          <!--底部-->
          <div class="bottom-box">
            <!--异常分析-->
            <div class="first-box" style="margin-left: 0.373333rem; margin-bottom: 0.5rem">
              <dv-border-box-12
                :color="['#128799', '#22E6E5']"
                backgroundColor="#0F204C"
              >
                <div>
                  <abnormal-count />
                </div>
              </dv-border-box-12>
            </div>
            <!--日用量统计 水-->
            <div class="first-box" style=" margin:0 0.133333rem 0.5rem 0.133333rem;">
              <dv-border-box-12
                :color="['#128799', '#22E6E5']"
                backgroundColor="#0F204C"
              >
                <div>
                  <water-daily-use />
                </div>
              </dv-border-box-12>
            </div>
            <!--日用量统计 电-->
            <div class="first-box" style=" margin:0 0.133333rem 0.5rem 0;">
              <dv-border-box-12
                :color="['#128799', '#22E6E5']"
                backgroundColor="#0F204C"
              >
                <div>
                  <electric-daily-use />
                </div>
              </dv-border-box-12>
            </div>
            <!--日用量统计 氮气-->
            <div style="margin:0 0.373333rem 0.5rem 0;">
              <dv-border-box-12
                :color="['#128799', '#22E6E5']"
                backgroundColor="#0F204C"
              >
                <div>
                  <gas-daily-use />
                </div>
              </dv-border-box-12>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</template>

<script>
  import dayjs from 'dayjs'
import totalCost from "./dataBigScreen/totalCost";
import meterCount from "./dataBigScreen/meterCount";
import threeEnergyCost from "./dataBigScreen/threeEnergyCost";
import energyMonthUse from "./dataBigScreen/energyMonthUse";
import solar from "./dataBigScreen/solar";
import mapCenter from "./dataBigScreen/mapCenter";
import dailyReport from "./dataBigScreen/dailyReport";
import abnormalCount from "./dataBigScreen/abnormalCount";
import waterDailyUse from "./dataBigScreen/waterDailyUse";
import electricDailyUse from './dataBigScreen/electricDailyUse'
import gasDailyUse from "./dataBigScreen/gasDailyUse";
  import dayCostCountLineChart from './dashboard/dataBigScreenEcharts/dayCostCountLineChart'
export default {
  name: "Index",
  components: {
    totalCost,
    meterCount,
    threeEnergyCost,
    energyMonthUse,
    electricDailyUse,
    solar,
    dailyReport,
    abnormalCount,
    mapCenter,
    waterDailyUse,
    gasDailyUse,
  },
  data() {
    return {
      keyData:'',
      //定时器
      timer:'',
      time:{
        dateTime:'15:30:30',
        week:'星期日',
        day:'2021-01-01'
      },
      config3: {
        data: [
          {
            value: "60%",
          },
        ],
      },
      water: {
        data: [24, 45],
        shape: "roundRect",
        formatter: "{value}%",
        waveNum: 3,
      },
    };
  },
  computed:{
    timeDefault_instant(){
      this.dateRange_instant = dayjs().format('YYYY-MM-DD HH:mm:ss'); //将值设置给插件绑定的数据
      console.log('当前时间',this.dateRange_instant)
    }
  },
  created() {
    window.addEventListener('resize',this.getWindow)
  },
  mounted() {
    this.getNowDate();
    this.timer = setInterval(()=>{
      console.log('执行定时任务----')
      this.getNowDate();
    },1000)
    //this.loading = false
  },
  beforeDestroy() {
    clearInterval(this.timer);
  },
  destroyed() {
    window.removeEventListener('resize',this.getWindow)
  },
  methods: {
    getWindow(){
      let innerWidth = window.innerWidth
      //location. reload()
    },
    // 获取当前时间
    getNowDate(){
      let nowTime = dayjs().format('YYYY-MM-DD HH:mm:ss'); //将值设置给插件绑定的数据
      this.time.dateTime = nowTime.substring(11,19)
      this.time.day = nowTime.substring(0,11).replace(/\-/g,'/')
      let weekData = dayjs().day()
      let str = '';
      switch (weekData) {
          case 1:
           str = '星期一';
           break;
          case 2:
            str ='星期二';
            break;
          case 3:
            str ='星期三';
            break;
          case 4:
            str ='星期四';
            break;
          case 5:
            str ='星期五';
            break;
          case 6:
            str ='星期六';
            break;
          case 0:
            str = '星期日';
      }
      this.time.week = str;
    },
  },
};
</script>

<style lang="scss">
@import "../assets/scss/index.scss";
@import "../assets/scss/style.scss";
img {
  margin: 0 0.133333rem 0 0;
  width: 0.946667rem;
  height: 0.56rem;
}
.time {
  // margin: 0 0.5rem ;
  position: absolute;
  right: 0.266667rem;
  top: 0.133333rem;
}
.top-time {
  margin-right: 0.2rem;
  line-height: 0.666667rem;
  font-size: 0.35rem;
}
.top-date {
  font-size: 0.2rem;
  text-align: center;
}
.body-box {
  .content-box {
    // height: 281px;
    // box-sizing: 3.746667rem;
    height: 3.2rem; //240px
    .first-box {
      height: 3.2rem;
      margin-right: 0.133333rem;
      .dv-border-box-12 {
        // box-sizing: 3.2rem;
        height: 3.2rem;
        .dv-border-svg-container {
          height: 3.2rem;
        }
      }
    }
  }
  .center-box {
    .first-box {
      // height: 441.84px;
      height: 5.43rem;
      margin-right: 0.133333rem;
      .dv-border-box-12 {
        // box-sizing: 5.8rem;
        height: 5.43rem;
        .dv-border-svg-container {
          // box-sizing: 435;
          height: 5.43rem;
        }
      }
    }
    .center-center-box {
      // height: 441.84px;
      .first-box {
        // height: 282px;
        height: 3.36rem;
        .dv-border-box-12 {
          // box-sizing: 5.8rem;
          height: 3.36rem;
          .dv-border-svg-container {
            // box-sizing: 435;
            height: 3.36rem;
          }
        }
      }
      .second-box {
        // height: 101px;
        height: 1.7rem;
        margin-right: 0.133333rem;
        .dv-border-box-12 {
          // box-sizing: 5.8rem;
          height: 1.9rem;
          .dv-border-svg-container {
            // box-sizing: 435;
            height: 1.9rem;
          }
        }
      }
    }
  }
}
</style>
