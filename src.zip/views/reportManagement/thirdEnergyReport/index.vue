<template>
  <el-container class="all">
    <el-row :gutter="1" style="width: 100%;padding: 50px 50px 0 50px;height:100%">
      <el-col :span="12" :xs="12" style="text-align: center">
        <h2>每日水电明细统计:</h2>
      </el-col>
      <el-col :span="12" :xs="12" style="text-align: left">
        <el-form
          :inline="true"
          :model="dayForm"
          :rules="rules"
          label-width="10px"
          ref="elForm"
          size="small"
        >
          <el-form-item>
            <el-date-picker
              align="right"
              placeholder="日期"
              type="date"
              unlink-panels
              v-model="dayForm.dateForDay"
              value-format="yyyy-MM-dd"
            />
          </el-form-item>
          <el-form-item size="small">
            <el-button @click="handleThirdDayRp" icon="el-icon-download" type="warning"
                       v-loading.fullscreen.lock="fullscreenLoading">
              导出
            </el-button>
          </el-form-item>
        </el-form>
      </el-col>

      <el-col :span="12" :xs="12" style="text-align: center">
        <h2>3厂月水电气用量明细统计:</h2>
      </el-col>
      <el-col :span="12" :xs="12" style="text-align: left">
        <el-form
          :inline="true"
          :model="monthForm"
          :rules="rules"
          label-width="10px"
          ref="elForm"
          size="small"
        >
          <el-form-item>
            <el-date-picker
              align="right"
              placeholder="日期"
              type="date"
              unlink-panels
              v-model="monthForm.dateForMonth"
              value-format="yyyy-MM-dd"
            />
          </el-form-item>
          <el-form-item size="small">
            <el-button @click="handleThirdMonthRp" icon="el-icon-download" type="warning"
                       v-loading.fullscreen.lock="fullscreenLoading">
              导出
            </el-button>
          </el-form-item>
        </el-form>
      </el-col>

      <el-col :span="12" :xs="12" style="text-align: center">
        <h2>2厂月水电氮气用量分摊统计:</h2>
      </el-col>
      <el-col :span="12" :xs="12" style="text-align: left">
        <el-form
          :inline="true"
          :model="monthFormOfTwoFty"
          :rules="rules"
          label-width="10px"
          ref="elForm"
          size="small"
        >
          <el-form-item>
            <el-date-picker
              align="right"
              placeholder="日期"
              type="date"
              unlink-panels
              v-model="monthFormOfTwoFty.dateForMonth"
              value-format="yyyy-MM-dd"
            />
          </el-form-item>
          <el-form-item size="small">
            <el-button @click="handleSecondMonthRp" icon="el-icon-download" type="warning"
                       v-loading.fullscreen.lock="fullscreenLoading">
              导出
            </el-button>
          </el-form-item>
        </el-form>
      </el-col>

    </el-row>
  </el-container>
</template>

<script>
  import dayjs from 'dayjs'
  import {
    exportSecondFtyRpForMonth,
    exportThirdFtyRpForDay,
    exportThirdFtyRpForMonth
  } from "../../../api/reportManagement";

  export default {
    name: "thirdEnergyReport",
    components: {},
    data() {
      return {
        fullscreenLoading: false,
        dayForm: {
          //dateForDay: dayjs().format('YYYY-MM-DD'),
          dateForDay: dayjs(dayjs().add(-1, 'day').toString()).format('YYYY-MM-DD')
        },
        monthForm: {
          dateForMonth: dayjs().format('YYYY-MM-DD'),
        },
        monthFormOfTwoFty:{
          dateForMonth: dayjs().format('YYYY-MM-DD'),
        },
        rules: {},
      };
    },
    computed: {},
    created() {
    },
    mounted() {
    },
    methods: {
      handleThirdDayRp() {
        const {dateForDay} = this.dayForm
        const param = {
          monthParm: dateForDay
        }
        this.fullscreenLoading = true;
        exportThirdFtyRpForDay(param)
          .then((response) => {
            this.download(response.msg);
          })
          .finally(() => {
            this.fullscreenLoading = false;
          });
      },
      handleThirdMonthRp() {
        const {dateForMonth} = this.monthForm
        const param = {
          monthParm: dateForMonth
        }
        this.fullscreenLoading = true;
        exportThirdFtyRpForMonth(param)
          .then((response) => {
            this.download(response.msg);
          })
          .finally(() => {
            this.fullscreenLoading = false;
          });
      },
      handleSecondMonthRp() {
        const {dateForMonth} = this.monthFormOfTwoFty
        const param = {
          monthParm: dateForMonth
        }
        this.fullscreenLoading = true;
        exportSecondFtyRpForMonth(param)
          .then((response) => {
            this.download(response.msg);
          })
          .finally(() => {
            this.fullscreenLoading = false;
          });
      }
    }
  }

</script>

<style scoped>
  .all {
    background: #fff;
  }
</style>
