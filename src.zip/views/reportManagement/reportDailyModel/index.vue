<template>
  <div class="app-container">
    <el-row :gutter="20">
      <el-col :span="24" :xs="24" class="all-center">
        <h1>每日水电明细统计-模板管理</h1>
      </el-col>
      <el-col :span="6" :xs="6">
        &nbsp;
      </el-col>
      <el-col :span="6" :xs="6" class="all-center">
        <h2>报表日期:</h2>
      </el-col>
      <el-col :span="12" :xs="12" class="all-left">
        <el-form
          :inline="true"
          :model="dayForm"
          :rules="rules"
          label-width="10px"
          ref="elForm"
          size="small"
        >
          <el-form-item>
            <el-date-picker
              align="right"
              placeholder="日期"
              type="date"
              unlink-panels
              v-model="dayForm.dateForDay"
              value-format="yyyy-MM-dd"
              @blur="getRpModelDailyList"
              :picker-options="pickerOptions"
            />
          </el-form-item>
          <el-form-item size="small">
            <el-button @click="handleThirdDayRp" icon="el-icon-download" type="warning"
                       v-loading.fullscreen.lock="fullscreenLoading">
              导出
            </el-button>
          </el-form-item>
          <el-form-item size="small">
            <el-button @click="getRpModelDailyList" icon="el-icon-search" type="primary" :loading="btnLoading">
              查询
            </el-button>
          </el-form-item>
        </el-form>
      </el-col>

      <el-col :span="6" :xs="6">
        &nbsp;
      </el-col>
      <el-col :span="6" :xs="6" class="all-center">
        <h2>模板导入:</h2>
      </el-col>
      <el-col :span="12" :xs="12" class="all-left">
        <el-button
          type="info"
          icon="el-icon-upload2"
          size="mini"
          @click="handleImport"
        >导入
        </el-button>
      </el-col>

      <el-col :span="24" :xs="24">
        <el-main v-loading="tableLoading" element-loading-text="拼命加载中" style="width: 100%;">
          <el-table
            :data="tableData"
            stripe
            border
            style="width: 92%; margin-left: 3%"
          >
            <el-table-column
              align="center"
              prop="max"
              label="操作"
            >
              <template slot-scope="scope">
                <el-button @click="downloadModel(scope.row.id)" type="text" size="small" icon="el-icon-download">下载
                </el-button>
              </template>

            </el-table-column>
            <el-table-column
              align="center"
              prop="modelDate"
              label="模板日期"
            ></el-table-column>
            <el-table-column
              align="center"
              prop="modelName"
              label="模板名称"
            ></el-table-column>
            <el-table-column
              align="center"
              prop="modelSource"
              label="模板来源"
            >
              <template slot-scope="scope">
                <el-tag
                  :type="scope.row.modelSource == '1' ? 'primary' : 'success'"
                  disable-transitions>{{scope.row.modelSource=='1'?'用户上传':'系统生成'}}
                </el-tag>
              </template>

            </el-table-column>
            <el-table-column
              align="center"
              prop="createName"
              label="上传人"
            ></el-table-column>
            <el-table-column
              align="center"
              prop="createTime"
              label="上传时间"
            ></el-table-column>
          </el-table>
        </el-main>
      </el-col>
    </el-row>

    <!-- 用户导入对话框 -->
    <el-dialog :title="upload.title" :visible.sync="upload.open" width="400px" append-to-body>
      <el-upload
        ref="upload"
        :limit="1"
        accept=".xlsx, .xls"
        :headers="upload.headers"
        :action="upload.url"
        :disabled="upload.isUploading"
        :on-progress="handleFileUploadProgress"
        :on-success="handleFileSuccess"
        :auto-upload="false"
        :data="{rpModelDate:dayForm.dateForDay}"
        drag
      >
        <i class="el-icon-upload"></i>
        <div class="el-upload__text">
          将文件拖到此处，或
          <em>点击上传</em>
        </div>
        <div class="el-upload__tip" style="color:red" slot="tip">提示：仅允许导入“xls”或“xlsx”格式文件！</div>
      </el-upload>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitFileForm">确 定</el-button>
        <el-button @click="upload.open = false">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import dayjs from 'dayjs'
  import {downloadRpModelDaily, exportThirdFtyRpForDay, getRpModelDailyList} from "../../../api/reportManagement";
  import {getToken} from '@/utils/auth'

  export default {
    name: "reportDailyModel",
    components: {},
    data() {
      return {
        fullscreenLoading: false,
        btnLoading: false,
        tableLoading: false,
        dayForm: {
          //dateForDay: dayjs().format('YYYY-MM-DD'),
          dateForDay: dayjs(dayjs().add(0, 'day').toString()).format('YYYY-MM-DD')
        },
        rules: {},
        tableData: [],
        // 模板导入参数
        upload: {
          // 是否显示弹出层
          open: false,
          // 弹出层标题
          title: "日报表模板导入",
          // 是否禁用上传
          isUploading: false,
          // 设置上传的请求头部
          headers: {Authorization: "Bearer " + getToken()},
          // 上传的地址
          url: process.env.VUE_APP_BASE_API + "/reportModel/uploadDailyModel?modelSource=1"
        },
        pickerOptions:{
          disabledDate (time) {
            return time.getTime() > (Date.now() - (24 * 60 * 60 * 1000))
          }
        }
      };
    },
    computed: {},
    created() {
      this.getRpModelDailyList()
    },
    mounted() {

    },
    methods: {
      handleThirdDayRp() {
        const {dateForDay} = this.dayForm
        const param = {
          monthParm: dateForDay
        }
        this.fullscreenLoading = true;
        exportThirdFtyRpForDay(param)
          .then((response) => {
            this.download(response.msg);
          })
          .finally(() => {
            this.fullscreenLoading = false;
          });
      },
      getRpModelDailyList() {
        const {dateForDay} = this.dayForm
        const param = {
          rpModelDate: dateForDay
        }
        this.btnLoading = true;
        this.tableLoading = true;
        getRpModelDailyList(param)
          .then((response) => {
            if (response.code == 200) {
              this.tableData = response.data;
            } else {
              this.$message.error("数据查询异常==>" + response.msg);
            }
          })
          .finally(() => {
            this.btnLoading = false;
            this.tableLoading = false;
          });
      },
      /** 导入按钮操作 */
      handleImport() {
        this.upload.open = true;
      },
      // 文件上传中处理
      handleFileUploadProgress(event, file, fileList) {
        this.upload.isUploading = true;
      },
      // 文件上传成功处理
      handleFileSuccess(response, file, fileList) {
        this.upload.open = false;
        this.upload.isUploading = false;
        this.fullscreenLoading = false;
        this.$refs.upload.clearFiles();
        this.getRpModelDailyList();
      },
      // 提交上传文件
      submitFileForm() {
        this.$refs.upload.submit();
        this.fullscreenLoading = true;
      },
      //下载模板
      downloadModel(id) {
        const param = {
          id: id
        }
        this.fullscreenLoading = true;
        downloadRpModelDaily(param)
          .then((response) => {
            this.download(response.msg);
          })
          .finally(() => {
            this.fullscreenLoading = false;
          });
      }

    }
  }

</script>

<style scoped>
  .all {
    background: #fff;
  }

  .all-center {
    text-align: center;
    padding-top: 20px
  }

  .all-left {
    text-align: left;
    padding-top: 20px
  }

  .all-right {
    text-align: right;
    padding-top: 20px
  }
</style>
