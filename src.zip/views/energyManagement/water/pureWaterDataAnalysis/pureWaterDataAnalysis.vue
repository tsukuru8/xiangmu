//二厂纯水分析
<template>
  <el-container class="all">
    <el-main>
      <el-tabs v-model="activeName" @tab-click="handleClick">
        <el-tab-pane :lazy="true" label="用水量分析" name="first">
          <el-row :gutter="1">
            <el-col :span="20" :xs="24">
              <el-form
                :inline="true"
                :model="formData"
                :rules="rules"
                label-width="10px"
                ref="elForm"
                size="small"
              >
                <el-form-item label="" prop="radioValue">
                  <el-radio-group size="small" v-model="formData.radioValue">
                    <el-radio
                      :disabled="item.disabled"
                      :key="index"
                      :label="item.value"
                      @change="getRadioValueToShowOrHidden"
                      border
                      v-for="(item, index) in radioValueOption.filter(
                        (p) => p.value !== 3
                      )"
                    >
                      {{ item.label }}
                    </el-radio>
                  </el-radio-group>
                </el-form-item>

                <el-form-item
                ><!--日-->
                  <el-date-picker
                    align="right"
                    end-placeholder="结束日期"
                    range-separator="至"
                    start-placeholder="开始日期"
                    type="daterange"
                    unlink-panels
                    v-if="showOrHidden.showDay"
                    v-model="dateRange_day"
                    value-format="yyyy-MM-dd"
                  ></el-date-picker>
                </el-form-item>
                <el-form-item
                ><!--月-->
<!--                  <el-date-picker-->
<!--                    align="right"-->
<!--                    end-placeholder="结束月份"-->
<!--                    range-separator="至"-->
<!--                    start-placeholder="开始月份"-->
<!--                    type="monthrange"-->
<!--                    unlink-panels-->
<!--                    v-if="showOrHidden.showMonth"-->
<!--                    v-model="dateRange_month"-->
<!--                    value-format="yyyy-MM"-->
<!--                  ></el-date-picker>-->
                </el-form-item>
                <el-form-item
                ><!--年-->
                  <el-date-picker
                    placeholder="选择起始年"
                    type="year"
                    v-if="showOrHidden.showYear"
                    v-model="dateRange_year_beg"
                    value-format="yyyy-01-01 00:00:00"
                  ></el-date-picker>
                  <el-date-picker
                    placeholder="选择截止年"
                    type="year"
                    v-if="showOrHidden.showYear"
                    v-model="dateRange_year_end"
                    value-format="yyyy-12-31 23:59:59"
                  ></el-date-picker>
                </el-form-item>

                <el-form-item size="small">
                  <el-button @click="submitForm" type="primary"
                  >查询
                  </el-button>
                  <!-- <el-button @click="handleExport" icon="el-icon-download" type="warning">导出
                  </el-button> -->
                </el-form-item>
              </el-form>
            </el-col>
          </el-row>
          <el-row :gutter="2">
            <el-col class="chart-wrapper">
              <el-row style="padding: 16px 16px 0; margin-bottom: 32px">
                <line-chart_pure-water-use-analysis
                  v-if="activeName === 'first'"
                  :chart-data="lineChart_pureWaterUseAnalysis"
                />
              </el-row>
            </el-col>
          </el-row>
          <el-row :gutter="3">
            <el-table
              :data="tableData"
              stripe
              border
              style="width: 92%; margin-left: 3%"
            >
              <el-table-column
                align="center"
                prop="date"
                label="日期"
                width="200"
              ></el-table-column>
              <el-table-column
                align="center"
                prop="current"
                label="本期水流量(m³)"
              ></el-table-column>
<!--              <el-table-column-->
<!--                align="center"-->
<!--                prop="lastMonth"-->
<!--                label="上月同期水流量(m³)"-->
<!--                v-if="this.formData.radioValue !== 2"-->
<!--              ></el-table-column>-->
<!--              <el-table-column-->
<!--                align="center"-->
<!--                prop="lastYear"-->
<!--                label="去年同期水流量(m³)"-->
<!--              ></el-table-column>-->
<!--              <el-table-column-->
<!--                align="center"-->
<!--                prop="mom"-->
<!--                label="环比(%)"-->
<!--                v-if="this.formData.radioValue !== 2"-->
<!--              ></el-table-column>-->
<!--              <el-table-column-->
<!--                align="center"-->
<!--                prop="yoy"-->
<!--                label="同比(%)"-->
<!--              ></el-table-column>-->
            </el-table>
          </el-row>
        </el-tab-pane>

        <el-tab-pane :lazy="true" label="负荷分析" name="second">
          <el-row :gutter="1">
            <el-col :span="20" :xs="24">
              <el-form
                :inline="true"
                :model="formData"
                :rules="rules"
                label-width="10px"
                ref="elForm"
                size="small"
              >
                <el-form-item label="" prop="radioValue">
                  <el-radio-group size="small" v-model="formData.radioValue">
                    <el-radio
                      :disabled="item.disabled"
                      :key="index"
                      :label="item.value"
                      @change="getRadioValuesToShowOrHidden"
                      border
                      v-for="(item, index) in radioValueOptions.filter(
                        (p) => p.value < 3
                      )"
                    >
                      {{ item.label }}
                    </el-radio>
                  </el-radio-group>
                </el-form-item>
                <el-form-item
                ><!--瞬时-->
                  <el-date-picker
                    align="right"
                    placeholder="查询日期"
                    v-if="showOrHidden.showInstant"
                    v-model="dateRange_instant"
                    value-format="yyyy-MM-dd"
                  >
                  </el-date-picker>
                </el-form-item>
                <el-form-item
                ><!--日-->
<!--                  <el-date-picker-->
<!--                    align="right"-->
<!--                    end-placeholder="结束日期"-->
<!--                    range-separator="至"-->
<!--                    start-placeholder="开始日期"-->
<!--                    type="daterange"-->
<!--                    unlink-panels-->
<!--                    v-if="showOrHidden.showDay"-->
<!--                    v-model="dateRange_day"-->
<!--                    value-format="yyyy-MM-dd"-->
<!--                  ></el-date-picker>-->
<!--                </el-form-item>-->
<!--                <el-form-item-->
<!--                >&lt;!&ndash;月&ndash;&gt;-->
<!--                  <el-date-picker-->
<!--                    align="right"-->
<!--                    end-placeholder="结束月份"-->
<!--                    range-separator="至"-->
<!--                    start-placeholder="开始月份"-->
<!--                    type="monthrange"-->
<!--                    unlink-panels-->
<!--                    v-if="showOrHidden.showMonth"-->
<!--                    v-model="dateRange_month"-->
<!--                    value-format="yyyy-MM"-->
<!--                  ></el-date-picker>-->
<!--                </el-form-item>-->
<!--                <el-form-item-->
<!--                >&lt;!&ndash;年&ndash;&gt;-->
<!--                  <el-date-picker-->
<!--                    placeholder="选择起始年"-->
<!--                    type="year"-->
<!--                    v-if="showOrHidden.showYear"-->
<!--                    v-model="dateRange_year_beg"-->
<!--                    value-format="yyyy-01-01 00:00:00"-->
<!--                  ></el-date-picker>-->
<!--                  <el-date-picker-->
<!--                    placeholder="选择截止年"-->
<!--                    type="year"-->
<!--                    v-if="showOrHidden.showYear"-->
<!--                    v-model="dateRange_year_end"-->
<!--                    value-format="yyyy-12-31 23:59:59"-->
<!--                  ></el-date-picker>-->
                </el-form-item>

                <el-form-item size="small">
                  <el-button @click="submitForm" type="primary"
                  >查询
                  </el-button>
                  <!-- <el-button @click="handleExport" icon="el-icon-download" type="warning">导出
                  </el-button> -->
                </el-form-item>
              </el-form>
            </el-col>
          </el-row>
<!--          <el-row :gutter="2" v-if="linChartShowOrHidden">-->
<!--            <el-col class="chart-wrapper">-->
<!--              <el-row style="padding: 16px 16px 0; margin-bottom: 10px">-->
<!--                <line-chart_water-load-analysis-->
<!--                  v-if="activeName === 'second'"-->
<!--                  :chart-data="lineChart_pureInstantLoadAnalysis"-->
<!--                />-->
<!--              </el-row>-->
<!--            </el-col>-->
<!--          </el-row>-->
          <el-row :gutter="3" v-if="linChartShowOrHiddenCurrent">
            <el-col class="chart-wrapper">
              <el-row style="padding: 16px 16px 0; margin-bottom: 10px">
                <line-chart_pure-instant-load-analysis
                  :chart-data="lineChart_pureInstantLoadAnalysis"
                />
              </el-row>
            </el-col>
          </el-row>
          <el-row :gutter="5">
            <el-table
              :data="tableData"
              stripe
              border
              style="width: 92%; margin-left: 3%"
            >
              <el-table-column
                align="center"
                prop="max"
                label="最大负荷(m³)"
              ></el-table-column>
              <el-table-column
                align="center"
                prop="maxTime"
                label="发生时间"
              ></el-table-column>
              <el-table-column
                align="center"
                prop="min"
                label="最小负荷(m³)"
              ></el-table-column>
              <el-table-column
                align="center"
                prop="minTime"
                label="发生时间"
              ></el-table-column>
              <el-table-column
                align="center"
                prop="avg"
                label="平均负荷(m³)"
              ></el-table-column>
              <el-table-column
                align="center"
                prop="diff"
                label="峰谷差(m³)"
              ></el-table-column>
              <el-table-column
                align="center"
                prop="rate"
                label="负荷率(%)"
              ></el-table-column>
            </el-table>
          </el-row>
          <el-row :gutter="5">
            <el-alert
              style="width: 92%; margin: 2% 0 2% 3%"
              title="峰谷差：最大负荷与最小负荷之差； 峰谷差率：峰谷差与最大负荷的比率； 负荷率：平均负荷与最大负荷之比的百分数。"
              type="success"
            >
            </el-alert>
          </el-row>
          <el-row :gutter="6" v-if="TableShowOrHidden">
            <el-table
              :data="tableData2"
              stripe
              border
              style="width: 92%; margin-left: 3%"
            >
              <el-table-column
                align="center"
                prop="date"
                label="日期"
                width="200"
              ></el-table-column>
              <el-table-column
                align="center"
                prop="max"
                label="最大负荷(m³)"
              ></el-table-column>
              <el-table-column
                align="center"
                prop="min"
                label="最小负荷(m³)"
              ></el-table-column>
              <el-table-column
                align="center"
                prop="average"
                label="平均负荷(m³)"
              ></el-table-column>
              <el-table-column
                align="center"
                prop="peakValleyDiff"
                label="峰谷差(m³)"
              ></el-table-column>
              <el-table-column
                align="center"
                prop="loadFactor"
                label="负荷率(%)"
              ></el-table-column>
            </el-table>
          </el-row>
        </el-tab-pane>
      </el-tabs>
    </el-main>
  </el-container>
</template>

<script>
  import dayjs from 'dayjs'
  import {
    jennyTable,
    jennyMapDay,
    mixedMapDay,
    mixedTable,
    jennyPiont,
    mixedPiont,
    // getTreeForWater,
  } from "@/api/plantThreeEnergyManagement/water/pureWaterDataAnalysis";
  import LineChart_pureInstantLoadAnalysis from "../../../dashboard/yjWaterEcharts/LineChart_pureInstantLoadAnalysis";
  import LineChart_waterLoadAnalysis from "../../../dashboard/yjWaterEcharts/LineChart_waterLoadAnalysis";
  import LineChart_pureWaterUseAnalysis from "../../../dashboard/yjWaterEcharts/LineChart_pureWaterUseAnalysis";
  /** 当前页面的工厂ID */
  const pageDeptId = 110;
  export default {
    name: "dataAnalysis",
    components: {
      LineChart_pureInstantLoadAnalysis,
      LineChart_waterLoadAnalysis,
      LineChart_pureWaterUseAnalysis
    },
    data() {
      return {
        //左侧树型结构
        treeData: [],
        //默认展开的节点
        //defaultShowNodes:[1030001],
        defaultProps: {
          children: "children",
          label: "name",
        },
        selectedTab: "first",
        selectedDeviceId: "",
        //右侧图标
        loading: false,
        linChartShowOrHiddenCurrent: true,
        linChartShowOrHidden: false,
        TableShowOrHidden: true,
        activeName: "first",
        // 日期范围
        dateRange_instant: "",
        dateRange_day: [],
        dateRange_month: [],
        dateRange_year_beg: "",
        dateRange_year_end: "",
        //力调分析
        settlementDate: 25,
        dateRange_year: "",
        dateRange: [],

        showOrHidden: {
          showInstant: false,
          showDay: true,
          showMonth: false,
          showYear: false,
        },

        formData: {
          radioValue: 1,
        },
        rules: {
          radioValue: [
            {
              required: true,
              message: "不能为空",
              trigger: "change",
            },
          ],
        },
        radioValueOptions: [
          {
            label: "瞬时",
            value: 0,
          },
          // {
          //   label: "日",
          //   value: 1,
          // },
          // {
          //   label: "月",
          //   value: 2,
          // },
          // {
          //   label: "年",
          //   value: 3,
          // },
        ],
        radioValueOption: [
          {
            label: "日",
            value: 1,
          },
          // {
          //   label: "月",
          //   value: 2,
          // },
          // {
          //   label: "年",
          //   value: 3,
          // },
        ],
        tableData: [],
        tableData2: [],
        /** 用能分析 */
        lineChart_pureWaterUseAnalysis: {},
        /** 瞬时负荷 */
        lineChart_pureInstantLoadAnalysis: {},
        /** 其他负荷类型 */
        lineChart_waterLoadAnalysis: {},
      };
    },

    computed: {
      timeDefault_instant() {
        this.dateRange_instant = dayjs().format('YYYY-MM-DD HH:mm:ss'); //将值设置给插件绑定的数据
      },
      timeDefault_day() {
        this.dateRange_day = [dayjs().format('YYYY-MM-01 00:00:00'), dayjs().endOf('month').format('YYYY-MM-DD 23:59:59')]; //将值设置给插件绑定的数据
      },
      timeDefault_month() {
        this.dateRange_month = [dayjs().format('YYYY-01-01 00:00:00'), dayjs().format('YYYY-12-31 23:59:59')]; //将值设置给插件绑定的数据
      },

      timeDefault_year() {
        this.dateRange_year_beg = dayjs().startOf('year').format('YYYY-MM-DD 00:00:00'); //将值设置给插件绑定的数据
        this.dateRange_year_end = dayjs().endOf('year').format('YYYY-MM-DD 23:59:59'); //将值设置给插件绑定的数据
        this.dateRange_year = dayjs().get('year');
      },
    },
    created() {},
    mounted() {
      const route = this.$route.name.split('/')
      const param = route[route.length - 1]

      if(!isNaN(Number.parseInt(param))) {
        this.pageDeptId = Number.parseInt(param)
      }

      // 初始化查询，默认为每月1号到当前时间
      this.timeDefault_day;
      this.dateRange = [
        this.dateRange_day[0].toString(),
        this.dateRange_day[1].toString(),
      ];
      this.getList();
      // getTreeForWater({ date: this.pageDeptId })
      // .then(({ data = [] }) => {
      //   //删除没有第三级节点的二级节点
      //   for (let i=data[0].children.length-1; i>=0 ; i--) {
      //     if (data[0].children[i].children.length===0){
      //       data[0].children.splice(i,1)
      //     }
      //   }
      //   this.treeData = data;
      //   if (Array.isArray(data) && data.length > 0) {
      //     if (Array.isArray(data[0].children) && data[0].children.length > 1) {
      //       const first = data[0].children[0];
      //       if (Array.isArray(first.children) && first.children.length > 0) {
      //         const second = first.children[0];
      //         if (Array.isArray(second.children) && second.children.length > 0) {
      //           this.selectedDeviceId = second.children[0].id;
      //         } else {
      //           this.selectedDeviceId = second.id;
      //         }
      //       } else {
      //         this.selectedDeviceId = first.id;
      //       }
      //       //第一次加载默认选中节点
      //       this.$nextTick(function() {
      //         this.$refs.tree.setCurrentKey(first.children[0])
      //       })
      //       this.getList();
      //     }
      //   }
      // });

    },
    methods: {
      //树型结构节点单击事件
      handleNodeClick(data) {
        const { id, children } = data || {};

        if (!children || children.length === 0) {
          this.selectedDeviceId = id;
          this.getList();
        }
      },

      /** 根据当前选项查询数据 */
      getList() {
        this.loading = true;

        let timeParam = {
          beginTime: this.dateRange[0],
          endTime: this.dateRange[1],
        };

        if (this.formData.radioValue === 0) {
          timeParam = {
            date: this.dateRange,
          };
        }

        switch (this.selectedTab) {
          case "first":
            {
              mixedMapDay({
                ...timeParam,
              })
                .then(({ data }) => {
                  const {
                    abscissa,
                    curList,
                    tableData,
                  } = data || {};
                  this.lineChart_pureWaterUseAnalysis = {
                    ...this.lineChart_pureWaterUseAnalysis,
                    timeData: curList,
                    xAxisData: abscissa,

                  };
                  this.tableData=tableData;
                })
                .finally((res) => {
                  this.loading = false;
                });
            }
            break;
          case "second":
            {
              mixedPiont({
                ...timeParam,
              })
                .then(({ data }) => {
                  const {
                    abscissa,
                    curList,
                    tableData,
                  } = data || {};
                  this.lineChart_pureInstantLoadAnalysis = {
                    ...this.lineChart_pureInstantLoadAnalysis,
                    timeData: curList,
                    xAxisData: abscissa,

                  };
                  this.tableData=tableData;

                })
                .finally((res) => {
                  this.loading = false;
                });
            }
            break;
          case "third":
            {
              timeSharingAnalysis({
                ...timeParam,
                deviceId: this.selectedDeviceId,
                anlsValue: this.formData.radioValue,
              })
                .then(({ data }) => {
                  const { abscissa, compareData, compositonVOList, flatList, peakList, tipList, valleyList } = data || {};

                  /** 分时统计 */
                  this.lineChart_timeSharingPowerAnalysis = {
                    ...this.lineChart_timeSharingPowerAnalysis,
                    xAxisData: abscissa,
                    flatList: flatList,
                    peakList: peakList,
                    tipList: tipList,
                    valleyList: valleyList,
                  };

                  /** 分时统计——对比 */
                  this.lineChart_comparedAnalysis = {
                    ...this.lineChart_comparedAnalysis,
                    compareData: compareData,
                    xAxisData: abscissa,
                  };

                  /** 分时统计——构成 */
                  this.pieChart_constituteAnalysis = {
                    ...this.pieChart_constituteAnalysis,
                    compositonVOList: compositonVOList,
                    xAxisData: abscissa,
                  };
                })
                .finally((res) => {
                  this.loading = false;
                });
            }
            break;
          case "fourth":
            {
              forceAnalysis({
                year: this.dateRange_year,
                deptId: pageDeptId,
                settlementDate: this.settlementDate,
                anlsValue: this.formData.radioValue,
              })
                .then(({ data }) => {
                  const { abscissa, baseList, forceList, tableData } = data || {};
                  this.lineChart_forceAnalysis = {
                    ...this.lineChart_forceAnalysis,
                    baseList: baseList,
                    forceList: forceList,
                    xAxisData: abscissa,
                  };
                  this.tableData = tableData;
                })
                .finally((res) => {
                  this.loading = false;
                });
            }
            break;
          default:
            break;
        }
      },

      //tab选项卡
      handleClick(tab, event) {
        const { name } = tab;

        this.selectedTab = name;

        switch (name) {
          case "first":
          case "second":
          case "third":
          case "fourth":
            this.timeDefault_year;
            // this.dateRange = [this.dateRange_year.toString()];
            break;
          default:
            break;
        }

        this.getList();
      },

      //有瞬时按钮的
      getRadioValuesToShowOrHidden() {
        const radioValue = this.formData.radioValue;

        switch (radioValue) {
          case 0:
          {
            this.showOrHidden = {
              ...this.showOrHidden,
              showInstant: true,
              showDay: false,
              showMonth: false,
              showYear: false,
            };
            this.TableShowOrHidden = false;
            this.timeDefault_instant;
            this.linChartShowOrHiddenCurrent = true;
            this.linChartShowOrHidden = false;
            this.dateRange = this.dateRange_instant;
          }
            break;
          case 1:
          {
            this.showOrHidden = {
              ...this.showOrHidden,
              showInstant: false,
              showDay: true,
              showMonth: false,
              showYear: false,
            };
            this.linChartShowOrHiddenCurrent = false;
            this.linChartShowOrHidden = true;
            this.TableShowOrHidden = true;
            this.timeDefault_day;
            this.dateRange = [
              this.dateRange_day[0].toString(),
              this.dateRange_day[1].toString(),
            ];
          }
            break;
          case 2:
          {
            this.showOrHidden = {
              ...this.showOrHidden,
              showInstant: false,
              showDay: false,
              showMonth: true,
              showYear: false,
            };
            this.linChartShowOrHiddenCurrent = false;
            this.linChartShowOrHidden = true;
            this.TableShowOrHidden = true;
            this.timeDefault_month;
            this.dateRange = [
              this.dateRange_month[0].toString(),
              this.dateRange_month[1].toString(),
            ];
          }
            break;
          case 3:
          {
            this.showOrHidden = {
              ...this.showOrHidden,
              showInstant: false,
              showDay: false,
              showMonth: false,
              showYear: true,
            };
            this.linChartShowOrHiddenCurrent = false;
            this.linChartShowOrHidden = true;
            this.TableShowOrHidden = true;
            this.timeDefault_year;
            this.dateRange = [
              this.dateRange_year.toString(),
            ];
          }
            break;

          default:
            break;
        }

        this.getMDMYYoubangCountConsumption();
      },

      //无瞬时按钮的
      getRadioValueToShowOrHidden() {
        const radioValue = this.formData.radioValue;

        switch (radioValue) {
          case 1:
          {
            this.showOrHidden = {
              ...this.showOrHidden,
              showDay: true,
              showMonth: false,
              showYear: false,
            };
            this.timeDefault_day;
            this.dateRange = [
              this.dateRange_day[0].toString(),
              this.dateRange_day[1].toString(),
            ];
          }
            break;
          case 2:
          {
            this.showOrHidden = {
              ...this.showOrHidden,
              showDay: false,
              showMonth: true,
              showYear: false,
            };
            this.timeDefault_month;
            this.dateRange = [
              this.dateRange_month[0].toString(),
              this.dateRange_month[1].toString(),
            ];
          }
            break;
          case 3:
          {
            this.showOrHidden = {
              ...this.showOrHidden,
              showDay: false,
              showMonth: false,
              showYear: true,
            };
            this.timeDefault_year;
            this.dateRange = [this.dateRange_year.toString()]
          }
            break;
          default:
            break;
        }

        /*this.getUseAnalysis();*/
      },

      submitForm() {
        this.$refs["elForm"].validate((valid) => {
          if (valid) {
            this.getMDMYYoubangCountConsumption();
          }
        });
      },
      /** 导出按钮操作 */
      /*handleExport() {
        const queryParams = this.queryParams;
        this.$confirm("是否确认导出所有用户数据项?", "警告", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning",
        })
          .then(function () {
            return exportUser(queryParams);
          })
          .then((response) => {
            this.download(response.msg);
          })
          .catch(function () {});
      },*/
      /** 查询用能分析列表 */
      getMDMYYoubangCountConsumption() {
        const radioValue = this.formData.radioValue;

        switch (radioValue) {
          case 0:
            this.dateRange = this.dateRange_instant.split(" ")[0];
            break;
          case 1:
            this.dateRange = [
              this.dateRange_day[0].toString().substring(0, 10) + " 00:00:00",
              this.dateRange_day[1].toString().substring(0, 10) + " 23:59:59",
            ];
            break;
          case 2:
            const beginTime = this.dateRange_month[0].toString().substring(0, 7) + "-01 00:00:00"
            const endTime = dayjs(this.dateRange_month[1].toString().substring(0, 7) + "-01 23:59:59").endOf('month').format('YYYY-MM-DD 23:59:59')

            this.dateRange = [ beginTime, endTime ];
            break;
          case 3:
            // this.dateRange = [this.dateRange_year.toString()];
            break;

          default:
            break;
        }
        this.getList();
      },
    },
  };
</script>
<style>
  /*修改选中节点的字体颜色*/
  .el-tree--highlight-current .el-tree-node.is-current>.el-tree-node__content {
    color: #48A0FE !important;
  }
</style>
<style scoped>
.all {
  background: #fff;
}

.el-aside {
  background: #fff;
}

.chart-wrapper {
  background: #fff;
  padding: 16px 16px 0;
  margin-bottom: 32px;
}
</style>
