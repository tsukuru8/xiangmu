<template>
  <el-container class="all">
    <el-aside
      class="el-aside"
      width="230px"
      style="border-right: solid 1px gainsboro"
    >
      <el-tree
        :data="treeData"
        :props="defaultProps"
        :expand-on-click-node="false"
        ref="tree"
        @node-click="handleNodeClick"
        :highlight-current="true"
        node-key="id"
        :default-expanded-keys="defaultShowNodes"
        :default-expand-all="true"
        style="margin-top: 30px; margin-left: 8px"
      />
    </el-aside>
    <el-main v-loading="loading" element-loading-text="拼命加载中">
      <el-form
        :model="queryParams"
        ref="queryForm"
        :inline="true"
        label-width="80px"
      >
        <el-form-item label="记录日期" prop="queryParams.date">
          <el-date-picker
            v-model="queryParams.date"
            value-format="yyyy-MM-dd"
            placeholder="选择日期时间"
            @change="getList"
            :default-value="new Date()"
          >
          </el-date-picker>
        </el-form-item>
      </el-form>

      <el-button
        type="primary"
        icon="el-icon-plus"
        size="mini"
        @click="handleAdd"
        v-hasPermi="['system:user:add']"
      >新增
      </el-button
      >
      <br/>
      <br/>

      <el-table :data="tableData" stripe border style="width: 100%">
        <el-table-column
          align="center"
          prop="ljllH"
          label="累计流量_高"
        ></el-table-column>
        <el-table-column
          align="center"
          prop="ljllL"
          label="累计流量_低"
        ></el-table-column>
        <el-table-column
          align="center"
          prop="ssll"
          label="瞬时流量"
        ></el-table-column>
        <el-table-column
          align="center"
          prop="temper"
          label="温度"
        ></el-table-column>
        <el-table-column
          align="center"
          prop="pressure"
          label="压力"
        ></el-table-column>
        <el-table-column
          align="center"
          prop="createTime"
          label="记录时间"
        ></el-table-column>
        <el-table-column
          label="操作"
          align="center"
          width="140"
          class-name="small-padding fixed-width"
        >
          <template slot-scope="scope">
            <el-button
              size="mini"
              type="text"
              icon="el-icon-edit"
              @click="handleUpdate(scope.row)"
              v-hasPermi="['system:user:edit']"
            >修改
            </el-button
            >
            <el-button
              v-if="scope.row.userId !== 1"
              size="mini"
              type="text"
              icon="el-icon-delete"
              @click="handleDelete(scope.row)"
              v-hasPermi="['system:user:remove']"
            >删除
            </el-button
            >
          </template>
        </el-table-column>
      </el-table>
      <pagination
        v-show="total > 0"
        :total="total"
        :page.sync="queryParams.pageNum"
        :limit.sync="queryParams.pageSize"
        @pagination="getList"
      />
    </el-main>

    <!-- 添加或修改参数配置对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="800px" append-to-body>
      <el-form ref="form" :model="form" label-width="100px">
        <el-row>
          <el-col :span="12">
            <el-form-item label="累计流量_高" prop="ljllH">
              <el-input-number :min="0" :precision="1" v-model="form.ljllH"/>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="累计流量_低" prop="ljllL">
              <el-input-number :min="0" :precision="1" v-model="form.ljllL"/>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="瞬时流量" prop="ssll">
              <el-input-number :min="0" :precision="1" v-model="form.ssll"/>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="温度" prop="temper">
              <el-input-number :min="0" :precision="1" v-model="form.temper"/>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="压力" prop="pressure">
              <el-input-number
                :min="0"
                :precision="1"
                v-model="form.pressure"
              />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="记录时间" prop="createTimeStr">
              <el-date-picker
                v-model="form.createTimeStr"
                type="datetime"
                format="yyyy-MM-dd HH:mm"
                value-format="yyyy-MM-dd HH:mm"
                placeholder="选择日期时间"
              >
              </el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </el-container>
</template>


<script>
  import {getTreeForGas} from "../../../../api/plantThreeEnergyManagement/steam/steamDataAnalysis";
  import {gasInputAdd, gasInputDel, gasInputList, gasInputMod,} from "../../../../api/manualInputManagement/gas/index";

  export default {
    name: "manualInput",
    data() {
      return {
        pageDeptId: 101,
        //左侧树型结构
        treeData: [],
        //默认展开的节点
        defaultShowNodes: [1],
        defaultProps: {
          children: "children",
          label: "name",
        },
        //右侧图标
        loading: false,
        // 总条数
        total: 0,
        //表格数据
        tableData: [],
        queryParams: {
          date: null,
          deviceId: null,
          pageNum: 1,
          pageSize: 10,
        },
        // 弹出层标题
        title: "",
        // 是否显示弹出层
        open: false,
        form: {},
        selectedDeviceId: '',
      };
    },
    computed: {},
    created() {
    },
    mounted() {
      this.queryParams.date = this.getNow();

      const route = this.$route.name.split("/");
      const param = route[route.length - 1];

      if (!isNaN(Number.parseInt(param))) {
        this.pageDeptId = Number.parseInt(param);
      }

      getTreeForGas({deptId: this.pageDeptId, needInput: 1}).then(
        ({data = []}) => {
          //删除没有第三级节点的二级节点
          for (let i = data[0].children.length - 1; i >= 0; i--) {
            if (data[0].children[i].children.length === 0) {
              data[0].children.splice(i, 1);
            }
          }
          this.treeData = data;
          if (Array.isArray(data) && data.length > 0) {
            if (Array.isArray(data[0].children) && data[0].children.length > 0) {
              const first = data[0].children[0];
              if (Array.isArray(first.children) && first.children.length > 0) {
                const second = first.children[0];
                if (
                  Array.isArray(second.children) &&
                  second.children.length > 0
                ) {
                  this.queryParams.deviceId = second.children[0].id;
                  this.selectedDeviceId = second.children[0].id;
                } else {
                  this.queryParams.deviceId = second.id;
                  this.selectedDeviceId = second.id;
                }
              } else {
                this.queryParams.deviceId = first.id;
                this.selectedDeviceId = first.id;
              }
              //第一次加载默认选中节点
              this.$nextTick(function () {
                this.$refs.tree.setCurrentKey(first.children[0]);
              });
              this.getList();
            }
          }
        }
      );
    },
    methods: {
      getNow() {
        //get current Time
        var date = new Date();
        var mon = date.getMonth() + 1;
        var day = date.getDate();
        return (
          date.getFullYear() +
          "-" +
          (mon < 10 ? "0" + mon : mon) +
          "-" +
          (day < 10 ? "0" + day : day)
        );
      },
      //树型结构节点单击事件
      handleNodeClick(data) {
        const {id, children} = data || {};

        if (!children || children.length === 0) {
          this.queryParams.deviceId = id;
          this.selectedDeviceId = id;
          this.getList();
        }
      },
      /** 新增按钮操作 */
      handleAdd() {
        this.reset();
        this.open = true;
        this.title = "添加";
      },
      // 取消按钮
      cancel() {
        this.open = false;
        this.reset();
      },
      reset() {
        this.form = {
          id: undefined,
          ljllH: 0,
          ljllL: 0,
          ssll: 0,
          temper: 0,
          pressure: 0,
          createTimeStr: undefined,
        };
        this.resetForm("form");
      },

      /** 删除按钮操作 */
      handleDelete(row) {
        let that = this;
        this.$confirm("是否确认删除数据项?", "警告", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning",
        })
          .then(function () {
            console.log("row=" + row.id);
            console.log("deviceId= " + that.queryParams.deviceId);
            return gasInputDel({
              deptId: that.queryParams.deviceId,
              id: row.id,
            });
          })
          .then(() => {
            this.getList();
            this.msgSuccess("删除成功");
          })
          .catch(function () {
          });
      },

      /** 提交按钮 */
      submitForm: function () {
        this.$refs["form"].validate((valid) => {
          if (valid) {
            this.form.deptId = this.queryParams.deviceId ? this.queryParams.deviceId : this.selectedDeviceId;
            if (this.form.id != undefined) {
              gasInputMod(this.form).then((response) => {
                if (response.code === 200) {
                  this.msgSuccess("修改成功");
                  this.open = false;
                  this.getList();
                } else {
                  this.msgError(response.msg);
                }
              });
            } else {
              gasInputAdd(this.form).then((response) => {
                if (response.code === 200) {
                  this.msgSuccess("新增成功");
                  this.open = false;
                  this.getList();
                } else {
                  this.msgError(response.msg);
                }
              });
            }
          }
        });
      },
      /** 修改按钮操作 */
      handleUpdate(row) {
        this.reset();
        this.form = Object.assign(this.form, row);
        this.form.createTimeStr = row.createTime;
        this.open = true;
        this.title = "修改";
      },
      //加载表格数据
      getList() {
        this.loading = true;
        gasInputList(this.queryParams).then((res) => {
          if (res.code == 200) {
            this.tableData = res.rows;
            this.total = res.total;
          }
          this.loading = false;
        });
      },
    },
  };
</script>
