// 抄见用量日报表
<template>
  <el-container class="all">
    <el-row :gutter="1" style="width: 100%;">
      <el-col :span="24" :xs="24" style="padding: 20px 20px 0 20px; width: 100%;">
        <el-form
          :inline="true"
          :model="formData"
          :rules="rules"
          label-width="10px"
          ref="elForm"
          size="small"
        >
          <el-form-item>
            <el-date-picker
              align="right"
              end-placeholder="结束日期"
              range-separator="至"
              start-placeholder="开始日期"
              type="daterange"
              unlink-panels
              v-model="formData.dateRange_day"
              value-format="yyyy-MM-dd"
            />
          </el-form-item>
          <el-form-item size="small">
            <el-button @click="getList" type="primary"
              >查询
            </el-button>
            <el-button @click="handleExport" icon="el-icon-download" type="warning">导出
            </el-button>
          </el-form-item>
        </el-form>
      </el-col>
      <el-col :span="24" :xs="24" style="width: 100%;">
        <el-main v-loading="loading" element-loading-text="拼命加载中" style="width: 100%;">
          <el-table
            style="width: 100%;"
            :data="tableData"
            row-key="deviceName"
            stripe
            border
            :height="windowHeight"
          >
            <el-table-column
              align="center"
              v-for="item in columns"
              :key="item.value"
              :prop="item.value"
              :label="item.name"
              :min-width="item.value === 'deviceName' || item.value === 'total' ? '150px' : '100px'"
              :width="item.value === 'deviceName' || item.value === 'total' ? '150px' : '100px'"
            />
          </el-table>
        </el-main>
        </el-col>
      </el-row>
  </el-container>
</template>

<script>
import dayjs from 'dayjs'
import { useDayReport, useDayReportExport } from "@/api/plantThreeEnergyManagement/solar/solarDataAnalysis";

export default {
  name: "copySeePowerByDay",
  components: {
  },
  data() {
    return {
      //根据窗口大小调整
      windowHeight:window.innerHeight - 200,
      pageDeptId: 100,
      loading: false,
      columns: [],
      tableData: [],
      formData: {
        dateRange_day: [],
      },
      rules: {},
    };
  },

  computed: {
  },
  created() {
    window.addEventListener('resize',this.getHeight)
  },
  mounted() {
    const route = this.$route.name.split('/')
    const param = route[route.length - 1]

    if(!isNaN(Number.parseInt(param))) {
      this.pageDeptId = Number.parseInt(param)
    }

    this.formData.dateRange_day = [dayjs().format('YYYY-MM-01'), dayjs().format('YYYY-MM-DD')]

    this.getList()
  },
  destroyed() {
    window.removeEventListener('resize',this.getHeight)
  },
  methods: {
    //根据窗口大小调整
    getHeight(){
      this.windowHeight = window.innerHeight - 200
    },
    /** 根据当前选项查询数据 */
    getList() {
      this.loading = true;

      const { dateRange_day=[] } = this.formData
      const [beginTime, endTime] = dateRange_day

      useDayReport({
        deptId: this.pageDeptId,
        beginTime: beginTime,
        endTime: endTime,
      })
      .then(({ data={} }) => {
        const {columns=[], tableData=[]} = data
        this.columns = columns
        this.tableData = tableData
      })
      .finally((res) => {
        this.loading = false;
      });
    },

    /** 导出按钮操作 */
    handleExport() {
      const { dateRange_day=[] } = this.formData
      const [beginTime, endTime] = dateRange_day

      const param = {
        deptId: this.pageDeptId,
        beginTime: beginTime,
        endTime: endTime,
      }

      this.$confirm("是否确认导出所有用户数据项?", "警告", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      }).then(function () {
          return useDayReportExport(param)
      }).then((response) => {
          this.download(response.msg);
      }).catch(function () {});
    },

  },
};
</script>

<style scoped>
.all {
  background: #fff;
}

.el-aside {
  background: #fff;
}

.chart-wrapper {
  background: #fff;
  padding: 16px 16px 0;
  margin-bottom: 32px;
}
</style>
