<template>
  <el-container class="all">
    <el-aside
      class="el-aside"
      width="230px"
      style="border-right: solid 1px gainsboro"
    >
      <el-tree
        :data="treeData"
        :props="defaultProps"
        :expand-on-click-node="false"
        ref="tree"
        highlight-current
        node-key="id"
        :default-expanded-keys="defaultShowNodes"
        @node-click="handleNodeClick"
        style="margin-top: 30px; margin-left: 10px"
      />
    </el-aside>
    <el-main v-loading="loading" element-loading-text="拼命加载中">
      <el-form
        :inline="true"
        :model="formData"
        :rules="rules"
        label-width="10px"
        ref="elForm"
        size="small"
      >
        <el-form-item>
          <el-date-picker
            align="right"
            placeholder="日期"
            type="date"
            unlink-panels
            v-model="formData.date"
            value-format="yyyy-MM-dd"
          />
        </el-form-item>
        <!-- <el-form-item>
          负荷阈值：<el-input-number v-model="num" label="负荷阈值" />KW
        </el-form-item> -->
        <el-form-item size="small">
          <el-button @click="getList" type="primary"
          >查询
          </el-button>
          <el-button @click="handleExport" icon="el-icon-download" type="warning">导出
          </el-button>
        </el-form-item>
      </el-form>

      <el-table
        style="width: 100%;"
        :data="tableData"
        row-key="deviceName"
        stripe
        border
        :height="windowHeight"
      >
        <el-table-column
          align="center"
          key="recordTime"
          prop="recordTime"
          label="时点"
          min-width="150px"
          width="150px"
        />
        <el-table-column align="center" label="监测点数据监测">
          <el-table-column
            align="center"
            key="ygzdnD"
            prop="ygzdnD"
            label="天发电量"
            min-width="100px"
          />
          <el-table-column
                           align="center"
                           key="ygzdn"
                           prop="ygzdn"
                           label="有功电能"
                           min-width="100px"
          />
          <el-table-column
                           align="center"
                           key="ygglA"
                           prop="ygglA"
                           label="交流输出功率"
                           min-width="100px"
          />
          <el-table-column
                           align="center"
                           key="ygglD"
                           prop="ygglD"
                           label="直流输入功率"
                           min-width="100px"
          />
          <el-table-column
                           align="center"
                           key="ia"
                           prop="ia"
                           label="A相并网电流"
                           min-width="100px"
          />
          <el-table-column
            align="center"
            key="ib"
            prop="ib"
            label="B相并网电流"
            min-width="100px"
          />
          <el-table-column
            align="center"
            key="ic"
            prop="ic"
            label="C相并网电流"
            min-width="100px"
          />
          <el-table-column
            align="center"
            key="id"
            prop="id"
            label="直流电流"
            min-width="100px"
          />
          <el-table-column
            align="center"
            key="ua"
            prop="ua"
            label="A相并网电压"
            min-width="100px"
          />
          <el-table-column
            align="center"
            key="ub"
            prop="ub"
            label="B相并网电压"
            min-width="100px"
          />
          <el-table-column
            align="center"
            key="uc"
            prop="uc"
            label="C相并网电压"
            min-width="100px"
          />
          <el-table-column
            align="center"
            key="ud"
            prop="ud"
            label="直流电压"
            min-width="100px"
          />
          <el-table-column
            align="center"
            key="lc"
            prop="lc"
            label="漏电流"
            min-width="100px"
          />
          <el-table-column
            align="center"
            key="temp"
            prop="temp"
            label="散热器温度"
            min-width="100px"
          />
          <el-table-column
            align="center"
            key="hz"
            prop="hz"
            label="并网频率"
            min-width="100px"
          />
        </el-table-column>
      </el-table>
    </el-main>
  </el-container>
</template>

<script>
  import dayjs from 'dayjs'
  import {
    getTreeForSolar,
    monitorRealTimeReport,
    monitorRealTimeReportExport,
  } from "@/api/plantThreeEnergyManagement/solar/solarDataAnalysis";

  export default {
    name: "copySeePowerByDay",
    components: {
    },
    data() {
      return {
        windowHeight:window.innerHeight - 250,
        isTotalTable:false,
        pageDeptId: 100,
        treeData: [],
        defaultShowNodes:[1],
        defaultProps: {
          children: "children",
          label: "name",
        },
        FGPJDeviceId: [1010001, 1550175, 1550176, 1550177],
        loading: false,
        tableData: [],
        formData: {
          date: dayjs().format('YYYY-MM-DD'),
        },
        rules: {},
      };
    },

    computed: {
    },
    created() {
      window.addEventListener('resize',this.getHeight)
    },
    mounted() {
      const route = this.$route.name.split('/')
      const param = route[route.length - 1]

      if(!isNaN(Number.parseInt(param))) {
        this.pageDeptId = Number.parseInt(param)
      }
      getTreeForSolar({ deptId: this.pageDeptId }).then(({ data = [] }) => {
        //删除没有第三级节点的二级节点
        for (let i=data[0].children.length-1; i>=0 ; i--) {
          if (data[0].children[i].children.length===0){
            data[0].children.splice(i,1)
          }
        }
        this.treeData = data;
        if (Array.isArray(data) && data.length > 0) {
          if (Array.isArray(data[0].children) && data[0].children.length > 1) {
            const first = data[0].children[0];
            if (Array.isArray(first.children) && first.children.length > 0) {
              const second = first.children[0];
              if (Array.isArray(second.children) && second.children.length > 0) {
                this.selectedDeviceId = second.children[0].id;
              } else {
                this.selectedDeviceId = second.id;
              }
            } else {
              this.selectedDeviceId = first.id;
            }
            //第一次加载默认选中节点
            this.$nextTick(function() {
              this.$refs.tree.setCurrentKey(first.children[0])
            })
            this.getList();
          }
        }
      });
    },
    destroyed() {
      window.removeEventListener('resize',this.getHeight)
    },
    methods: {
      //根据窗口大小调整
      getHeight(){
        this.windowHeight = window.innerHeight - 250
      },
      //树型结构节点单击事件
      handleNodeClick(data) {
        const { id, children } = data || {};

        if (!children || children.length === 0) {
          this.selectedDeviceId = id;
          this.getList();
        }
      },
      /** 根据当前选项查询数据 */
      getList() {
        this.loading = true;

        const { date} = this.formData

        const param = {
          deviceId: this.selectedDeviceId,
          date,
        };

        monitorRealTimeReport(param)
          .then(({ data=[] }) => {
            this.tableData = data
          })
          .finally((res) => {
            this.loading = false;
          });
      },

      submitForm() {
        this.$refs["elForm"].validate((valid) => {
          if (valid) {
            this.getList();
          }
        });
      },
      /** 导出按钮操作 */
      handleExport() {
        const { date} = this.formData
        const params = {
          deviceId: this.selectedDeviceId,
          date,
        }

        this.$confirm("是否确认导出所有数据项?", "警告", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning",
        })
          .then(function () {
            return monitorRealTimeReportExport(params);
          })
          .then((response) => {
            this.download(response.msg);
          })
          .catch(function () {});
      },
    },
  };
</script>

<style>
  /*修改选中节点的字体颜色*/
  .el-tree--highlight-current .el-tree-node.is-current>.el-tree-node__content {
    color: #48A0FE !important;
  }
</style>
<style scoped>
  .all {
    background: #fff;
  }

  .el-aside {
    background: #fff;
  }

  .chart-wrapper {
    background: #fff;
    padding: 16px 16px 0;
    margin-bottom: 32px;
  }
</style>
