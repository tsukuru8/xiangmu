<template>
  <el-container>
    <el-row style="width: 100%;">
      <el-col style="text-align: center">
        <img src="../../../../../assets/image/solar/solar.png" style="width: 16rem; height: 6rem">
      </el-col>

      <el-col style="width: 100%;">
        <el-table
          :header-cell-style="{textAlign: 'center'}"
          :cell-style="{ textAlign: 'center' }"
          :data="tableData"
          :align="center"
          style="width: 100%;">
          <el-table-column
            label="概况"
          >
            <el-table-column
              prop="device"
              label="设备"
              width="180">
            </el-table-column>
            <el-table-column
              prop="status"
              label="工作状态">
              <template slot-scope="scope">
                <div slot="reference" class="name-wrapper">
                  <el-tag size="medium">{{ scope.row.status }}</el-tag>
                </div>
              </template>
            </el-table-column>
            <el-table-column
              prop="temp"
              label="温度(℃)">
            </el-table-column>
            <el-table-column
              prop="dayYgzdn"
              label="日发电量(kW.h)">
            </el-table-column>
            <el-table-column
              prop="sumYgzdn"
              label="总发电量(kW.h)">
            </el-table-column>
          </el-table-column>
          <el-table-column
            label="交流侧"
          >
            <el-table-column
              prop="ia"
              label="ia"
              width="180">
            </el-table-column>
            <el-table-column
              prop="ib"
              label="ib">
            </el-table-column>
            <el-table-column
              prop="ic"
              label="ic">
            </el-table-column>
            <el-table-column
              prop="ua"
              label="ua">
            </el-table-column>
            <el-table-column
              prop="ub"
              label="ub">
            </el-table-column>
            <el-table-column
              prop="uc"
              label="uc">
            </el-table-column>
          </el-table-column>
          <el-table-column
            label="直流侧">
            <el-table-column
              prop="id"
              label="i">
            </el-table-column>
            <el-table-column
              prop="ud"
              label="u">
            </el-table-column>
          </el-table-column>
        </el-table>
      </el-col>
    </el-row>

  </el-container>

</template>

<script>
  import {systemStatus} from '../../../../../api/plantThreeEnergyManagement/solar/solarDataAnalysis'
  export default {
    name: 'index',
    data() {
      return {
        tableData:[],
      }
    },
    created() {
      this.getSystemStatusData();
    },
    mounted() {
    },
    methods:{
      getSystemStatusData(){
        systemStatus().then(response =>{
          this.tableData = response.data;
          //console.log('执行了', response.data);
        })
      }
    }
  }

</script>

<style>
  img{
  }
</style>
