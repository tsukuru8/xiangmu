<template>
  <div>
    <div style="display: flex; flex-direction: row;">
      <div style="margin-right: 45px">
        <div class="title">{{device.machineName}}</div>
        <div class="device-image">
          <el-image :src="require('../../../../assets/image/'+device.imgUrl)" fit="fill"></el-image>
        </div>
      </div>
      <div>
        <div :style="{ color: getColor(device.deviceStatus) }" class="title status">{{ getStatus(device.deviceStatus) }}</div>
        <div v-show="active === j" v-for="(alarm, j) in device.alarmInfo" :key="j">
          <div>
            <div class="font">告警类型</div>
            <div class="title">{{alarm.alarmContent}}</div>
            <div  class="font">告警持续时长</div>
            <div class="title">{{alarm.duration}}</div>
          </div>
        </div>
        <span v-for="(circle, i) in device.alarmInfo" :key="i" @click="handleTrigger(i)" class="circle" :class=" active === i ? 'active' : ''">
                </span>
      </div>
    </div>
    <div>
        <div>
          {{`累计用电量 : ${device.activePower}`}}
      </div>
        <div style="display: flex; justify-content: space-around;">
          <div>{{`A项电流 : ${device.ia}`}}</div>
          <div>{{`B项电流 : ${device.ib}`}}</div>
        </div>
        <div style="display: flex; justify-content: space-around">
          <div>{{`C项电流 : ${device.ic}`}}</div>
          <div>{{`实时功率 : ${device.power}`}}</div>
        </div>
    </div>
  </div>
</template>

<script>
import DeviceImg from '../../../../assets/image/WechatIMG7929.png';

export default {
  name: "DeviceOverview",
  components: {
  },
  props: {
    device: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      loading: false,
      active: 0,
      LabelData:[
        { label:'累计用电量', key:'activePower' },
        { label:'A项电流', key:'ia' },
        { label:'B项电流', key:'ib' },
        { label:'C项电流', key:'ic' },
        { label:'实时功率', key:'power' }
      ],
      url: DeviceImg
    };
  },

  created() {
    console.log(this.device)
  },
  methods: {
    /**
     * 获取设备状态名称
     * @param status状态
     */
    getStatus(status) {
      switch (status) {
        case 0:
          return '故障';
        case 1:
          return '停机';
        case 2:
          return '空载';
        case 3:
          return '满载';
        case 4:
          return '过载';
        default: return 'NA';
      }
    },
    /**
     * 获取颜色
     * @param runStatus 状态
     */
    getColor(runStatus) {
      switch (runStatus) {
        case 'Error':
        case '故障':
        case 0:
          return '#F76666';
        case 'Shutdown':
        case '停机':
        case 1:
          return '#8C9199';
        case 'NoLoad':
        case '空载':
        case 2:
          return '#5AD8A6';
        case 'FullLoad':
        case '满载':
        case 3:
          return '#1890FF';
        case 'OverLoad':
        case '过载':
        case 4:
          return '#F6BD16';
        default: return '#8C9199';
      }
    },
    handleTrigger(index){
      this.active = index;
    }
  }
}
</script>
<style lang="scss" scoped>
    .title{
      font-size: 16px;
      font-weight: 800;
      color: #fff;
    }
    .status{
      margin-top: 28px;
    }
    .circle{
      display: inline-block;
      margin: 11px 8px 5px 2px;
      width: 10px;
      height: 10px;
      border-radius: 50%;
      background-color: #909399;
    }
    .active{
      background-color: #409EFF;
    }
    .el-image{
      margin-top: 16px;
      width: 200px;
      height: 150px;
    }
    .font{
      color: #BFCBD9;
    }

</style>
