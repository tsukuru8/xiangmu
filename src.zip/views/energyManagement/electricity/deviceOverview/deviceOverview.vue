<template>
  <el-container class="all">
    <el-main v-loading="loading" element-loading-text="拼命加载中">
        <div>
          <span style="margin-right: 10px">设备区域：</span>
          <el-select v-model="deptId" placeholder="请选择">
            <el-option
              v-for="item in deptIdOptions"
              :key="item.id"
              :label="item.name"
              :value="item.id">
            </el-option>
          </el-select>
          <el-select v-model="time" placeholder="请选择" style="margin-left: 30px">
            <el-option
              v-for="item in timeOptions"
              :key="item.id"
              :label="item.name"
              :value="item.id">
            </el-option>
          </el-select>
          <span style="margin-left: 10px">刷新一次</span>
        </div>
      <div style="display: flex; flex-wrap: wrap; justify-content: space-around; margin-top: 24px">
        <el-card v-for="device in deviceList"  :key="device.machineCode" style="margin: 16px; line-height: 30px">
          <device-content :device="device"></device-content>
        </el-card>
      </div>
      <pagination
        v-show="total >= 10"
        :total="total"
        :page.sync="pageNum"
        :limit.sync="pageSize"
        @pagination="getDeviceStatus"
      />
    </el-main>
  </el-container>
</template>

<script>
import {
  getTree,
  ListDeviceStatus,
  getRefreshTimeOptions,
  getRrefreshTime,
  EditRrefreshTime
} from "@/api/plantThreeEnergyManagement/electricity/electricityDataAnalysis";
import deviceContent from "./deviceContent";

export default {
  name: "DeviceOverview",
  components: {
    deviceContent
  },
  data() {
    return {
      pageDeptId: 100,
      deptIdOptions: [],
      total: 0,
      // 查询参数
      pageNum: 1,
      pageSize: 6,
      deptId: 101,
      loading: false,
      time: 15000,
      timeOptions: [],
      deviceList: [],
      active: 0,
      timer: null

    };
  },
  watch: {
    deptId: {
      deep: true,
      handler() {
        this.loading = true;
        this.getDeviceStatus()
      }
    },
    time: {
      deep: true,
      handler(val) {
        this.time = val;
        this.editTime();
        clearInterval(this.timer);
        this.openTimer();

      }
    }
  },
  created() {
    const route = this.$route.name.split('/')
    const param = route[route.length - 1]

    if(!isNaN(Number.parseInt(param))) {
      this.pageDeptId = Number.parseInt(param)
    }
    this.getOptions()
    this.loading = true;
    this.getDeviceStatus();
    this.getTime();

  },
  methods: {
    /**
     * 获取设备状态名称
     * @param status状态
     */
    getStatus(status) {
      switch (status) {
        case 0:
          return '故障';
        case 1:
          return '停机';
        case 2:
          return '空载';
        case 3:
          return '满载';
        case 4:
          return '过载';
        default: return 'NA';
      }
    },
    /**
     * 获取颜色
     * @param runStatus 状态
     */
    getColor(runStatus) {
      switch (runStatus) {
        case 'Error':
        case '故障':
        case 0:
          return '#F76666';
        case 'Shutdown':
        case '停机':
        case 1:
          return '#8C9199';
        case 'NoLoad':
        case '空载':
        case 2:
          return '#5AD8A6';
        case 'FullLoad':
        case '满载':
        case 3:
          return '#1890FF';
        case 'OverLoad':
        case '过载':
        case 4:
          return '#F6BD16';
        default: return '#8C9199';
      }
    },
    handleTrigger(index){
      this.active = index;
    },
    getOptions() {
      this.loading = true;
      getTree({ deptId: this.pageDeptId }).then(({ data = [] }) => {
        console.log('data',data[0].children)
        this.deptIdOptions = data[0].children
      })
    },

    getDeviceStatus(){
      ListDeviceStatus({
        deptId: this.deptId,
        pageNum: this.pageNum,
        pageSize: this.pageSize
      })
        .then((data) => {
          this.loading = false;
          this.deviceList = data.rows || [];
          this.machineCode = this.deviceList[0].machineCode
          this.alarmPoint = this.deviceList[0].alarmInfo.alarmPoint
          this.total = data.total;

        })
        .finally(() => {});
    },
    getTime(){
      getRefreshTimeOptions().then(({data}) => {
        console.log('ss:',data)
        data.forEach((time) => {
          this.timeOptions.push({name:time + '秒', id: time * 1000});
        });
        this.loading = false;
      });
      getRrefreshTime().then(({data})=>{
        this.time = data * 1000
        clearInterval(this.timer);
        this.openTimer();
      })
    },
    editTime(){
      EditRrefreshTime(this.time / 1000).then(({data})=>{
        console.log(data)
      })
    },
    // 这是一个定时器
    openTimer() {
     this.timer = setInterval(()=>{
        this.getDeviceStatus()
      },this.time)
    },
  }
}
</script>
<style lang="scss" scoped>
    .all {
      min-height: calc(100vh - 84px);
      height: 100%;
      font-size: 14px;
    }

    .el-main {
      background-color: #001528;
      color: #fff;
      .el-card {
        width: 440px;
        background-color: #1F2D3D;
        border-color: #1952B3;
        box-shadow: 0 2px 12px 0 rgba(34, 181, 235, 50%);
        color: #fff;
      }
      .pagination-container{
        background-color: #001528;
      }
    }
</style>
