<template>
    <el-container class="all">
      <el-aside
        class="el-aside"
        width="260px"
        style="border-right: solid 1px gainsboro"
      >
        <el-tree
          :data="treeData"
          :props="defaultProps"
          default-expand-all
          :expand-on-click-node="false"
          check-on-click-node
          ref="tree"
          :highlight-current="true"
          node-key="id"
          show-checkbox
          @check-change="handleCheckChange"
          style="margin-top: 30px; margin-left: 8px"
        />
      </el-aside>
      <el-main v-loading="loading" element-loading-text="拼命加载中">
            <el-row :gutter="1">
              <el-col :span="20" :xs="24">
                <el-form
                  :inline="true"
                  :model="formData"
                  :rules="rules"
                  label-width="10px"
                  ref="elForm"
                  size="small"
                >
                  <el-form-item>
                    <el-date-picker
                      v-model="dateRange"
                      type="datetimerange"
                      :picker-options="pickerOptions"
                      range-separator="至"
                      start-placeholder="开始日期"
                      end-placeholder="结束日期"
                      value-format="yyyy-MM-dd HH:mm:ss"
                      align="right">
                    </el-date-picker>
                  </el-form-item>
                  <el-form-item size="small">
                    <el-button @click="submitForm" type="primary"
                      >查询
                    </el-button>
                  </el-form-item>
                </el-form>
              </el-col>
            </el-row>
            <el-row :gutter="2">
              <el-col class="chart-wrapper">
                <el-row style="padding: 16px 16px 0; margin-bottom: 32px">
                  <LineChartDeviceOEE
                    v-if="treeNodeCheckedList.length && machineSplitList.length"
                    :chart-data="machineSplitList"
                  />
                </el-row>
              </el-col>
            </el-row>
      </el-main>
    </el-container>
  </template>

  <script>
  import dayjs from 'dayjs'
  import {
    getTree,
    deviceAnalysis,
  } from "@/api/plantThreeEnergyManagement/electricity/electricityDataAnalysis";
  import LineChartDeviceOEE from "../../../dashboard/yjElectricityEcharts/LineChart_deviceOEE";

  export default {
    name: "DeviceOEE",
    components: {
      LineChartDeviceOEE
    },
    data() {
      return {
        pageDeptId: 100,
        //左侧树型结构
        treeData: [],
        defaultProps: {
          children: "children",
          label: "name",
          disabled: this.handleCheckedLimit
        },
        pickDate: '', // 存放选中的日期
        treeCheckedLimitNum: 5,
        loading: false,
        aYear: 365 * 24 * 3600 * 1000,
        // 日期范围
        pickerOptions: {
          shortcuts: [{
            text: '最近一周',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
              picker.$emit('pick', [start, end]);
            }
          }, {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
              picker.$emit('pick', [start, end]);
            }
          }, {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
              picker.$emit('pick', [start, end]);
            }
          }],
          onPick: ({ maxDate, minDate }) => {
            this.pickDate = minDate.getTime()
            if (maxDate) {
              this.pickDate = ''
            }
          },
          disabledDate: (time)=>{
            // time.getTime()获取的是时间戳
            // 只能选择365天的范围且不能大于当前日期
            const choiceDateTime = new Date(this.pickDate).getTime()
            const minTime = new Date(choiceDateTime).setMonth(new Date(choiceDateTime).getMonth() - 12)
            const maxTime = new Date(choiceDateTime).setMonth(new Date(choiceDateTime).getMonth() + 12)
            const min = minTime
            const newDate = new Date(new Date().toLocaleDateString()).getTime() + 24 * 60 * 60 * 1000 - 1
            const max = newDate < maxTime ? newDate : maxTime
            // 如果已经选中一个日期 则 返回 该日期前后12个月时间可选,后12个月最大为当前日期
            if (this.pickDate) {
              return time.getTime() < min || time.getTime() > max
            }
            // 若一个日期也没选中 则 返回 当前日期以前日期可选
            return time.getTime() > newDate
          }
        },
        dateRange: [],
        // 选中的树节点集合
        treeNodeCheckedList: [],
        formData: {},
        rules: {},
        machineSplitList: [],
      };
    },

    created() {
      const route = this.$route.name.split('/')
      const param = route[route.length - 1]

      if(!isNaN(Number.parseInt(param))) {
        this.pageDeptId = Number.parseInt(param)
      }

      getTree({ deptId: this.pageDeptId }).then(({ data = [] }) => {
        //删除没有第三级节点的二级节点
        for (let i=data[0].children.length-1; i>=0 ; i--) {
          if (data[0].children[i].children.length===0){
            data[0].children.splice(i,1)
          }
        }
        this.treeData = data;
        if (Array.isArray(data) && data.length > 0) {
          if (Array.isArray(data[0].children) && data[0].children.length > 1) {
            const first = data[0].children[0];
            if (Array.isArray(first.children) && first.children.length > 0) {
              const second = first.children[0];
              if (Array.isArray(second.children) && second.children.length > 0) {
                this.selectedDeviceId = second.children[0].id;
              } else {
                this.selectedDeviceId = second.id;
              }
            } else {
              this.selectedDeviceId = first.id;
            }
            //第一次加载默认选中节点
            this.$nextTick(function() {
              this.$refs.tree.setCurrentKey(first.children[0])
            })
            // this.getList();
          }
        }
      });
      this.handleDateRange();

    },
    methods: {
      // 选中树节点
      handleCheckChange(data, checked, indeterminate) {
        const { id, pid, children} = data || {};
        if((!children || children.length === 0)){
          checked && !this.treeNodeCheckedList.includes(id) && this.treeNodeCheckedList.push(id);
          !checked && this.treeNodeCheckedList.includes(id) && this.treeNodeCheckedList.splice(this.treeNodeCheckedList.indexOf(id),1)
          if(this.treeNodeCheckedList.length){
            this.getList();
          }
        }
      },

      // 超过可选节点数量后禁选
      handleCheckedLimit(data,node){
        if(  data.children.length > 0 || !node.checked && this.treeNodeCheckedList.length >= this.treeCheckedLimitNum){
          return true
        }
          return false
      },

      handleDateRange(){
        const end = new Date();
        const start = new Date();
        start.setTime(start.getTime() - 24 * 3600 * 1000);
        // 初始化查询，默认为当前时间
        this.dateRange= [start ,end];
      },

      /** 根据当前选项渲染图表 */
      getList() {
        this.loading = true;
        let timeParam = {
          beginTime: dayjs(this.dateRange[0]).format('YYYY-MM-DD HH:mm:ss'),
          endTime: dayjs(this.dateRange[1]).format('YYYY-MM-DD HH:mm:ss'),
        };
        deviceAnalysis({
              ...timeParam,
              machineCodeList: this.treeNodeCheckedList.join()
            })
              .then(({data}) => {
                this.loading = false;
                this.machineSplitList = data || [];
              })
              .finally((res) => {
              });
      },
      submitForm() {
        if(!this.treeNodeCheckedList.length) {
          this.$message({
            message: '请选择设备！',
            type: 'error'
          })
          return
      };
        this.$refs["elForm"].validate((valid) => {
          if (valid) {
            this.getList();
          }
        });
      }
    }
  }
  </script>

  <style>
    /*修改选中节点的字体颜色*/
    .el-tree--highlight-current .el-tree-node.is-current>.el-tree-node__content {
      color: #48A0FE !important;
    }
  </style>
  <style lang="scss" scoped>
  .all {
    background: #fff;
  }

  .el-aside {
    background: #fff;
  }

  .chart-wrapper {
    background: #fff;
    padding: 16px 16px 0;
    margin-bottom: 32px;
  }
  ::v-deep{
    .el-tree .el-tree-node__content{
      height: 28px;
    }
  }
  </style>
