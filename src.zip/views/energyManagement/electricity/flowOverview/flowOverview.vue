<template>
    <el-container class="all">
        <el-row :gutter="1" style="width: 100%;">
            <el-col :span="24" :xs="24" style="padding: 20px 20px 0 20px; width: 100%;">
                <el-form :inline="true" :model="formData" :rules="rules" label-width="10px" ref="elForm" size="small">
                    <span style="margin-right: 10px">流程：</span>
                    <el-select v-model="flowId" placeholder="请选择">
                        <el-option v-for="item in flowIdOptions" :key="item.id" :label="item.name" :value="item.id">
                        </el-option>
                    </el-select>
                    <el-form-item>
                        <el-date-picker align="right" end-placeholder="结束日期" range-separator="至"
                            start-placeholder="开始日期" type="daterange" unlink-panels v-model="formData.dateRange_day"
                            value-format="yyyy-MM-dd" />
                    </el-form-item>

                    <el-form-item size="small">
                        <el-button @click="getList" type="primary">查询
                        </el-button>
                        <el-button @click="handleExport" icon="el-icon-download" type="warning">导出
                        </el-button>
                    </el-form-item>
                </el-form>
            </el-col>
            <el-col :span="24" :xs="24" style="width: 100%;">
                <el-main v-loading="loading" element-loading-text="拼命加载中" style="width: 100%;">
                    <el-table style="width: 100%;" :data="tableData" row-key="id" stripe border :height="windowHeight">
                        <el-table-column label="编号" align="center" width="100">
                            <template slot-scope="scop">
                                {{ scop.$index + 1 }}
                            </template>
                        </el-table-column>
                        <el-table-column label="开始时间" align="center" prop="begTime">
                            
                        </el-table-column>
                        <el-table-column label="结束时间" align="center" prop="stopTime">
                           
                        </el-table-column>
                        <el-table-column label="有功总电能" align="center" prop="total" />
                        <el-table-column label="操作" align="center" width="180" class-name="small-padding fixed-width">
                            <template slot-scope="scope">
                                <el-button size="mini" type="text" icon="el-icon-edit"
                                    @click="handleDetail(scope.row)">明细</el-button>

                            </template>
                        </el-table-column>
                    </el-table>
                </el-main>
            </el-col>
        </el-row>
        <!-- 流程明细对话框 -->
        <el-dialog :title="title" :visible.sync="open" :destroy-on-close="true" width="800px" append-to-body>
            <el-main v-loading="loading" element-loading-text="拼命加载中" style="width: 100%;">
                <el-table style="width: 100%;" :data="dtableData" row-key="" stripe border :height="windowHeight">
                    <el-table-column label="编号" align="center" width="100">
                        <template slot-scope="scop">
                            {{ scop.$index + 1 }}
                        </template>
                    </el-table-column>
                    <el-table-column align="center" v-for="item in dcolumns" :key="item.value" :prop="item.value"
                        :label="item.name" />
                </el-table>
               
            </el-main>
            <div slot="footer" class="dialog-footer">
                <el-button @click="handleExportDetail" icon="el-icon-download" type="warning">导出
                        </el-button>
                 
                    <el-button @click="cancel">取 消</el-button>
                </div>
        </el-dialog>
    </el-container>


</template>
  
<script>
import dayjs from 'dayjs'
import { getFlow, workflowReport, workflowReportExport, getFlowDetail,workflowDetailReportExport } from "@/api/plantThreeEnergyManagement/electricity/electricityDataAnalysis";

export default {
    name: "seeworkflowByDay",
    components: {
    },
    data() {
        return {
            windowHeight: window.innerHeight - 200,
            flowId: 1,
            pageFlowId: 1,
            flowIdOptions: [],
            loading: false,
            // 是否显示弹出层
            open: false,
            columns: [],
            tableData: [],
            dcolumns: [],
            dtableData: [],
            dbegTime:null,
            dstopTime:null,
            title: "",
            formData: {
                dateRange_day: [],
                needMult: false,
            },
            rules: {},
        };
    },

    computed: {
    },
    created() {
        window.addEventListener('resize', this.getHeight)
    },
    mounted() {

        const route = this.$route.name.split('/')
        const param = route[route.length - 1]

        if (!isNaN(Number.parseInt(param))) {
            this.pageFlowId = Number.parseInt(param)
        }

        this.formData.dateRange_day = [dayjs().format('YYYY-MM-01'), dayjs().format('YYYY-MM-DD')]
        this.getOptions();
        this.getList()
    },
    destroyed() {
        window.removeEventListener('resize', this.getHeight)
    },
    methods: {
        //根据窗口大小调整
        getHeight() {
            this.windowHeight = window.innerHeight - 250
        },
        /** 根据当前选项查询数据 */
        getList() {
            this.loading = true;
            const { dateRange_day = [], needMult } = this.formData
            const [beginTime, endTime] = dateRange_day
            console.log(this.flowId);
            workflowReport({
                flowId: this.flowId,
                beginTime: beginTime,
                endTime: endTime,
                needMult: needMult ? 1 : 0,
            })
                .then(({ data = {} }) => {
                    console.log(data)
                    //const { columns = [], tableData = [] } = data
                    //this.columns = [{name:'序号',value:'id'},{name:'流程号',value:'flowId'},{name:'开始时间',value:'begTime'},{name:'结束时间',value:'stopTime'},{name:'有功总电能',value:'total'}]
                    this.tableData = data
                })
                .finally((res) => {
                    this.loading = false;
                });
        },
        getOptions() {
            this.loading = true;
            getFlow().then(({ data = [] }) => {
                console.log('data', data)
                this.flowIdOptions = data
            })
        },
        onChangeNeedMult() {
            this.getList();
        },
        /** 导出按钮操作 */
        handleExport() {
            const { dateRange_day = [], needMult } = this.formData
            const [beginTime, endTime] = dateRange_day
            const param = {
                flowId: this.flowId,
                beginTime: beginTime,
                endTime: endTime,
                needMult: needMult ? 1 : 0,
            }

            this.$confirm("是否确认导出所有用户数据项?", "警告", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning",
            })
                .then(function () {
                    return workflowReportExport(param);
                })
                .then((response) => {
                    this.download(response.msg);
                })
                .catch(function () { });
        },
        handleExportDetail() {
          
            const param = {
                flowId: this.flowId,
                beginTime: this.dbegTime,
                endTime: this.dstopTime
            }

            this.$confirm("是否确认导出所有用户数据项?", "警告", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning",
            })
                .then(function () {
                    return workflowDetailReportExport(param);
                })
                .then((response) => {
                    this.download(response.msg);
                })
                .catch(function () { });
        },
        
        /** 点击明细 */
        handleDetail(row) {
            this.flowId=row.flowId;
            this.dbegTime=row.begTime;
            this.dstopTime=row.stopTime;
            const query = {
                flowId: row.flowId,
                beginTime: row.begTime,
                endTime: row.stopTime
            }
            this.open = true;
            getFlowDetail(query).then(response => {
                this.dcolumns = response.data.columns
                this.dtableData = response.data.tableData              
                this.title = "流程明细";              
            });
        },
        // 取消按钮
        cancel() {
            this.open = false;
            this.reset();
        }

    },
};
</script>
  
<style scoped>
.all {
    background: #fff;
}

.el-aside {
    background: #fff;
}

.chart-wrapper {
    background: #fff;
    padding: 16px 16px 0;
    margin-bottom: 32px;
}
</style>
  