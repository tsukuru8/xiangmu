<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" :inline="true" label-width="68px">
      <el-form-item label="设备名称" prop="deviceName">
        <el-input
          v-model="queryParams.deviceName"
          placeholder="请输入设备名称"
          clearable
          size="small"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="点位名称" prop="alarmPoint">
        <el-input
          v-model="queryParams.alarmPoint"
          placeholder="请输入点位名称"
          clearable
          size="small"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="告警信息" prop="alarmContent">
        <el-input
          v-model="queryParams.alarmContent"
          placeholder="请输入告警信息"
          clearable
          size="small"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="告警状态" prop="alarmStatus">
        <el-select
          v-model="queryParams.alarmStatus"
          placeholder="请选择告警状态"
          size="small"
          clearable
          @keyup.enter.native="handleQuery"
        >
          <el-option
            v-for="item in alarmStatusOptions"
            :key="item.value"
            :label="item.label"
            :value="item.value">
          </el-option>
        </el-select>
      </el-form-item>
<!--      <el-form-item label="告警时间" prop="creatTime">-->
<!--        <el-date-picker-->
<!--          clearable size="small" style="width: 200px"-->
<!--          v-model="queryParams.creatTime"-->
<!--          type="date"-->
<!--          value-format="yyyy-MM-dd"-->
<!--          placeholder="选择告警时间">-->
<!--        </el-date-picker>-->
<!--      </el-form-item>-->
<!--      <el-form-item label="恢复时间" prop="updateTime">-->
<!--        <el-date-picker-->
<!--          clearable size="small" style="width: 200px"-->
<!--          v-model="queryParams.updateTime"-->
<!--          type="date"-->
<!--          value-format="yyyy-MM-dd"-->
<!--          placeholder="选择恢复时间">-->
<!--        </el-date-picker>-->
<!--      </el-form-item>-->
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="warning"
          icon="el-icon-download"
          size="mini"
          @click="handleExport"
        >导出</el-button>
      </el-col>
    </el-row>

    <el-table v-loading="loading" :data="tableList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column label="序号"  type="index" align="center" prop="id" />
      <el-table-column label="设备名称" align="center" prop="deviceName"/>
      <el-table-column label="主题" align="center" prop="topics"/>
      <el-table-column label="点位名称" align="center" prop="alarmPoint" />
      <el-table-column label="点位值" align="center" prop="pointValue" />
      <el-table-column label="告警信息" align="center" prop="alarmContent" />
      <el-table-column label="告警状态" align="center" prop="alarmStatus" :formatter="()=>formmatterStatus">
        <template slot-scope="scope">
          <span>{{ scope.row.alarmStatus === 0 ? '已恢复' : '未恢复'}}</span>
        </template>
      </el-table-column>
      <el-table-column label="告警时间" align="center" prop="creatTime" width="180">
      </el-table-column>
      <el-table-column label="恢复时间" align="center" prop="updateTime" width="180">
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />
  </div>
</template>

<script>
import { listAlarm, delAlarm,exportAlarm } from '@/api/plantThreeEnergyManagement/electricity/electricityDataAnalysis';
export default {
  name: "Configure",
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 总条数
      total: 0,
      // 表格数据
      tableList: [],
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        deviceName: undefined,
        alarmPoint: undefined,
        alarmContent:undefined,
        alarmStatus: undefined,
        creatTime: undefined,
        updateTime:undefined
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {},
      alarmStatusOptions:[{
        value: '1',
        label: '未恢复'
      }, {
        value: '0',
        label: '已恢复'
      }]
    };
  },
  created() {
    this.getList();
    this.timer();
  },
  methods: {
    /** 查询列表 */
    getList() {
      this.loading = true;
      listAlarm(this.queryParams).then(response => {
        this.tableList = response.rows;
        this.total = response.total;
        this.loading = false;
      });
    },
    // 表单重置
    reset() {
      this.form = {
        deviceName: undefined,
        alarmPoint: undefined,
        alarmContent:undefined,
        alarmStatus: undefined,
        creatTime: undefined,
        updateTime:undefined
      };
      this.resetForm("form");
    },
    formmatterStatus(row){
      console.log('row',row);
      row.alarmStatus
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm");
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.id)
      this.single = selection.length != 1
      this.multiple = !selection.length
    },
    /** 导出按钮操作 */
    handleExport() {
      const queryParams = this.queryParams;
      this.$confirm('是否确认导出所有告警数据项?', "警告", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      }).then(function() {
        return exportAlarm(queryParams);
      }).then(response => {
        this.download(response.msg);
      }).catch(function() {});
    },
    // 这是一个定时器
    timer() {
      return setInterval(()=>{
        this.getList()
      },60000)
    },
  }
};
</script>
