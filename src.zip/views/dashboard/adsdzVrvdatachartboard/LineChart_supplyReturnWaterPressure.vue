<template>
  <div :class="className" :style="{height:height,width:width}"/>
</template>

<script>
  import echarts from 'echarts'
  import resize from '../mixins/resize'

  require('echarts/theme/macarons') // echarts theme

  export default {
    mixins: [resize],
    props: {
      className: {
        type: String,
        default: 'chart'
      },
      width: {
        type: String,
        default: '100%'
      },
      height: {
        type: String,
        default: '330px'
      },
      autoResize: {
        type: Boolean,
        default: true
      },
      chartData: {
        type: Object,
        required: true
      }
    },
    data() {
      return {
        chart: null
      }
    },
    watch: {
      chartData: {
        deep: true,
        handler(val) {
          this.setOptions(val)
        }
      }
    },
    mounted() {
      this.$nextTick(() => {
        this.initChart()
      })
    },
    // beforeDestroy() {
    //   if (!this.chart) {
    //     return
    //   }
    //   this.chart.dispose()
    //   this.chart = null
    // },
    methods: {
      initChart() {
        this.chart = echarts.init(this.$el, 'macarons')
        this.setOptions(this.chartData)
      },
      setOptions({timeData, firstChillingWaterSupplyReturnPressureDifference, secondChillingWaterSupplyReturnPressureDifference, firstCoolingWaterSupplyReturnPressureDifference, secondCoolingWaterSupplyReturnPressureDifference,chillingWaterPipeSupplyReturnPressureDifference,hotWaterSupplyReturnPressureDifference} = {}) {
        this.chart.setOption({
          xAxis: {
            data: timeData,
            boundaryGap: false,
            axisTick: {
              show: false
            }
          },
          grid: {
            left: '3%',
            right: '5%',
            bottom: '10%',
            top: '3%',
            containLabel: true
          },
          tooltip: {
            trigger: 'axis',
            axisPointer: {
              type: 'cross'
            },
            padding: [5, 10]
          },
          yAxis: {
            axisTick: {
              show: false
            }
          },
          legend: {
            data: ['1#冷冻水泵供回水压力差', '2#冷冻水泵供回水压力差', '1#冷却水泵供回水压力差', '2#冷却水泵供回水压力差','冷冻水管供回水压差','热水系统供回水压力差'],
            icon:'roundRect',
            y:'bottom',
            itemWidth: 15,
            itemHeight: 15,
          },
          series: [{
            name: '1#冷冻水泵供回水压力差',
            smooth: true,
            type: 'line',
            itemStyle: {
              normal: {
                color: '#63b2ee',
                lineStyle: {
                  color: '#63b2ee',
                  width: 2
                },
                areaStyle: {
                  color: '#63b2ee'
                }
              }
            },
            data: firstChillingWaterSupplyReturnPressureDifference,
            animationDuration: 2800,
            animationEasing: 'quadraticOut'
          },
            {
              name: '2#冷冻水泵供回水压力差',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#76da91',
                  lineStyle: {
                    color: '#76da91',
                    width: 2
                  },
                  areaStyle: {
                    color: '#76da91'
                  }
                }
              },
              data: secondChillingWaterSupplyReturnPressureDifference,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            },
            {
              name: '1#冷却水泵供回水压力差',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#f8cb7f',
                  lineStyle: {
                    color: '#f8cb7f',
                    width: 2
                  },
                  areaStyle: {
                    color: '#f8cb7f'
                  }
                }
              },
              data: firstCoolingWaterSupplyReturnPressureDifference,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            },
            {
              name: '2#冷却水泵供回水压力差',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#f89588',
                  lineStyle: {
                    color: '#f89588',
                    width: 2
                  },
                  areaStyle: {
                    color: '#f89588'
                  }
                }
              },
              data: secondCoolingWaterSupplyReturnPressureDifference,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            },
            {
              name: '冷冻水管供回水压差',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#7cd6cf',
                  lineStyle: {
                    color: '#7cd6cf',
                    width: 2
                  },
                  areaStyle: {
                    color: '#7cd6cf'
                  }
                }
              },
              data: chillingWaterPipeSupplyReturnPressureDifference,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            },
            {
              name: '热水系统供回水压力差',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#F9B980',
                  lineStyle: {
                    color: '#F9B980',
                    width: 2
                  },
                  areaStyle: {
                    color: '#F9B980'
                  }
                }
              },
              data: hotWaterSupplyReturnPressureDifference,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            }]
        })
      },
    }
  }
</script>
