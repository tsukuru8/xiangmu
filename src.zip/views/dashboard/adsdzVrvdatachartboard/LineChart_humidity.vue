<template>
  <div :class="className" :style="{height:height,width:width}"/>
</template>

<script>
  import echarts from 'echarts'
  import resize from '../mixins/resize'

  require('echarts/theme/macarons') // echarts theme

  export default {
    mixins: [resize],
    props: {
      className: {
        type: String,
        default: 'chart'
      },
      width: {
        type: String,
        default: '100%'
      },
      height: {
        type: String,
        default: '330px'
      },
      autoResize: {
        type: Boolean,
        default: true
      },
      chartData: {
        type: Object,
        required: true
      }
    },
    data() {
      return {
        chart: null
      }
    },
    watch: {
      chartData: {
        deep: true,
        handler(val) {
          this.setOptions(val)
        }
      }
    },
    mounted() {
      this.$nextTick(() => {
        this.initChart()
      })
    },
    // beforeDestroy() {
    //   if (!this.chart) {
    //     return
    //   }
    //   this.chart.dispose()
    //   this.chart = null
    // },
    methods: {
      initChart() {
        this.chart = echarts.init(this.$el, 'macarons')
        this.setOptions(this.chartData)
      },
      setOptions({timeData, outsideHumidity, bondingAreaHumidity,solidCrystalAreaHumidity,dispensingAreaHumidity,bakingAreaHumidity,packageAreaHumidity} = {}) {
        this.chart.setOption({
          xAxis: {
            data: timeData,
            boundaryGap: false,
            axisTick: {
              show: false
            }
          },
          grid: {
            left: '3%',
            right: '5%',
            bottom: '10%',
            top: '3%',
            containLabel: true
          },
          tooltip: {
            trigger: 'axis',
            axisPointer: {
              type: 'cross'
            },
            padding: [5, 10]
          },
          yAxis: {
            axisTick: {
              show: false
            },
            //限定y轴最值
            max:100
          },
          legend: {
            data: ['室外湿度', '焊线区湿度','固晶区湿度','点胶区湿度','烘烤区湿度','封装区湿度'],
            y:'bottom',
            icon: 'roundRect',
            itemWidth: 15,
            itemHeight: 15,
          },
          series: [{
            name: '室外湿度',
            smooth: true,
            type: 'line',
            itemStyle: {
              normal: {
                color: '#63b2ee',
                lineStyle: {
                  color: '#63b2ee',
                  width: 2
                },
                areaStyle: {
                  color: '#63b2ee'
                }
              }
            },
            data: outsideHumidity,
            animationDuration: 2800,
            animationEasing: 'quadraticOut'
          },
            {
              name: '焊线区湿度',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#76da91',
                  lineStyle: {
                    color: '#76da91',
                    width: 2
                  },
                  areaStyle: {
                    color: '#76da91'
                  }
                }
              },
              data: bondingAreaHumidity,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            },
            {
              name: '固晶区湿度',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#f8cb7f',
                  lineStyle: {
                    color: '#f8cb7f',
                    width: 2
                  },
                  areaStyle: {
                    color: '#f8cb7f'
                  }
                }
              },
              data: solidCrystalAreaHumidity,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            },
            {
              name: '点胶区湿度',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#f89588',
                  lineStyle: {
                    color: '#f89588',
                    width: 2
                  },
                  areaStyle: {
                    color: '#f89588'
                  }
                }
              },
              data: dispensingAreaHumidity,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            },
            {
              name: '烘烤区湿度',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#7cd6cf',
                  lineStyle: {
                    color: '#7cd6cf',
                    width: 2
                  },
                  areaStyle: {
                    color: '#7cd6cf'
                  }
                }
              },
              data: bakingAreaHumidity,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            },
            {
              name: '封装区湿度',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#F9B980',
                  lineStyle: {
                    color: '#F9B980',
                    width: 2
                  },
                  areaStyle: {
                    color: '#F9B980'
                  }
                }
              },
              data: packageAreaHumidity,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            },
          ]
        })
      },
    }
  }
</script>
