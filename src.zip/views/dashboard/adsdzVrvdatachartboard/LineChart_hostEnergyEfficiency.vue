<template>
  <div :class="className" :style="{height:height,width:width}"/>
</template>

<script>
  import echarts from 'echarts'
  import resize from '../mixins/resize'

  require('echarts/theme/macarons') // echarts theme

  export default {
    mixins: [resize],
    props: {
      className: {
        type: String,
        default: 'chart'
      },
      width: {
        type: String,
        default: '100%'
      },
      height: {
        type: String,
        default: '330px'
      },
      autoResize: {
        type: Boolean,
        default: true
      },
      chartData: {
        type: Object,
        required: true
      }
    },
    data() {
      return {
        chart: null
      }
    },
    watch: {
      chartData: {
        deep: true,
        handler(val) {
          this.setOptions(val)
        }
      }
    },
    mounted() {
      this.$nextTick(() => {
        this.initChart()
      })
    },
    // beforeDestroy() {
    //   if (!this.chart) {
    //     return
    //   }
    //   this.chart.dispose()
    //   this.chart = null
    // },
    methods: {
      initChart() {
        this.chart = echarts.init(this.$el, 'macarons')
        this.setOptions(this.chartData)
      },
      setOptions({timeData, eers, instantEerplant, calculateEerplant, instantCop, calculateCop} = {}) {
        this.chart.setOption({
          xAxis: {
            data: timeData,
            boundaryGap: false,
            axisTick: {
              show: false
            }
          },
          grid: {
            left: '3%',
            right: '5%',
            bottom: '10%',
            top: '3%',
            containLabel: true
          },
          tooltip: {
            trigger: 'axis',
            axisPointer: {
              type: 'cross'
            },
            padding: [5, 10]
          },
          yAxis: {
            axisTick: {
              show: false
            }
          },
          legend: {
            data: ['空调系统能效比EERS', '制冷站瞬时能耗比EERplant', '制冷站累计能耗比EERplant', '冰水主机瞬时COP','冰水主机累计COP'],
            icon:'roundRect',
            y:'bottom',
            itemWidth: 15,
            itemHeight: 15,
          },
          series: [{
            name: '空调系统能效比EERS',
            smooth: true,
            type: 'line',
            itemStyle: {
              normal: {
                color: '#63b2ee',
                lineStyle: {
                  color: '#63b2ee',
                  width: 2
                },
                areaStyle: {
                  color: '#63b2ee'
                }
              }
            },
            data: eers,
            animationDuration: 2800,
            animationEasing: 'quadraticOut'
          },
            {
              name: '制冷站瞬时能耗比EERplant',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#76da91',
                  lineStyle: {
                    color: '#76da91',
                    width: 2
                  },
                  areaStyle: {
                    color: '#76da91'
                  }
                }
              },
              data: instantEerplant,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            },
            {
              name: '制冷站累计能耗比EERplant',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#f8cb7f',
                  lineStyle: {
                    color: '#f8cb7f',
                    width: 2
                  },
                  areaStyle: {
                    color: '#f8cb7f'
                  }
                }
              },
              data: calculateEerplant,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            },
            {
              name: '冰水主机瞬时COP',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#f89588',
                  lineStyle: {
                    color: '#f89588',
                    width: 2
                  },
                  areaStyle: {
                    color: '#f89588'
                  }
                }
              },
              data: instantCop,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            },
            {
              name: '冰水主机累计COP',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#7cd6cf',
                  lineStyle: {
                    color: '#7cd6cf',
                    width: 2
                  },
                  areaStyle: {
                    color: '#7cd6cf'
                  }
                }
              },
              data: calculateCop,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            },
          ]
        })
      },
    }
  }
</script>
