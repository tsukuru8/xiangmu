<template>
  <div :class="className" :style="{height:height,width:width}"/>
</template>

<script>
  import echarts from 'echarts'
  import resize from '../mixins/resize'

  require('echarts/theme/macarons') // echarts theme

  export default {
    mixins: [resize],
    props: {
      className: {
        type: String,
        default: 'chart'
      },
      width: {
        type: String,
        default: '100%'
      },
      height: {
        type: String,
        default: '330px'
      },
      autoResize: {
        type: Boolean,
        default: true
      },
      chartData: {
        type: Object,
        required: true
      }
    },
    data() {
      return {
        chart: null
      }
    },
    watch: {
      chartData: {
        deep: true,
        handler(val) {
          this.setOptions(val)
        }
      }
    },
    mounted() {
      this.$nextTick(() => {
        this.initChart()
      })
    },
    // beforeDestroy() {
    //   if (!this.chart) {
    //     return
    //   }
    //   this.chart.dispose()
    //   this.chart = null
    // },
    methods: {
      initChart() {
        this.chart = echarts.init(this.$el, 'macarons')
        this.setOptions(this.chartData)
      },
      setOptions({timeData, outsideTemp, chillingWaterSupplyTemp,chillingWaterReturnTemp,chillingWaterSupplyReturnTempDifference,
                   coolingWaterSupplyTemp,coolingWaterReturnTemp,coolingWaterSupplyReturnTempDifference,firstColdWaterEvaporatorTemp,firstColdWaterCondenserTemp,
                   secondColdWaterEvaporatorTemp,secondColdWaterCondenserTemp,hotWaterSupplyTemp,hotWaterReturnTemp,hotWaterSupplyReturnTempDifference,
                   bondingAreaTemp,solidCrystalAreaTemp,dispensingAreaTemp,bakingAreaTemp,packageAreaTemp} = {}) {
        this.chart.setOption({
          xAxis: {
            data: timeData,
            boundaryGap: false,
            axisTick: {
              show: false
            }
          },
          //坐标轴的位置
          grid: {
            left:'3%',
            right: '5%',
            bottom:'25%',
            top: '3%',
            containLabel: true
          },
          tooltip: {
            trigger: 'axis',
            axisPointer: {
              type: 'cross'
            },
            padding: [5, 10]
          },
          yAxis: {
            axisTick: {
              show: false,
            },
            //type:'value',
            max:50
          },
          legend: {
            data: ['室外温度','焊线区温度','固晶区温度','点胶区温度','烘烤区温度','封装区温度','冷冻水供水温度','冷冻水回水温度','冷冻水供回水温差',
              '冷却水供水温度','冷却水回水温度','冷却水供回水温差',
              '热水供水温度','热水回水温度','热水供回水温差','1#冷水主机蒸发器趋近温度','1#冷水主机冷凝器趋近温度', '2#冷水主机蒸发器趋近温度','2#冷水主机冷凝器趋近温度'],
            y:'bottom',
            x:'right',
            icon: 'roundRect',
            itemWidth: 15,
            itemHeight: 15,
            selected:{
              '冷冻水供水温度':false,
              '冷冻水回水温度':false,
              '冷冻水供回水温差':false,
              '冷却水供水温度':false,
              '冷却水回水温度':false,
              '冷却水供回水温差':false,
              '1#冷水主机蒸发器趋近温度':false,
              '1#冷水主机冷凝器趋近温度':false,
              '2#冷水主机蒸发器趋近温度':false,
              '2#冷水主机冷凝器趋近温度':false,
              '热水供水温度':false,
              '热水回水温度':false,
              '热水供回水温差':false
            }
          },
          series: [{
            icon:"triangle",
            name: '室外温度',
            smooth: true,
            type: 'line',
            itemStyle: {
              normal: {
                color: '#f89588',
                lineStyle: {
                  color: '#f89588',
                  width: 2
                },
                areaStyle: {
                  color: '#f89588'
                }
              }
            },
            data: outsideTemp,
            animationDuration: 2800,
            animationEasing: 'quadraticOut'
          },{
            name: '焊线区温度',
            smooth: true,
            type: 'line',
            itemStyle: {
              normal: {
                color: '#63b2ee',
                lineStyle: {
                  color: '#63b2ee',
                  width: 2
                },
                areaStyle: {
                  color: '#63b2ee'
                }
              }
            },
            data: bondingAreaTemp,
            animationDuration: 2800,
            animationEasing: 'quadraticOut'
          },{
            name: '固晶区温度',
            smooth: true,
            type: 'line',
            itemStyle: {
              normal: {
                color: '#76da91',
                lineStyle: {
                  color: '#76da91',
                  width: 2
                },
                areaStyle: {
                  color: '#76da91'
                }
              }
            },
            data: solidCrystalAreaTemp,
            animationDuration: 2800,
            animationEasing: 'quadraticOut'
          },{
            name: '点胶区温度',
            smooth: true,
            type: 'line',
            itemStyle: {
              normal: {
                color: '#efa666',
                lineStyle: {
                  color: '#efa666',
                  width: 2
                },
                areaStyle: {
                  color: '#efa666'
                }
              }
            },
            data: dispensingAreaTemp,
            animationDuration: 2800,
            animationEasing: 'quadraticOut'
          },{
            name: '烘烤区温度',
            smooth: true,
            type: 'line',
            itemStyle: {
              normal: {
                color: '#FFCCCC',
                lineStyle: {
                  color: '#FFCCCC',
                  width: 2
                },
                areaStyle: {
                  color: '#FFCCCC'
                }
              }
            },
            data: bakingAreaTemp,
            animationDuration: 2800,
            animationEasing: 'quadraticOut'
          },
            {
              name: '封装区温度',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#CCFFFF',
                  lineStyle: {
                    color: '#CCFFFF',
                    width: 2
                  },
                  areaStyle: {
                    color: '#CCFFFF'
                  }
                }
              },
              data: packageAreaTemp,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            },
            {
              name: '冷冻水供水温度',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#05f8d6',
                  lineStyle: {
                    color: '#05f8d6',
                    width: 2
                  },
                  areaStyle: {
                    color: '#05f8d6'
                  }
                }
              },
              data: chillingWaterSupplyTemp,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            },{
              name: '冷冻水回水温度',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#0082fc',
                  lineStyle: {
                    color: '#0082fc',
                    width: 2
                  },
                  areaStyle: {
                    color: '#0082fc'
                  }
                }
              },
              data: chillingWaterReturnTemp,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            },{
              name: '冷冻水供回水温差',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#fdd845',
                  lineStyle: {
                    color: '#fdd845',
                    width: 2
                  },
                  areaStyle: {
                    color: '#fdd845'
                  }
                }
              },
              data: chillingWaterSupplyReturnTempDifference,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            },{
              name: '冷却水供水温度',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#22ed7c',
                  lineStyle: {
                    color: '#22ed7c',
                    width: 2
                  },
                  areaStyle: {
                    color: '#22ed7c'
                  }
                }
              },
              data: coolingWaterSupplyTemp,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            },{
              name: '冷却水回水温度',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#09b0d3',
                  lineStyle: {
                    color: '#09b0d3',
                    width: 2
                  },
                  areaStyle: {
                    color: '#09b0d3'
                  }
                }
              },
              data: coolingWaterReturnTemp,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            },{
              name: '冷却水供回水温差',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#1d27c9',
                  lineStyle: {
                    color: '#1d27c9',
                    width: 2
                  },
                  areaStyle: {
                    color: '#1d27c9'
                  }
                }
              },
              data: coolingWaterSupplyReturnTempDifference,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            },{
              name: '1#冷水主机蒸发器趋近温度',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#f9e264',
                  lineStyle: {
                    color: '#f9e264',
                    width: 2
                  },
                  areaStyle: {
                    color: '#f9e264'
                  }
                }
              },
              data: firstColdWaterEvaporatorTemp,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            },{
              name: '1#冷水主机冷凝器趋近温度',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#f47a75',
                  lineStyle: {
                    color: '#f47a75',
                    width: 2
                  },
                  areaStyle: {
                    color: '#f47a75'
                  }
                }
              },
              data: firstColdWaterCondenserTemp,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            },{
              name: '2#冷水主机蒸发器趋近温度',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#009db2',
                  lineStyle: {
                    color: '#009db2',
                    width: 2
                  },
                  areaStyle: {
                    color: '#009db2'
                  }
                }
              },
              data: secondColdWaterEvaporatorTemp,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            },{
              name: '2#冷水主机冷凝器趋近温度',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#024b51',
                  lineStyle: {
                    color: '#024b51',
                    width: 2
                  },
                  areaStyle: {
                    color: '#024b51'
                  }
                }
              },
              data: secondColdWaterCondenserTemp,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            },{
              name: '热水供水温度',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#0780cf',
                  lineStyle: {
                    color: '#0780cf',
                    width: 2
                  },
                  areaStyle: {
                    color: '#0780cf'
                  }
                }
              },
              data: hotWaterSupplyTemp,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            },{
              name: '热水回水温度',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#d5d6d8',
                  lineStyle: {
                    color: '#d5d6d8',
                    width: 2
                  },
                  areaStyle: {
                    color: '#d5d6d8'
                  }
                }
              },
              data: hotWaterReturnTemp,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            },{
              name: '热水供回水温差',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#765005',
                  lineStyle: {
                    color: '#765005',
                    width: 2
                  },
                  areaStyle: {
                    color: '#765005'
                  }
                }
              },
              data: hotWaterSupplyReturnTempDifference,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            }]
        })
      },
    }
  }
</script>
