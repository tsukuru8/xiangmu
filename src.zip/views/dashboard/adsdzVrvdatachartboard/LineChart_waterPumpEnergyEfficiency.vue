<template>
  <div :class="className" :style="{height:height,width:width}"/>
</template>

<script>
  import echarts from 'echarts'
  import resize from '../mixins/resize'

  require('echarts/theme/macarons') // echarts theme

  export default {
    mixins: [resize],
    props: {
      className: {
        type: String,
        default: 'chart'
      },
      width: {
        type: String,
        default: '100%'
      },
      height: {
        type: String,
        default: '330px'
      },
      autoResize: {
        type: Boolean,
        default: true
      },
      chartData: {
        type: Object,
        required: true
      }
    },
    data() {
      return {
        chart: null
      }
    },
    watch: {
      chartData: {
        deep: true,
        handler(val) {
          this.setOptions(val)
        }
      }
    },
    mounted() {
      this.$nextTick(() => {
        this.initChart()
      })
    },
    // beforeDestroy() {
    //   if (!this.chart) {
    //     return
    //   }
    //   this.chart.dispose()
    //   this.chart = null
    // },
    methods: {
      initChart() {
        this.chart = echarts.init(this.$el, 'macarons')
        this.setOptions(this.chartData)
      },
      setOptions({timeData, wtfcwpEff, wtfchwEff} = {}) {
        this.chart.setOption({
          xAxis: {
            data: timeData,
            boundaryGap: false,
            axisTick: {
              show: false
            }
          },
          grid: {
            left: '3%',
            right: '5%',
            bottom: '10%',
            top: 30,
            containLabel: true
          },
          tooltip: {
            trigger: 'axis',
            axisPointer: {
              type: 'cross'
            },
            padding: [5, 10]
          },
          yAxis: {
            axisTick: {
              show: false
            }
          },
          legend: {
            data: ['冷却水泵效率', '冷冻水泵效率'],
            icon:'roundRect',
            y:'bottom',
            itemWidth: 15,
            itemHeight: 15,
          },
          series: [{
            name: '冷却水泵效率',
            smooth: true,
            type: 'line',
            itemStyle: {
              normal: {
                color: '#63b2ee',
                lineStyle: {
                  color: '#63b2ee',
                  width: 2
                },
                areaStyle: {
                  color: '#63b2ee'
                }
              }
            },
            data: wtfcwpEff,
            animationDuration: 2800,
            animationEasing: 'quadraticOut'
          },
            {
              name: '冷冻水泵效率',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#F9B980',
                  lineStyle: {
                    color: '#F9B980',
                    width: 2
                  },
                  areaStyle: {
                    color: '#F9B980'
                  }
                }
              },
              data: wtfchwEff,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            },
          ]
        })
      },
    }
  }
</script>
