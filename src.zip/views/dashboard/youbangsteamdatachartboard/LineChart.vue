<template>
  <div :class="className" :style="{height:height,width:width}"/>
</template>

<script>
  import echarts from 'echarts'
  import resize from '../mixins/resize'

  require('echarts/theme/macarons') // echarts theme

  export default {
    mixins: [resize],
    props: {
      className: {
        type: String,
        default: 'chart'
      },
      width: {
        type: String,
        default: '100%'
      },
      height: {
        type: String,
        default: '330px'
      },
      autoResize: {
        type: Boolean,
        default: true
      },
      chartData: {
        type: Object,
        required: true
      }
    },
    data() {
      return {
        chart: null
      }
    },
    watch: {
      chartData: {
        deep: true,
        handler(val) {
          this.setOptions(val)
        }
      }
    },
    mounted() {
      this.$nextTick(() => {
        this.initChart()
      })
    },
    methods: {
      initChart() {
        this.chart = echarts.init(this.$el, 'macarons')
        this.setOptions(this.chartData)
      },
      setOptions({timeData, scebData, scybData, bglData, zjbdwsylylData, yfjsfwbData} = {}) {
        this.chart.setOption({
          xAxis: {
            data: timeData,
            boundaryGap: false,
            axisTick: {
              show: false
            }
          },
          grid: {
            left: '3%',
            right: '3%',
            bottom: 20,
            top: 30,
            containLabel: true
          },
          tooltip: {
            trigger: 'axis',
            axisPointer: {
              type: 'cross'
            },
            padding: [5, 10]
          },
          yAxis: {
            axisTick: {
              show: false
            }
          },
          legend: {
            data: ['生产一部', '生产二部', '办公楼', '研发、技术服务部', '质检部、动物实验楼1楼']
          },
          series: [
            {
              name: '生产一部',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#B6A2DE',
                  lineStyle: {
                    color: '#B6A2DE',
                    width: 2
                  },
                  areaStyle: {
                    color: '#B6A2DE'
                  }
                }
              },
              data: scybData,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            }, {
              name: '生产二部',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#45C7C8',
                  lineStyle: {
                    color: '#45C7C8',
                    width: 2
                  },
                  areaStyle: {
                    color: '#45C7C8'
                  }
                }
              },
              data: scebData,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            },
            {
              name: '办公楼',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#5AB1EF',
                  lineStyle: {
                    color: '#5AB1EF',
                    width: 2
                  },
                  areaStyle: {
                    color: '#5AB1EF'
                  }
                }
              },
              data: bglData,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            },
            {
              name: '研发、技术服务部',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#D87A80',
                  lineStyle: {
                    color: '#D87A80',
                    width: 2
                  },
                  areaStyle: {
                    color: '#D87A80'
                  }
                }
              },
              data: yfjsfwbData,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            }, {
              name: '质检部、动物实验楼1楼',
              smooth: true,
              type: 'line',
              itemStyle: {
                normal: {
                  color: '#F9B980',
                  lineStyle: {
                    color: '#F9B980',
                    width: 2
                  },
                  areaStyle: {
                    color: '#F9B980'
                  }
                }
              },
              data: zjbdwsylylData,
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            }]
        })
      }
    }
  }
</script>
