<template>
  <div :class="className" :style="{ height: height, width: width }" />
</template>

<script>
  import echarts from "echarts";
  require("echarts/theme/macarons"); // echarts theme
  import resize from "../mixins/resize";

  export default {
    mixins: [resize],
    props: {
      className: {
        type: String,
        default: "chart",
      },
      width: {
        type: String,
        default: "2.456667rem",
      },
      height: {
        type: String,
        default: "1.866667rem",
      },
      chartData: {
        type: Object,
        required: true
      }
    },
    data() {
      return {
        chart: null,
      };
    },
    mounted() {
      this.$nextTick(() => {
        this.initChart();
      });
    },
    watch: {
      chartData: {
        deep: true,
        handler(val) {
          this.setOptions(val)
        }
      }
    },
    beforeDestroy() {
      if (!this.chart) {
        return;
      }
      this.chart.dispose();
      this.chart = null;
    },
    methods: {
      initChart() {
        this.chart = echarts.init(this.$el, "macarons");
        this.setOptions(this.chartData)
      },
      setOptions({fourInch, sixInch, lead, paster, smallSignal, junction, PV, SC} = {}){
        this.chart.setOption({
          title: {
            text: '氮气',
            left: 'center',
            top:'43%',
            textStyle: {
              //图例文字的样式
              color: "#fff",
              fontSize: 18,
            },
          },
          color: [
            "#00FCB7",
            "#FFB331",
            "#DB464C",
            "#01CBDF",
            "#1896ED",
            "#F38E62",
            "#8B66F2",
            "#1055D6",
          ],
          tooltip: {
            trigger: "item",
            // formatter: '{a} <br/>{b} : {c} ({d}%)'
          },
          legend: {
            itemWidth: 14,
            textStyle: {
              //图例文字的样式
              color: "#fff",
              fontSize: 12,
            },
            orient: "vertical",
            align: "left",
            bottom: "8%",
            y:'center',
            itemGap: 35,
            // color: 'white',
           data: ['框架桥工厂','四寸晶圆', '六寸晶圆', '光伏工厂', '小信号工厂','贴片器件工厂','引线器件工厂','供应链工厂']
          },
          series: [
            {
              type: "pie",
              radius: ["45%", "65%"],
              avoidLabelOverlap: false,
              minAngle: 30,
              label: {
                show: false,
                position: "center",
              },
              center: ["50%", "50%"],
              data: [
                { value: fourInch},
                { value: sixInch},
                { value: lead},
                { value: paster},
                { value: smallSignal},
                { value: junction},
                { value: PV},
                { value: SC},
              ],
              emphasis: {
                // label: {
                //   show: true,
                //   fontSize: "10",
                //   fontWeight: "bold",
                // },
                itemStyle: {
                  shadowBlur: 10,
                  shadowOffsetX: 0,
                  shadowColor: "rgba(0, 0, 0,0.5)",
                },
              },
              itemStyle: {
                normal: {
                  label: {
                    show: true,
                    // formatter: '{c} ({d}%)', //自定义显示格式(b:name, c:value, d:百分比)
                    // formatter: '{c}%' //自定义显示格式(b:name, c:value, d:百分比)
                    formatter:function(data){ return data.percent.toFixed(0)+"%";},
                    textStyle:{
              fontSize:10,
                      color:'#fff'
                    }
                  },
                  labelLine: {
                    //指示线状态
                    show: true,
                    smooth: 0.2,
                    length: 8,
                    length2: 18,
                  },
                },
              },
              labelLine: {
                show: false,
              },
            },
          ],
        });
      },
    },
  };
</script>
