<template>
  <div :class="className" :style="{ height: height, width: width }" />
</template>

<script>
import echarts from "echarts";
require("echarts/theme/macarons"); // echarts theme
import resize from "../mixins/resize";

export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: "chart",
    },
    width: {
      type: String,
      default: "100%",
    },
    height: {
      type: String,
      default: "2.2rem",
    },
    chartData: {
      type: Object,
      required: true,
    },
  },
  data() {
    return {
      chart: null,
    };
  },
  mounted() {
    this.$nextTick(() => {
      this.initChart();
    });
  },
  watch: {
    chartData: {
      deep: true,
      handler(val) {
        this.setOptions(val);
      },
    },
  },
  beforeDestroy() {
    if (!this.chart) {
      return;
    }
    this.chart.dispose();
    this.chart = null;
  },
  methods: {
    initChart() {
      this.chart = echarts.init(this.$el, "macarons");
      this.setOptions(this.chartData);
    },
    setOptions({
      fourInch,
      sixInch,
      smallSignal,
      paster,
      lead,
      junction,
      PV,
      SC,
    } = {}) {
      this.chart.setOption({
        title: {
          text: '100%',
          left: '19%',
          top:'40%',
          textStyle: {
            //图例文字的样式
            color: "#fff",
            fontSize: 18,
          },
        },
        color: [
          "#00FCB7",
          "#FFB331",
          "#DB464C",
          "#01CBDF",
          "#1896ED",
          "#F38E62",
          "#8B66F2",
          "#1055D6",
        ],
        tooltip: {
          trigger: "item",
          // formatter: '{a} <br/>{b} : {c} ({d}%)'
        },
        legend: {
          itemWidth: 10,
          itemHeight: 10,
          textStyle: {
            //图例文字的样式
            color: "#fff",
            fontSize: 12,
          },
          orient: "vertical",
          align: "left",
          top: "10%",
          left: "right",
          right:"1%",
          itemGap: 25,
          // color: 'white',
          // data: ['框架桥工厂','四寸晶圆', '六寸晶圆', '光伏工厂', '小信号工厂','贴片器件工厂','引线器件工厂','供应链工厂']
        },
        series: [
          {
            type: "pie",
            radius: ["50%", "70%"],
            minAngle: 30,
            avoidLabelOverlap: false,
            label: {
              normal: {
                show: true,
                formatter:function(data){console.log(data); return data.percent.toFixed(0)+"%";} ,
                // formatter: "{d|{d}%}\n{hr|}",
                // lineStyle: {
                //   color: "yellow",
                //   width: 2,
                // },
                // rich: {
                //   hr: {
                //     // borderColor: "#4681ec",
                //     width: "100%",
                //     borderWidth: 2,
                //     height: 0,
                //   },
                //   d: {
                //     fontSize: 10,
                //     align: "left",
                //     padding: 0,
                //   },
                // },
              },
              // position: "center",
            },
            center: ["25%", "45%"],
            data: [
              { value: fourInch, name: "四寸晶圆" },
              { value: sixInch, name: "六寸晶圆" },
              { value: lead, name: "引线器件工厂" },
              { value: paster, name: "贴片器件工厂" },
              { value: smallSignal, name: "小信号工厂" },
              { value: junction, name: "框架桥工厂" },
              { value: PV, name: "光伏工厂" },
              { value: SC, name: "供应链工厂" },
            ],
            emphasis: {
              position: "left",
              show: true,
              textStyle: {
                fontSize: "10",
                fontWeight: "bold",
              },
              length: 1,
              // label: {
              //   show: true,
              //   fontSize: "10",
              //   fontWeight: "bold",
              // },
              itemStyle: {
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: "rgba(0, 0, 0,0.5)",
              },
            },
            itemStyle: {
              normal: {
                label: {
                  show: true,
                //   // formatter: '{c} ({d}%)', //自定义显示格式(b:name, c:value, d:百分比)
                //   // formatter: '{c}%' //自定义显示格式(b:name, c:value, d:百分比)
                //   formatter:function(data){ return data.percent.toFixed(0)+"%";},
                  textStyle:{
                    fontSize:10,
                    color:'#fff'
                  }
                },
                labelLine: {
                  //指示线状态
                  show: true,
                  // smooth: 0.2,
                  length: 8,
                  length2: 20,
                },
              },
            },
            labelLine: {
              show: false,
            },
          },
        ],
      });
    },
  },
};
</script>
