<template>
  <div :class="className" :style="{height:height,width:width}" />
</template>

<script>
  import echarts from 'echarts'
  require('echarts/theme/macarons') // echarts theme
  import resize from '../mixins/resize'

  export default {
    mixins: [resize],
    props: {
      className: {
        type: String,
        default: 'chart'
      },
      width: {
        type: String,
        default: '100%'
      },
      height: {
        type: String,
        // default: '1.466667rem'
      default: "1.866667rem",
      },
      chartData: {
        type: Object,
        required: true
      }
    },
    data() {
      return {
        chart: null
      }
    },
    mounted() {
      this.$nextTick(() => {
        this.initChart()
      })
    },
    watch: {
      chartData: {
        deep: true,
        handler(val) {
          this.setOptions(val)
        }
      }
    },
    beforeDestroy() {
      if (!this.chart) {
        return
      }
      this.chart.dispose()
      this.chart = null
    },
    methods: {
      initChart() {
        this.chart = echarts.init(this.$el, 'macarons')
        this.setOptions(this.chartData)
      },
      setOptions({CIC,CIT,park} = {}) {
        this.chart.setOption({
          title: {
            text: '100%',
            left: '24.5%',
            top:'36%',
            textStyle: {
              //图例文字的样式
              color: "#fff",
              fontSize: 16,
            },
          },
          color: [
            "#04F7BD",
            "#FF8441",
            "#129BE9",
          ],
          tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b} : {c} ({d}%)'
          },
          legend: {
            show:false,
           itemWidth: 10,
          itemHeight: 10,
            textStyle:{//图例文字的样式
              color:'#fff',
              fontSize:10
            },
            orient: 'vertical',
            //图例居中
            top: "10%",
          left: "60%",
          bottom:'0',
          itemGap: 15,
            //data: ['一厂','二厂', '三厂', '电镀', '泗洪']
          },
          series: [
            {
              type: 'pie',
              radius: ["45%", "65%"],
              avoidLabelOverlap: false,
              label: {
                show: false,
                position: "center",
              },
              center: ["30%", "42%"],
              data: [
                {value: CIC},
                {value: CIT},
                {value: park},

              ],
              emphasis: {
                itemStyle: {
                  shadowBlur: 10,
                  shadowOffsetX: 0,
                  shadowColor: 'rgba(0, 0, 0,0.5)'
                }
              },
              itemStyle: {
                normal: {
                  label: {
                    show: true,
                    // formatter: '{c} ({d}%)', //自定义显示格式(b:name, c:value, d:百分比)
                    // formatter: '{c}%' //自定义显示格式(b:name, c:value, d:百分比)
                    formatter:function(data){ return data.percent.toFixed(0)+"%";} ,
                    textStyle:{
                       fontSize:10,
                      color:'#fff'
                    }
                  },
                  labelLine: {
                    //指示线状态
                    show: true,
                    // smooth: 0.2,
                    length: 8,
                    length2: 20,
                  },
                },
              },
              labelLine: {
                show: false,
              },
            }
          ]
        })
      }


    }
  }
</script>
