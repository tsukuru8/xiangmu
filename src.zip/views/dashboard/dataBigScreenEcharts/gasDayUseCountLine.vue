<template>
  <div :class="className" :style="{ height: height, width: width }" />
</template>

<script>
  import echarts from "echarts";
  import resize from "../mixins/resize";

  require("echarts/theme/macarons"); // echarts theme

  export default {
    mixins: [resize],
    props: {
      className: {
        type: String,
        default: "chart",
      },
      width: {
        type: String,
        default: "100%",
      },
      height: {
        type: String,
        // default: "3rem",
        default: "1.5rem",
      },
      autoResize: {
        type: Boolean,
        default: true,
      },
      chartData: {
        type: Object,
        required: true,
      },
    },
    data() {
      return {
        chart: null,
      };
    },
    watch: {
      chartData: {
        deep: true,
        handler(val) {
          this.setOptions(val);
        },
      },
    },
    mounted() {
      this.$nextTick(() => {
        this.initChart();
      });
    },
    // beforeDestroy() {
    //   if (!this.chart) {
    //     return
    //   }
    //   this.chart.dispose()
    //   this.chart = null
    // },
    methods: {
      initChart() {
        this.chart = echarts.init(this.$el, "macarons");
        this.setOptions(this.chartData);
      },
      setOptions({ abscissa, curList } = {}) {
        this.chart.setOption({
          // title: {
          //   // text: '日费用统计',
          //   subtext: "单位:元",
          //   left:"2%",
          //   top:"0",
          //   // bottom:"85%",
          //   // padding: 4,
          //   subtextStyle: {
          //     fontSize: 10,
          //     color: "#fff",
          //   },
          // },
          grid: {
            left:'15%',
            right:'2%',
            top:'5%',
            bottom:'15%',
            show: true,
            backgroundColor : '#0f204c',
            borderColor: "transparent",
            // backgroundColor: "rgba(15,32,76,0)",
          },
          xAxis: {
            name:'日',
            nameTextStyle:{
              // fontSize:10,
              color:"#fff"
            },
            data: abscissa || [],
            axisLine: {
              lineStyle: {
                color: "#6889D8",
              },
            },
            // type: "category",
            // boundaryGap: false,
            // axisTick: {
            //   show: false
            // },
            // axisTick: {
            //   show: false,
            // },
            // axisLine: {
            //   show: false,
            // },
            // z: 10,
            axisLabel: {
              // margin:8,
              textStyle: {
                fontSize:10,
                color: "#fff",
              },
            },
          },
          yAxis: {
            // axisLine: {
            //   show: false,
            // },
            // axisTick: {
            //   show: false,
            // },
            splitArea: { show: false }, //去除网格区域
            splitLine: {
              lineStyle: {
                type: "dashed", // dotted虚线
                color:'#8a8c8e'
              },
            },
            axisLine: {
              lineStyle: {
                color: "#6889D8",
              },
            },
            axisLabel: {
              textStyle: {
                fontSize:10,
                color: "#fff",
              },
            },
          },
          // dataZoom: [
          //   {
          //     type: "inside",
          //   },
          // ],
          // grid: {
          //   left: "3%",
          //   right: "5%",
          //   bottom: "1%",
          //   top: "20%",
          //   containLabel: true,
          // },
          // tooltip: {
          //   trigger: "axis",
          //   axisPointer: {
          //     type: "cross",
          //   },
          //   calculable: true,
          //   padding: [5, 10],
          // },
          // toolbox: {
          //   show: true,
          // },
          // yAxis: {
          //   axisTick: {
          //     show: false,
          //   },
          //   //去除y轴网格线
          //   splitLine: {
          //     show: false,
          //   },
          //   splitArea: { show: false }, //去除网格区域
          // },
          // legend: {
          //   textStyle: {
          //     //图例文字的样式
          //     color: "#ccc",
          //     fontSize: 16,
          //     top: "middle",
          //     orient: "vertical",
          //   },
          //   data: ["水", "电", "氮气"],
          //   //icon:'roundRect',
          //   //color:'#ffffff',
          // },
          series: [
            {
              type: "line",
              areaStyle: {},
              // showBackground: true,
              itemStyle: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                  { offset: 0, color: "#8F53F3" },
                  /*{ offset: 0.5, color: "#02B9B4" },
                  { offset: 1, color: "#07ACC8" },*/
                ]),

                label: {
                  show: true,
                  position: 'right',
                  textStyle: {
                    fontSize: 18,
                    color: "white"
                  },
                  formatter: (params) => {
                    console.log('hhahahahaahahahaha-------------',params)
                    console.log('haaaaaaaaaaaaaaaa----------',curList.length)
                    if (curList.length - 1 === params.dataIndex) {
                      console.log('数值-----',params.value)
                      return params.value
                    } else {
                      return ""
                    }
                  },
                },
              },
              emphasis: {
                itemStyle: {
                  color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                    { offset: 0, color: "#2378f7" },
                    { offset: 0.7, color: "#2378f7" },
                    { offset: 1, color: "#83bff6" },
                  ]),
                },
              },
              data: curList || [],
            },
            // {
            //   smooth: true,
            //   type: "line",
            //   itemStyle: {
            //     normal: {
            //       color: "#1ab394",
            //       lineStyle: {
            //         color: "#1ab394",
            //         width: 2,
            //       },
            //     },
            //   },
            //   data: [2.0, 4.9, 7.0, 23.2],
            //   animationDuration: 2800,
            //   animationEasing: "quadraticOut",
            // },
            // {
            //   smooth: true,
            //   type: "line",
            //   itemStyle: {
            //     normal: {
            //       color: "#4394e4",
            //       lineStyle: {
            //         color: "#4394e4",
            //         width: 2,
            //       },
            //     },
            //   },
            //   data: [10, 12, 17, 67.2],
            //   animationDuration: 2800,
            //   animationEasing: "quadraticOut",
            // },
            // {
            //   smooth: true,
            //   type: "line",
            //   itemStyle: {
            //     normal: {
            //       color: "#db9e3f",
            //       lineStyle: {
            //         color: "#db9e3f",
            //         width: 2,
            //       },
            //     },
            //   },
            //   data: [5.0, 3, 10, 36],
            //   animationDuration: 2800,
            //   animationEasing: "quadraticOut",
            // },
          ],
        });
      },
    },
  };
</script>
