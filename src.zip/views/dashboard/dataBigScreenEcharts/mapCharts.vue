<template>
  <div :class="className" :style="{height:height,width:width}"/>
</template>

<script>
  import echarts from 'echarts'
  import "echarts/lib/chart/map";  //这个是必须的
  import 'echarts/map/js/china'
  import resize from '../mixins/resize'

  require('echarts/theme/macarons') // echarts theme

  export default {
    mixins: [resize],
    props: {
      className: {
        type: String,
        default: 'chart'
      },
      width: {
        type: String,
        default: '100%'
      },
      height: {
        type: String,
        default: '5.733rem'
      },
      autoResize: {
        type: Boolean,
        default: true
      },
      chartData: {
        type: Object,
        required: true
      }
    },
    data() {
      return {
        chart: null,

      }
    },
    watch: {
      chartData: {
        deep: true,
        handler(val) {
          this.setOptions(val)
        }
      }
    },
    mounted() {
      this.$nextTick(() => {
        this.initChart()
      })
    },
    // beforeDestroy() {
    //   if (!this.chart) {
    //     return
    //   }
    //   this.chart.dispose()
    //   this.chart = null
    // },
    methods: {
      randomValue(){
        return Math.round(Math.random()*500)
      },
      initChart() {
        this.chart = echarts.init(this.$el, 'macarons')
        this.setOptions(this.chartData)
        console.log(this.randomValue())
      },
      setOptions({timeData} = {}) {
        this.chart.setOption({

          tooltip: {
            trigger: 'item'
          },
          legend: {
            orient:'horizontal',//图例的排列方向
            textStyle:{color:'#3FA7FF'},
            x:'left',
            y:'20',
            data: ['全国数据'],
          },

          visualMap: {//颜色的设置  dataRange
            textStyle: {color:'#fff'},
            x: 'left',
            y: '60%',

            /*splitList: [
              {start: 1500},{start: 900, end: 1500},
              {start: 310, end: 1000},{start: 200, end: 300},
              {start: 50, end: 200},{start: 0, end: 50},
            ],*/
            // text:['高','低'],// 文本，默认为数值文本

           color: ['#5475f5', '#9feaa5', '#3FA7FF','#66E0E3', '#FFDC5E', '#9fb5ea']
          },
          series : [
            {
              name: '全国数据',
              type: 'map',
              mapType: 'china',
              zoom: 1.2,
              roam: false,//是否开启鼠标缩放和平移漫游
              itemStyle:{//地图区域的多边形 图形样式
                normal:{//是图形在默认状态下的样式
                  label:{
                    show: true,
                    textStyle: {color: "#fff"}
                  }
                },
                emphasis:{//是图形在高亮状态下的样式,比如在鼠标悬浮或者图例联动高亮时
                  label:{show:true},
                }
              },
              top:"35.4rem",//组件距离容器的距离
              data:[
                {name:"南海诸岛",value:0},
                {name: '北京', value: this.randomValue()},
                {name: '天津', value: this.randomValue()},
                {name: '上海', value: this.randomValue()},
                {name: '重庆', value: this.randomValue()},
                {name: '河北', value: this.randomValue()},
                {name: '河南', value: this.randomValue()},
                {name: '云南', value: this.randomValue()},
                {name: '辽宁', value: this.randomValue()},
                {name: '黑龙江', value: this.randomValue()},
                {name: '湖南', value: this.randomValue()},
                {name: '安徽', value: this.randomValue()},
                {name: '山东', value: this.randomValue()},
                {name: '新疆', value: this.randomValue()},
                {name: '江苏', value: this.randomValue()},
                {name: '浙江', value: this.randomValue()},
                {name: '江西', value: this.randomValue()},
                {name: '湖北', value: this.randomValue()},
                {name: '广西', value: this.randomValue()},
                {name: '甘肃', value: this.randomValue()},
                {name: '山西', value: this.randomValue()},
                {name: '内蒙古', value: this.randomValue()},
                {name: '陕西', value: this.randomValue()},
                {name: '吉林', value: this.randomValue()},
                {name: '福建', value: this.randomValue()},
                {name: '贵州', value: this.randomValue()},
                {name: '广东', value: this.randomValue()},
                {name: '青海', value: this.randomValue()},
                {name: '西藏', value: this.randomValue()},
                {name: '四川', value: this.randomValue()},
                {name: '宁夏', value: this.randomValue()},
                {name: '海南', value: this.randomValue()},
                {name: '台湾', value: this.randomValue()},
                {name: '香港', value: this.randomValue()},
                {name: '澳门', value: this.randomValue()}
              ]
            }
          ]

        })
      },
    }
  }
</script>
<style>
  *{margin:0;padding:0}
  html,body{
    width:100%;
    height:100%;
  }
  #main{
    width:600px;
    height:450px;
    margin: 150px auto;
    border:1px solid #3FA7FF;
  }
  /*默认长宽比0.75*/
</style>
