<template>
  <div :class="className" :style="{height: height, width: width}"/>
</template>

<script>
import echarts from 'echarts'
import resize from '../mixins/resize'

require('echarts/theme/macarons') // echarts theme

export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '530px'
    },
    autoResize: {
      type: Boolean,
      default: true
    },
    chartData: {
      type: Array,
      required: true
    },
  },
  data() {
    return {
      chart: null,
      machineSplitList:[],
      seriesData:[],
      categoriesData:[]
    }
  },
  watch: {
    chartData: {
      deep: true,
      handler(val) {
        this.machineSplitList = val;
        this.initData();
        this.setOptions();
      }
    }
  },
  created() {
    this.initData();
  },
  mounted() {
    this.$nextTick(() => {
      this.initChart()
    })
  },
  // beforeDestroy() {
  //   if (!this.chart) {
  //     return
  //   }
  //   this.chart.dispose()
  //   this.chart = null
  // },
  methods: {
    initChart() {
      this.chart = echarts.init(this.$el, 'macarons');
      this.setOptions()
    },

    initData(){
      this.categoriesData = [];
      this.seriesData = [];
      this.machineSplitList =  this.chartData;
      this.machineSplitList.forEach((series,index) => {
        this.categoriesData.push(series.machineName);
        series.machineSplitDtoList.forEach(item=>{
          const currentItem = {
            name: this.getStatus(item.status),
            value: [index,
              item.startDate,
              item.endDate,
              item.duration],
            itemStyle: {
              normal: {
                color: this.getColor(item.status)
              }
            }
          }
          this.seriesData.push(currentItem);
        });
      });
    },
    /**
     * 获取颜色
     * @param runStatus 状态
     */
    getColor(runStatus) {
      switch (runStatus) {
        case 'Error':
        case '故障':
        case 0:
          return '#F76666';
        case 'Shutdown':
        case '停机':
        case 1:
          return '#8C9199';
        case 'NoLoad':
        case '空载':
        case 2:
          return '#5AD8A6';
        case 'FullLoad':
        case '满载':
        case 3:
          return '#1890FF';
        case 'OverLoad':
        case '过载':
        case 4:
          return '#F6BD16';
        default: return '#8C9199';
      }
    },
    /**
     * 获取设备状态名称
     * @param status状态
     */
    getStatus(status) {
      switch (status) {
        case 0:
          return '故障';
        case 1:
          return '停机';
        case 2:
          return '空载';
        case 3:
          return '满载';
        case 4:
          return '过载';
        default: return 'NA';
      }
    },
    setOptions() {
      this.chart.setOption({
        color: ['#F76666','#8C9199','#5AD8A6','#1890FF','#F6BD16'],
        grid: {
          left: '2%',
          right: '5%',
          top: '8%',
          bottom: '15%',
          containLabel: true
        },
        dataZoom: [{
          type: 'slider',
          filterMode: 'weakFilter',
          bottom: '5%',
          left: '6%',
          right: '6%'
        }],
        tooltip: {
          textStyle: {
            fontSize: 12
          },
          formatter: function (params) {
            const data = params.value;
            const status = params.name; // 设备状态
            const dateRange = `${data[1]} - ${data[2]}`;
            const duration = data[3];
            if (data) {
              return `设备状态: ${status}<br>
            时间范围: ${dateRange}<br>
            持续时间: ${duration}`;
            }
          }
        },
        xAxis: {
          type: 'time',
          scale: true
        },
        yAxis: {
          data: this.categoriesData
        },
        legend: {},
        series:
          [
            { name: '故障', type: 'bar', data: [] },
            { name: '停机', type: 'bar', data: [] },
            { name: '空载', type: 'bar', data: [] },
            { name: '满载', type: 'bar', data: [] },
            { name: '过载', type: 'bar', data: [] },
            {
              type: 'custom',
              renderItem: function renderItem(params, api) {
                var categoryIndex = api.value(0);
                var start = api.coord([api.value(1), categoryIndex]);
                var end = api.coord([api.value(2), categoryIndex]);
                var height = api.size([0, 1])[1] * 0.6;
                var rectShape = echarts.graphic.clipRectByRect(
                  {
                    x: start[0],
                    y: start[1] - height / 2,
                    width: end[0] - start[0],
                    height: height
                  },
                  {
                    x: params.coordSys.x,
                    y: params.coordSys.y,
                    width: params.coordSys.width,
                    height: params.coordSys.height
                  }
                );
                return (
                  rectShape && {
                    type: 'rect',
                    transition: ['shape'],
                    shape: rectShape,
                    style: api.style()
                  }
                )
              },
              itemStyle: {
                opacity: 0.8
              },
              encode: {
                x: [1, 2],
                y: 0
              },
              data: this.seriesData
            }
          ]
      })
    },
  }
}
</script>
