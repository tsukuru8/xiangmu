<template>
  <div :class="className" :style="{height:height,width:width}"/>
</template>

<script>
  import echarts from 'echarts'
  import resize from '../mixins/resize'

  require('echarts/theme/macarons') // echarts theme

  export default {
    mixins: [resize],
    props: {
      className: {
        type: String,
        default: 'chart'
      },
      width: {
        type: String,
        default: '100%'
      },
      height: {
        type: String,
        default: '330px'
      },
      autoResize: {
        type: Boolean,
        default: true
      },
      chartData: {
        type: Object,
        required: true
      }
    },
    data() {
      return {
        chart: null
      }
    },
    watch: {
      chartData: {
        deep: true,
        handler(val) {
          this.setOptions(val)
        }
      }
    },
    mounted() {
      this.$nextTick(() => {
        this.initChart()
      })
    },
    // beforeDestroy() {
    //   if (!this.chart) {
    //     return
    //   }
    //   this.chart.dispose()
    //   this.chart = null
    // },
    methods: {
      initChart() {
        this.chart = echarts.init(this.$el, 'macarons')
        this.setOptions(this.chartData)
      },
      setOptions({xAxisData, flatList, peakList, tipList, valleyList} = {}) {
        this.chart.setOption({
          xAxis: {
            data: xAxisData || [],
            type: 'category'
            // boundaryGap: false,
            // axisTick: {
            //   show: false
            // },
          },
          grid: {
            left: '3%',
            right: '5%',
            bottom: 20,
            top: 30,
            containLabel: true
          },
          tooltip: {
            trigger: 'axis',
            axisPointer: {
              type: 'cross'
            },
            calculable: true,
            padding: [5, 10]
          },
          toolbox: {
            show: true,
            feature: {
              dataView: {show: true, readOnly: false},
              magicType: {show: true, type: ['line', 'bar']},
              restore: {show: true},
              saveAsImage: {show: true}
            }
          },
          yAxis: {
            axisTick: {
              show: false
            },
            type:'value',
            name:'单位:kW·h'
          },
          legend: {
            data: ['峰电量', '谷电量','平电量','尖电量'],
            icon:'roundRect',
          },
          series: [{
            name: '峰电量',
            smooth: true,
            type: 'bar',
            itemStyle: {
              normal: {
                color: '#f8cb7f',
                lineStyle: {
                  color: '#f8cb7f',
                  width: 2
                },
                areaStyle: {
                  color: '#f8cb7f'
                }
              }
            },
            data: peakList || [],
            animationDuration: 2800,
            animationEasing: 'quadraticOut'
          },
            {
              name: '谷电量',
              smooth: true,
              type: 'bar',
              itemStyle: {
                normal: {
                  color: '#76da91',
                  lineStyle: {
                    color: '#76da91',
                    width: 2
                  },
                  areaStyle: {
                    color: '#76da91'
                  }
                }
              },
              data: valleyList || [],
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            },{
              name: '平电量',
              smooth: true,
              type: 'bar',
              itemStyle: {
                normal: {
                  color: '#63b2ee',
                  lineStyle: {
                    color: '#63b2ee',
                    width: 2
                  },
                  areaStyle: {
                    color: '#63b2ee'
                  }
                }
              },
              data: flatList || [],
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            },{
              name: '尖电量',
              smooth: true,
              type: 'bar',
              itemStyle: {
                normal: {
                  color: '#f89588',
                  lineStyle: {
                    color: '#f89588',
                    width: 2
                  },
                  areaStyle: {
                    color: '#f89588'
                  }
                }
              },
              data: tipList || [],
              animationDuration: 2800,
              animationEasing: 'quadraticOut'
            }]
        })
      },
    }
  }
</script>
