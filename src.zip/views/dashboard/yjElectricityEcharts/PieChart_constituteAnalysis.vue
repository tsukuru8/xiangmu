<template>
  <div :class="className" :style="{height:height,width:width}" />
</template>

<script>
  import echarts from 'echarts'
  import resize from '../mixins/resize'
  require('echarts/theme/macarons') // echarts theme

  export default {
    mixins: [resize],
    props: {
      className: {
        type: String,
        default: 'chart'
      },
      width: {
        type: String,
        default: '100%'
      },
      height: {
        type: String,
        default: '300px'
      },
      chartData: {
        type: Object,
        required: true
      }
    },
    data() {
      return {
        chart: null
      }
    },
    watch: {
      chartData: {
        deep: true,
        handler(val) {
          this.setOptions(val)
        }
      }
    },
    mounted() {
      this.$nextTick(() => {
        this.initChart()
      })
    },
    beforeDestroy() {
      if (!this.chart) {
        return
      }
      this.chart.dispose()
      this.chart = null
    },
    methods: {
      initChart() {
        this.chart = echarts.init(this.$el, 'macarons')
        this.setOptions(this.chartData)

      },
      setOptions({compositonVOList} = {}) {
        this.chart.setOption({
          tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b} : {c} ({d}%)'
          },
          //设置饼图颜色
          color:['#f8cb7f','#76da91','#63b2ee','#f89588'],
          legend: {
            left: 'center',
            bottom: '10',
            data: ['峰电量', '谷电量', '平电量', '尖电量']
          },
          series: [
            {
              name: '构成分析',
              type: 'pie',
              // roseType: 'radius',
              radius: ['50%', '70%'],
              // center: ['50%', '38%'],
              avoidLabelOverlap: false,
              label: {
                  show: false,
                  position: 'center'
              },
              emphasis: {
                  label: {
                      show: true,
                      fontSize: '30',
                      fontWeight: 'bold'
                  }
              },
              labelLine: {
                  show: false,
              },
              data: this.chartData.compositonVOList || [],
            }
          ]
        })
      },
    }
  }
</script>
