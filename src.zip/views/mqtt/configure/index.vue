<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" :inline="true" label-width="70px">
      <el-form-item label="客户端ID" prop="clientId">
        <el-input
          v-model="queryParams.clientId"
          placeholder="请输入客户端ID"
          clearable
          size="small"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>

      <!--<el-form-item label="归属部门" prop="deptId">
        <treeselect multiple :options="deptOptions" width="50px" placeholder="请选择归属部门" v-model="queryParams.deptId" style="width: 215px; height: 30px"/>
      </el-form-item>-->
      <el-form-item label="设备名称" prop="deviceName">
        <el-input
          v-model="queryParams.deviceName"
          placeholder="设备名称"
          clearable
          size="small"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="主题" prop="topics">
        <el-input
          v-model="queryParams.topics"
          placeholder="请输入主题"
          clearable
          size="small"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
<!--      <el-form-item label="空载阈值" prop="noloadLimit">-->
<!--        <el-input-->
<!--          v-model="queryParams.noloadLimit"-->
<!--          placeholder="请输入空载阈值"-->
<!--          clearable-->
<!--          size="small"-->
<!--          @keyup.enter.native="handleQuery"-->
<!--        />-->
<!--      </el-form-item>-->
<!--      <el-form-item label="满载阈值" prop="overloadLimit">-->
<!--        <el-input-->
<!--          v-model="queryParams.overloadLimit"-->
<!--          placeholder="请输入满载阈值"-->
<!--          clearable-->
<!--          size="small"-->
<!--          @keyup.enter.native="handleQuery"-->
<!--        />-->
<!--      </el-form-item>-->
      <el-form-item label="创建人" prop="creatBy">
        <el-input
          v-model="queryParams.creatBy"
          placeholder="请输入创建人"
          clearable
          size="small"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="创建时间" prop="creatTime">
        <el-date-picker clearable size="small" style="width: 200px"
                        v-model="queryParams.creatTime"
                        type="date"
                        value-format="yyyy-MM-dd"
                        placeholder="选择创建时间">
        </el-date-picker>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          icon="el-icon-plus"
          size="mini"
          @click="handleAdd"
          v-hasPermi="['mqtt:configure:add']"
        >新增</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="success"
          icon="el-icon-edit"
          size="mini"
          :disabled="single"
          @click="handleUpdate"
          v-hasPermi="['mqtt:configure:edit']"
        >修改</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          icon="el-icon-delete"
          size="mini"
          :disabled="multiple"
          @click="handleDelete"
          v-hasPermi="['mqtt:configure:remove']"
        >删除</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          icon="el-icon-download"
          size="mini"
          @click="handleExport"
          v-hasPermi="['mqtt:configure:export']"
        >导出</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="info"
          icon="el-icon-info"
          size="mini"
          @click="MessageTips"
        >操作提示</el-button>
      </el-col>
    </el-row>

    <el-table v-loading="loading" :data="configureList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column label="主题ID" align="center" prop="id" />
      <el-table-column label="客户端ID" align="center" prop="clientId" />
      <!--<el-table-column label="部门名称" align="center" prop="deptName" />-->
      <el-table-column label="设备名称" align="center" prop="deviceName"/>
      <el-table-column label="主题" align="center" prop="topics" />
      <el-table-column label="QOS" align="center" prop="qos" />
      <el-table-column label="空载阈值" align="center" prop="noloadLimit" />
      <el-table-column label="满载阈值" align="center" prop="overloadLimit" />
      <el-table-column label="状态" align="center">
        <template slot-scope="scope">
          <el-switch
            v-model="scope.row.isOnline"
            active-value="1"
            inactive-value="0"
            active-color="green"
            inactive-color="red"
            disabled
          ></el-switch>
        </template>
      </el-table-column>
      <el-table-column label="电机类设备" align="center" prop="isMotor">
        <template slot-scope="scope">
         <span>{{scope.row.isMotor === 1 ? '是' : '否'}}</span>
        </template>
      </el-table-column>

      <el-table-column label="创建人" align="center" prop="creatBy" />
      <el-table-column label="创建时间" align="center" prop="creatTime" width="180">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.creatTime, '{y}-{m}-{d}') }}</span>
        </template>
      </el-table-column>
      <el-table-column label="最后心跳" align="center" prop="updateTime" width="180">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.updateTime) }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row)"
            v-hasPermi="['mqtt:configure:edit']"
          >修改</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-delete"
            @click="handleDelete(scope.row)"
            v-hasPermi="['mqtt:configure:remove']"
          >删除</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-s-tools"
            @click="handleGenerateDateTable(scope.row)"
            v-hasPermi="['mqtt:configure:generatedatetable']"
          >数据库配置</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加或修改MQTT订阅配置对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="500px" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="85px">
        <el-form-item label="客户端ID" prop="clientId">
          <el-input v-model="form.clientId" placeholder="请输入客户端ID" />
        </el-form-item>
        <!--<el-form-item label="归属部门" prop="deptId">
          <treeselect multiple :options="deptOptions" placeholder="请选择归属部门" v-model="deptIdList"/>
        </el-form-item>-->
        <el-form-item label="设备名称" prop="deviceName">
          <el-input v-model="form.deviceName" placeholder="请输入设备名称" />
        </el-form-item>
        <el-form-item label="主题" prop="topics">
          <el-input v-model="form.topics" placeholder="请输入主题" />
        </el-form-item>
        <el-form-item label="QOS" prop="qos">
          <el-input v-model="form.qos" placeholder="请输入QOS" />
        </el-form-item>
        <el-form-item label="空载阈值" prop="noloadLimit">
          <el-input v-model="form.noloadLimit" placeholder="请输入空载阈值" />
        </el-form-item>
        <el-form-item label="满载阈值" prop="overloadLimit">
          <el-input v-model="form.overloadLimit" placeholder="请输入满载阈值" />
        </el-form-item>
        <el-form-item label="电机类设备" prop="isMotor">
          <el-select v-model="form.isMotor" placeholder="请选择">
            <el-option
              v-for="item in motorOptions"
              :key="item.id"
              :label="item.name"
              :value="item.id">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="创建人" prop="creatBy">
          <el-input v-model="form.creatBy" placeholder="请输入创建人" />
        </el-form-item>
        <el-form-item label="创建时间" prop="creatTime">
          <el-date-picker clearable size="small" style="width: 200px"
                          v-model="form.creatTime"
                          type="date"
                          value-format="yyyy-MM-dd"
                          placeholder="选择创建时间">
          </el-date-picker>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import {treeselect} from "@/api/system/dept";
  import Treeselect from "@riophae/vue-treeselect";
  import "@riophae/vue-treeselect/dist/vue-treeselect.css";
  import { listConfigure, getConfigure, delConfigure, addConfigure, updateConfigure, exportConfigure, generateDateTable } from "@/api/mqtt/mqttConfigure";

  export default {
    name: "Configure",
    components: {Treeselect},
    data() {
      return {
        // 遮罩层
        loading: true,
        // 选中数组
        ids: [],
        // 非单个禁用
        single: true,
        // 非多个禁用
        multiple: true,
        // 总条数
        total: 0,
        // MQTT订阅配置表格数据
        configureList: [],
        // 弹出层标题
        title: "",
        // 是否显示弹出层
        open: false,
        // 部门树选项
        deptOptions: undefined,
        // 查询参数
        queryParams: {
          pageNum: 1,
          pageSize: 10,
          deptId: undefined,
          clientId: undefined,
          deptName:undefined,
          deviceName: undefined,
          topics: undefined,
          qos: undefined,
          noloadLimit: undefined,
          overloadLimit: undefined,
          creatBy: undefined,
          creatTime: undefined,
        },
        //部门集合
        deptIdList:[],
        options:[],
        // 表单参数
        form: {},
        // 表单校验
        rules: {
          deptId: [
            {required: true, message: "归属部门不能为空", trigger: "blur"}
          ],
        },
        motorOptions:[
          {name: '是', id: 1},
          {name: '否', id: 0}
        ]
      };
    },
    created() {
      this.getList();
      this.getTreeselect();
      this.timer();
    },
    methods: {

      /** 查询部门下拉树结构 */
      getTreeselect() {
        treeselect().then(response => {
          this.deptOptions = response.data;
        });
      },
    /** 查询MQTT订阅配置列表 */
      getList() {
        this.loading = true;
        listConfigure(this.queryParams).then(response => {
          this.configureList = response.rows;
          this.total = response.total;
          this.loading = false;
        });
      },
      // 取消按钮
      cancel() {
        this.open = false;
        this.reset();
      },
      // 表单重置
      reset() {
        this.form = {
          id: undefined,
          clientId: undefined,
          deptId:undefined,
          deptName:undefined,
          deviceName: undefined,
          topics: undefined,
          qos: undefined,
          noloadLimit: undefined,
          overloadLimit: undefined,
          creatBy: undefined,
          creatTime: undefined,
          updateBy: undefined,
          updateTime: undefined,
          isMotor: 0
        };
        this.resetForm("form");
      },
      /** 搜索按钮操作 */
      handleQuery() {
        this.queryParams.pageNum = 1;
        this.getList();
      },
      /** 重置按钮操作 */
      resetQuery() {
        this.resetForm("queryForm");
        this.handleQuery();
      },
      // 多选框选中数据
      handleSelectionChange(selection) {
        this.ids = selection.map(item => item.id)
        this.single = selection.length!=1
        this.multiple = !selection.length
      },
      /** 新增按钮操作 */
      handleAdd() {
        this.reset();
        this.open = true;
        this.title = "添加MQTT订阅配置";
      },
      /** 修改按钮操作 */
      handleUpdate(row) {
        this.reset();
        const id = row.id || this.ids
        getConfigure(id).then(response => {
          console.log(response.data)
          this.form = response.data;
          this.open = true;
          this.title = "修改MQTT订阅配置";
        });
      },
      /** 提交按钮 */
      submitForm: function() {
        this.$refs["form"].validate(valid => {
          if (valid) {
            if (this.form.id != undefined) {
              updateConfigure(this.form).then(response => {
                if (response.code === 200) {
                  this.msgSuccess("修改成功");
                  this.open = false;
                  this.getList();
                } else {
                  this.msgError(response.msg);
                }
              });
            } else {
              addConfigure(this.form).then(response => {
                if (response.code === 200) {
                  this.msgSuccess("新增成功");
                  this.open = false;
                  this.getList();
                } else {
                  this.msgError(response.msg);
                }
              });
            }
          }
        });
      },
      /** 删除按钮操作 */
      handleDelete(row) {
        const ids = row.id || this.ids;
        this.$confirm('是否确认删除MQTT订阅配置编号为"' + ids + '"的数据项?', "警告", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(function() {
          return delConfigure(ids);
        }).then(() => {
          this.getList();
          this.msgSuccess("删除成功");
        }).catch(function() {});
      },
      /** 导出按钮操作 */
      handleExport() {
        const queryParams = this.queryParams;
        this.$confirm('是否确认导出所有MQTT订阅配置数据项?', "警告", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(function() {
          return exportConfigure(queryParams);
        }).then(response => {
          this.download(response.msg);
        }).catch(function() {});
      },
      /**操作提示*/
      MessageTips() {
        this.$notify.info({
          title: '操作提示',
          message: '客户端ID为网关ID，需要保证唯一性，设备名称为现场电表名称，主题需要和设备名称对应并保证唯一性。'
        });
      },
      /**数据库配置*/
      handleGenerateDateTable(row){
        const id = row.id;
        this.$confirm('是否为编号为"' + id + '"的计量设备配置数据库?', "警告", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(function() {
          return generateDateTable(id);
        }).then(() => {
          this.msgSuccess("配置成功");
        }).catch(function() {});
      },

      // 这是一个定时器
      timer() {
        return setInterval(()=>{
          this.getList()
        },60000)
      },
    }
  };
</script>
