<template>
  <el-row>
    <el-date-picker
      v-model="date"
      type="date"
      value-format="yyyy-MM-dd"
      placeholder="选择日期">
    </el-date-picker>
    <el-button type="primary" @click="sumElectricData">电能汇总</el-button>
    <el-button type="primary" @click="calculateElectricData">电能计算</el-button>
<!--    <el-button type="primary" @click="sumWaterData">水能汇总</el-button>-->
<!--    <el-button type="primary" @click="calculateWaterData">水能计算</el-button>-->
<!--    <el-button type="primary" @click="sumGasData">气能汇总</el-button>-->
<!--    <el-button type="primary" @click="calculateGasData">气能计算</el-button>-->
<!--    <el-button type="primary" @click="sumSolarData">太阳能汇总</el-button>-->
<!--    <el-button type="primary" @click="calculateSolarData">太阳能计算</el-button>-->
<!--    <el-button type="primary" @click="sumThremalData">热能汇总</el-button>-->
<!--    <el-button type="primary" @click="calculateThremalData">热能计算</el-button>-->
<!--    <el-button type="warning" @click="refreshBigScreenData">大屏数据刷新</el-button>-->
  </el-row>
</template>
<script>
  import {
    calculateElectricData,
    calculateGasData,
    calculateSolarData,
    calculateThremalData,
    calculateWaterData,
    refreshBigScreenData,
    sumElectricData,
    sumGasData,
    sumSolarData,
    sumThremalData,
    sumWaterData
  } from "../../../api/mqtt/dataCalculate";

  export default {
    name: "dataCalculate",
    data() {
      return {
        date: undefined,
      }
    },
    created() {
    },
    mounted() {
    },
    methods: {
      /** 电能汇总*/
      sumElectricData() {
        const date = this.date;
        sumElectricData({date: date}).then(response => {
          if (response.code == 200) {
            this.msgSuccess("电能汇总成功")
          }
        })
      },
      /** 电能计算*/
      calculateElectricData() {
        const date = this.date;
        calculateElectricData({date: date}).then(response => {
          if (response.code == 200) {
            this.msgSuccess("电能计算成功")
          }
        })
      },
      /** 水能汇总*/
      sumWaterData() {
        const date = this.date;
        sumWaterData({date: date}).then(response => {
          if (response.code == 200) {
            this.msgSuccess("水能汇总成功")
          }
        })
      },
      /** 水能计算*/
      calculateWaterData() {
        const date = this.date;
        calculateWaterData({date: date}).then(response => {
          if (response.code == 200) {
            this.msgSuccess("水能计算成功")
          }
        })
      },
      /** 气能汇总*/
      sumGasData() {
        const date = this.date;
        sumGasData({date: date}).then(response => {
          if (response.code == 200) {
            this.msgSuccess("气能汇总成功")
          }
        })
      },
      /** 气能计算*/
      calculateGasData() {
        const date = this.date;
        calculateGasData({date: date}).then(response => {
          if (response.code == 200) {
            this.msgSuccess("气能计算成功")
          }
        })
      },

      /** 太阳能汇总*/
      sumSolarData() {
        const date = this.date;
        sumSolarData({date: date}).then(response => {
          if (response.code == 200) {
            this.msgSuccess("太阳能汇总成功")
          }
        })
      },
      /** 电能计算*/
      calculateSolarData() {
        const date = this.date;
        calculateSolarData({date: date}).then(response => {
          if (response.code == 200) {
            this.msgSuccess("太阳能计算成功")
          }
        })
      },

      /**热能汇总*/
      sumThremalData() {
        const date = this.date;
        sumThremalData({date: date}).then(response => {
          if (response.code == 200) {
            this.msgSuccess("热能汇总成功")
          }
        })
      },
      /**热能计算*/
      calculateThremalData() {
        const date = this.date;
        calculateThremalData({date: date}).then(response => {
          if (response.code == 200) {
            this.msgSuccess("热能计算成功")
          }
        })
      },


      /**大屏数据刷新*/
      refreshBigScreenData() {
        refreshBigScreenData().then(response => {
          if (response.code == 200) {
            this.msgSuccess("大屏数据刷新成功")
          }
        })
      }


    }
  }
</script>
