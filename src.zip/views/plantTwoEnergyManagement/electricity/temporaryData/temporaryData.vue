<template>

  <!--顶部查询-->
  <div class="app-container">
    <el-form :inline="true" :model="formData" :rules="rules" label-width="100px" ref="elForm" size="medium">

      <el-form-item label="查询表格" prop="field101">
        <el-select style="width: 280px" clearable placeholder="请选择" v-model="tableId">
          <el-option :disabled="item.disabled" :key="index" :label="item.label"
                     :value="item.value" v-for="(item, index) in tableList"></el-option>
        </el-select>
      </el-form-item>

      <el-form-item label="查询时间">
        <el-date-picker
          end-placeholder="结束日期"
          range-separator="-"
          size="small"
          start-placeholder="开始日期"
          style="width: 240px"
          type="daterange"
          v-model="dateRange"
          value-format="yyyy-MM-dd"
        ></el-date-picker>
      </el-form-item>

      <el-form-item size="large">
        <el-button @click="submitForm" type="primary">查询
        </el-button>
        <el-button @click="resetForm" type="reset">重置</el-button>
        <el-button @click="handleExport" icon="el-icon-download" type="warning">导出
        </el-button>
      </el-form-item>

    </el-form>

    <el-row :gutter="1" v-if="dn21">
      <!--报表title-->
      <el-tag :style="{width: '100%'}" align="center" clearable style="font-size: 20px" type="success">
        扬杰电子科技股份有限公司电能2_1表
      </el-tag>
      <!--报表内容-->
      <el-table :data="tableData" :row-class-name="tableRowClassName" border  style="width: 100%">
        <el-table-column align="center" label="日期" prop="createTime"/>
        <el-table-column align="center" label="约克200RT+水泵风机电能(kw·h)" prop="ygzdn"/>
        <el-table-column align="center" label="功率(kw)" prop="yggl"/>
      </el-table>
      <pagination
        :limit.sync="formData.pageSize"
        :page.sync="formData.pageNum"
        :total="total"
        @pagination="getDn21List"
        v-show="total>0"
      />
    </el-row>

    <el-row :gutter="2" v-if="dn22">
      <!--报表title-->
      <el-tag :style="{width: '100%'}" align="center" clearable style="font-size: 20px" type="success">
        扬杰电子科技股份有限公司电能2_2表
      </el-tag>
      <!--报表内容-->
      <el-table :data="tableData" :row-class-name="tableRowClassName" border  style="width: 100%">
        <el-table-column align="center" label="日期" prop="createTime"/>
        <el-table-column align="center" label="国祥200RT电能、国祥340RT电能(kw·h)" prop="ygzdn"/>
        <el-table-column align="center" label="功率(kw)" prop="yggl"/>
      </el-table>
      <pagination
        :limit.sync="formData.pageSize"
        :page.sync="formData.pageNum"
        :total="total"
        @pagination="getDn22List"
        v-show="total>0"
      />
    </el-row>
  </div>
</template>
<script>
  import {tempData21,exportDn21,tempData22,exportDn22} from "../../../../api/energyManagement/plantTwo/tempData"
  export default {
    name: "temporaryData",
    data() {
      return {
        // 遮罩层
        loading: true,
        // 选中数组
        ids: [],
        // 非单个禁用
        single: true,
        // 非多个禁用
        multiple: true,
        // 总条数
        total: 0,
        // 下拉选项
        tableList:[{
          value:1,
          label:'扬杰电子科技股份有限公司电能2_1表',
        },{
          value:2,
          label:'扬杰电子科技股份有限公司电能2_2表',
        }],
        // 日期范围
        dateRange: [],
        // 弹出层标题
        title: "",
        // 是否显示弹出层
        open: false,
        //下拉框初始值
        tableId: 1,
        // 查询参数
        formData: {
          pageNum: 1,
          pageSize: 10,
          dateRange: ""
        },
        rules: {
          tableId: [{
            required: true,
            message: '请选择查询表格',
            trigger: 'change'
          }],
          queryTime: [{
            required: true,
            message: '抄表日期不能为空',
            trigger: 'change'
          }],
        },
        // 下拉联动
        dn21:false,
        dn22:false,
        //电能1表
        tableData: [],


      }
    },
    computed: {

      timeDefault() {
        //获取新的时间(2020.5.12）
        let date = new Date()
        //获取当前时间的年份转为字符串
        let year = date.getFullYear().toString()   //'2020'
        //获取月份，由于月份从0开始，此处要加1，判断是否小于10，如果是在字符串前面拼接'0'
        let month = date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1).toString() : (date.getMonth() + 1).toString()  //'04'
        //获取天，判断是否小于10，如果是在字符串前面拼接'0'
        let da = date.getDate() < 10 ? '0' + date.getDate().toString() : date.getDate().toString()  //'12'
        //字符串拼接，开始时间，结束时间
        let end = year + '-' + month + '-' + da + ' 23:59:59' //当天'2020-05-12'
        let beg = year + '-' + month + '-01' + ' 00:00:00'   //当月第一天'2020-05-01'
        this.dateRange = [beg, end] //将值设置给插件绑定的数据
      }
    },
    watch: {},
    created() {
      // 初始化查询，默认为每月1号到当前时间
      this.formData.dateRange = this.timeDefault;
      this.getDn21List()
    },
    mounted() {

    },
    methods: {
      /** 查询扬杰电子电能2_1统计列表 */
      getDn21List() {
        this.loading = true;
          this.dn21=true,
          this.dn22=false,
          tempData21(this.addDateRange(this.formData,this.dateRange)).then(response => {
              console.log("执行了电能2_1------------")
              this.tableData = response.rows;
              this.total = response.total;
              this.loading = false;
            }
          );
      },
      /** 查询扬杰电子电能2_2统计列表 */
      getDn22List() {
        this.loading = true;
          this.dn21=false,
          this.dn22=true,
          tempData22(this.addDateRange(this.formData,this.dateRange)).then(response => {
              console.log("执行了电能2_2------------")
              this.tableData = response.rows;
              this.total = response.total;
              this.loading = false;
            }
          );
      },
      tableRowClassName({row, rowIndex}) {
        if (rowIndex === 0) {
          return 'first-row';
        } else if (rowIndex === 1 || rowIndex === 5) {
          return 'second-row';
        }
        return 'three-row';
      },

      submitForm() {
        this.$refs['elForm'].validate(valid => {
          if (valid) {
            if (1==this.tableId){
              this.getDn21List()
            }
            if (2==this.tableId){
              this.getDn22List()
            }
          }

        })
      },
      /**重置按钮*/
      resetForm() {
        this.dateRange = [];
        this.tableId = 1;
        this.$refs['elForm'].resetFields()
      },
      /** 导出按钮操作 */
      handleExport() {
        const queryParams = this.formData;
        console.log("========="+queryParams);
        if (1==this.tableId) {
          this.$confirm('是否确认导出扬杰电子科技股份有限公司电能2_1表?', "警告", {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning"
          }).then(function () {
            return exportDn21(queryParams);
          }).then(response => {
            this.download(response.msg);
          }).catch(function () {
          });
        }
        if (2==this.tableId){
          this.$confirm('是否确认导出扬杰电子科技股份有限公司电能2_2表?', "警告", {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning"
          }).then(function () {
            return exportDn22(queryParams);
          }).then(response => {
            this.download(response.msg);
          }).catch(function () {
          });
        }
      }
    }
  }

</script>
<style>
  /**页面样式调整**/
  .el-table .first-row {
    background: #f0f9eb;
  }

  .el-table .second-row {
    background: #f0f9eb;
  }

  .el-table .three-row {
    background: #f0f9eb;
  }
</style>
